#! /usr/bin/sed -E -i .bak -f
s/『A-APF-C』/Adjective, Accusative, Plural, Feminine, Comparative/g
s/『A-APF-NUI』/Adjective, Accusative, Plural, Feminine, NUmerical Indiclinable (A)/g
s/『A-APF-S』/Adjective, Accusative, Plural, Feminine, Superlative/g
s/『A-APF』/Adjective, Accusative, Plural, Feminine/g
s/『A-APM-C』/Adjective, Accusative, Plural, Masculine, Comparative/g
s/『A-APM-LG』/Adjective, Accusative, Plural, Masculine, Location Gentilic/g
s/『A-APM-NUI』/Adjective, Accusative, Plural, Masculine, NUmerical Indiclinable (A)/g
s/『A-APM-PG』/Adjective, Accusative, Plural, Masculine, Person Gentilic/g
s/『A-APM-S』/Adjective, Accusative, Plural, Masculine, Superlative/g
s/『A-APM』/Adjective, Accusative, Plural, Masculine/g
s/『A-APN-C』/Adjective, Accusative, Plural, Neuter, Comparative/g
s/『A-APN-NUI』/Adjective, Accusative, Plural, Neuter, NUmerical Indiclinable (A)/g
s/『A-APN-S』/Adjective, Accusative, Plural, Neuter, Superlative/g
s/『A-APN』/Adjective, Accusative, Plural, Neuter/g
s/『A-ASF-C』/Adjective, Accusative, Singular, Feminine, Comparative/g
s/『A-ASF-L』/Adjective, Accusative, Singular, Feminine, Location/g
s/『A-ASF-LG』/Adjective, Accusative, Singular, Feminine, Location Gentilic/g
s/『A-ASF-N』/Adjective, Accusative, Singular, Feminine, Negative/g
s/『A-ASF-PG』/Adjective, Accusative, Singular, Feminine, Person Gentilic/g
s/『A-ASF-S』/Adjective, Accusative, Singular, Feminine, Superlative/g
s/『A-ASF』/Adjective, Accusative, Singular, Feminine/g
s/『A-ASM-C』/Adjective, Accusative, Singular, Masculine, Comparative/g
s/『A-ASM-LG』/Adjective, Accusative, Singular, Masculine, Location Gentilic/g
s/『A-ASM-N』/Adjective, Accusative, Singular, Masculine, Negative/g
s/『A-ASM-PG』/Adjective, Accusative, Singular, Masculine, Person Gentilic/g
s/『A-ASM-S』/Adjective, Accusative, Singular, Masculine, Superlative/g
s/『A-ASM』/Adjective, Accusative, Singular, Masculine/g
s/『A-ASN-C』/Adjective, Accusative, Singular, Neuter, Comparative/g
s/『A-ASN-LG』/Adjective, Accusative, Singular, Neuter, Location Gentilic/g
s/『A-ASN-N』/Adjective, Accusative, Singular, Neuter, Negative/g
s/『A-ASN-S』/Adjective, Accusative, Singular, Neuter, Superlative/g
s/『A-ASN』/Adjective, Accusative, Singular, Neuter/g
s/『A-DPF-C』/Adjective, Dative, Plural, Feminine, Comparative/g
s/『A-DPF-NUI』/Adjective, Dative, Plural, Feminine, NUmerical Indiclinable (A)/g
s/『A-DPF-S』/Adjective, Dative, Plural, Feminine, Superlative/g
s/『A-DPF』/Adjective, Dative, Plural, Feminine/g
s/『A-DPM-C』/Adjective, Dative, Plural, Masculine, Comparative/g
s/『A-DPM-LG』/Adjective, Dative, Plural, Masculine, Location Gentilic/g
s/『A-DPM-NUI』/Adjective, Dative, Plural, Masculine, NUmerical Indiclinable (A)/g
s/『A-DPM-PG』/Adjective, Dative, Plural, Masculine, Person Gentilic/g
s/『A-DPM-S』/Adjective, Dative, Plural, Masculine, Superlative/g
s/『A-DPM』/Adjective, Dative, Plural, Masculine/g
s/『A-DPN-LG』/Adjective, Dative, Plural, Neuter, Location Gentilic/g
s/『A-DPN-NUI』/Adjective, Dative, Plural, Neuter, NUmerical Indiclinable (A)/g
s/『A-DPN-S』/Adjective, Dative, Plural, Neuter, Superlative/g
s/『A-DPN』/Adjective, Dative, Plural, Neuter/g
s/『A-DSF-C』/Adjective, Dative, Singular, Feminine, Comparative/g
s/『A-DSF-L』/Adjective, Dative, Singular, Feminine, Location/g
s/『A-DSF-LG』/Adjective, Dative, Singular, Feminine, Location Gentilic/g
s/『A-DSF-PG』/Adjective, Dative, Singular, Feminine, Person Gentilic/g
s/『A-DSF-S』/Adjective, Dative, Singular, Feminine, Superlative/g
s/『A-DSF』/Adjective, Dative, Singular, Feminine/g
s/『A-DSM-C』/Adjective, Dative, Singular, Masculine, Comparative/g
s/『A-DSM-N』/Adjective, Dative, Singular, Masculine, Negative/g
s/『A-DSM-PG』/Adjective, Dative, Singular, Masculine, Person Gentilic/g
s/『A-DSM-S』/Adjective, Dative, Singular, Masculine, Superlative/g
s/『A-DSM』/Adjective, Dative, Singular, Masculine/g
s/『A-DSN-C』/Adjective, Dative, Singular, Neuter, Comparative/g
s/『A-DSN-LG』/Adjective, Dative, Singular, Neuter, Location Gentilic/g
s/『A-DSN-N』/Adjective, Dative, Singular, Neuter, Negative/g
s/『A-DSN-S』/Adjective, Dative, Singular, Neuter, Superlative/g
s/『A-DSN』/Adjective, Dative, Singular, Neuter/g
s/『A-GMS』/Adjective, Genitive, Masculine, Superlative/g
s/『A-GPF-L』/Adjective, Genitive, Plural, Feminine, Location/g
s/『A-GPF-NUI』/Adjective, Genitive, Plural, Feminine, NUmerical Indiclinable (A)/g
s/『A-GPF-S』/Adjective, Genitive, Plural, Feminine, Superlative/g
s/『A-GPF』/Adjective, Genitive, Plural, Feminine/g
s/『A-GPM-C』/Adjective, Genitive, Plural, Masculine, Comparative/g
s/『A-GPM-LG』/Adjective, Genitive, Plural, Masculine, Location Gentilic/g
s/『A-GPM-NUI』/Adjective, Genitive, Plural, Masculine, NUmerical Indiclinable (A)/g
s/『A-GPM-PG』/Adjective, Genitive, Plural, Masculine, Person Gentilic/g
s/『A-GPM-S』/Adjective, Genitive, Plural, Masculine, Superlative/g
s/『A-GPM』/Adjective, Genitive, Plural, Masculine/g
s/『A-GPN-C』/Adjective, Genitive, Plural, Neuter, Comparative/g
s/『A-GPN-NUI』/Adjective, Genitive, Plural, Neuter, NUmerical Indiclinable (A)/g
s/『A-GPN-S』/Adjective, Genitive, Plural, Neuter, Superlative/g
s/『A-GPN』/Adjective, Genitive, Plural, Neuter/g
s/『A-GSF-C』/Adjective, Genitive, Singular, Feminine, Comparative/g
s/『A-GSF-L』/Adjective, Genitive, Singular, Feminine, Location/g
s/『A-GSF-LG』/Adjective, Genitive, Singular, Feminine, Location Gentilic/g
s/『A-GSF-PG』/Adjective, Genitive, Singular, Feminine, Person Gentilic/g
s/『A-GSF-S』/Adjective, Genitive, Singular, Feminine, Superlative/g
s/『A-GSF』/Adjective, Genitive, Singular, Feminine/g
s/『A-GSM-C』/Adjective, Genitive, Singular, Masculine, Comparative/g
s/『A-GSM-N』/Adjective, Genitive, Singular, Masculine, Negative/g
s/『A-GSM-PG』/Adjective, Genitive, Singular, Masculine, Person Gentilic/g
s/『A-GSM-S』/Adjective, Genitive, Singular, Masculine, Superlative/g
s/『A-GSM』/Adjective, Genitive, Singular, Masculine/g
s/『A-GSN-N』/Adjective, Genitive, Singular, Neuter, Negative/g
s/『A-GSN-S』/Adjective, Genitive, Singular, Neuter, Superlative/g
s/『A-GSN』/Adjective, Genitive, Singular, Neuter/g
s/『A-NPF-C』/Adjective, Nominative, Plural, Feminine, Comparative/g
s/『A-NPF-NUI』/Adjective, Nominative, Plural, Feminine, NUmerical Indiclinable (A)/g
s/『A-NPF-S』/Adjective, Nominative, Plural, Feminine, Superlative/g
s/『A-NPF』/Adjective, Nominative, Plural, Feminine/g
s/『A-NPM-C』/Adjective, Nominative, Plural, Masculine, Comparative/g
s/『A-NPM-LG』/Adjective, Nominative, Plural, Masculine, Location Gentilic/g
s/『A-NPM-NUI』/Adjective, Nominative, Plural, Masculine, NUmerical Indiclinable (A)/g
s/『A-NPM-PG』/Adjective, Nominative, Plural, Masculine, Person Gentilic/g
s/『A-NPM-S』/Adjective, Nominative, Plural, Masculine, Superlative/g
s/『A-NPM』/Adjective, Nominative, Plural, Masculine/g
s/『A-NPN-C』/Adjective, Nominative, Plural, Neuter, Comparative/g
s/『A-NPN-NUI』/Adjective, Nominative, Plural, Neuter, NUmerical Indiclinable (A)/g
s/『A-NPN-S』/Adjective, Nominative, Plural, Neuter, Superlative/g
s/『A-NPN』/Adjective, Nominative, Plural, Neuter/g
s/『A-NSF-C』/Adjective, Nominative, Singular, Feminine, Comparative/g
s/『A-NSF-LG』/Adjective, Nominative, Singular, Feminine, Location Gentilic/g
s/『A-NSF-N』/Adjective, Nominative, Singular, Feminine, Negative/g
s/『A-NSF-S』/Adjective, Nominative, Singular, Feminine, Superlative/g
s/『A-NSF』/Adjective, Nominative, Singular, Feminine/g
s/『A-NSM-ATT』/Adjective, Nominative, Singular, Masculine, ATTic Greek form/g
s/『A-NSM-C』/Adjective, Nominative, Singular, Masculine, Comparative/g
s/『A-NSM-LG』/Adjective, Nominative, Singular, Masculine, Location Gentilic/g
s/『A-NSM-N』/Adjective, Nominative, Singular, Masculine, Negative/g
s/『A-NSM-PG』/Adjective, Nominative, Singular, Masculine, Person Gentilic/g
s/『A-NSM-S』/Adjective, Nominative, Singular, Masculine, Superlative/g
s/『A-NSM-T』/Adjective, Nominative, Singular, Masculine, Title/g
s/『A-NSM』/Adjective, Nominative, Singular, Masculine/g
s/『A-NSN-C』/Adjective, Nominative, Singular, Neuter, Comparative/g
s/『A-NSN-N』/Adjective, Nominative, Singular, Neuter, Neuter/g
s/『A-NSN-S』/Adjective, Nominative, Singular, Neuter, Superlative/g
s/『A-NSN』/Adjective, Nominative, Singular, Neuter/g
s/『A-NUI-ABB』/Adjective, Nominative, ABBreviated form/g
s/『A-NUI』/Indeclinable NUmeral (Adjective)/g
s/『A-VPF』/Adjective, Vocative, Plural, Feminine/g
s/『A-VPM-C』/Adjective, Vocative, Plural, Masculine, Comparative/g
s/『A-VPM-PG』/Adjective, Vocative, Plural, Masculine, Person Gentilic/g
s/『A-VPM』/Adjective, Vocative, Plural, Masculine/g
s/『A-VPN』/Adjective, Vocative, Plural, Neuter/g
s/『A-VSF』/Adjective, Vocative, Singular, Feminine/g
s/『A-VSM-S』/Adjective, Vocative, Singular, Masculine, Superlative/g
s/『A-VSM』/Adjective, Vocative, Singular, Masculine/g
s/『A-VSN』/Adjective, Vocative, Singular, Neuter/g
s/『ADV-C』/ADVerb, Contracted form/g
s/『ADV-I』/ADVerb, Interrogative/g
s/『ADV-K』/ADVerb, Kai/g
s/『ADV-N』/ADVerb, Negative/g
s/『ADV-S』/ADVerb, Superlative/g
s/『ADV』/ADVerb or adverb and particle combined/g
s/『ARAM』/ARAMaic transliterated word (indeclinable)/g
s/『C-APM』/reCiprocal pronoun, Accusative, Plural, Masculine/g
s/『C-DPM』/reCiprocal pronoun, Dative, Plural, Masculine/g
s/『C-DPN』/reCiprocal pronoun, Dative, Plural, Neuter/g
s/『C-GPM』/reCiprocal pronoun, Genitive, Plural, Masculine/g
s/『C-GPN』/reCiprocal pronoun, Genitive, Plural, Neuter/g
s/『COND-C』/Contracted form/g
s/『COND-K』/CONDitional particle, Kai/g
s/『COND-P』/Contracted form/g
s/『COND』/CONDitional particle or conjunction/g
s/『CONJ-N』/CONJunction, Negative/g
s/『CONJ』/CONJunction or conjunctive particle/g
s/『D-APF』/Demonstrative pronoun, Accusative, Plural, Feminine/g
s/『D-APM-C』/Demonstrative pronoun, Accusative, Plural, Masculine, Contracted form/g
s/『D-APM-K』/Demonstrative pronoun, Accusative, Plural, Masculine, Kai/g
s/『D-APM』/Demonstrative pronoun, Accusative, Plural, Masculine/g
s/『D-APN-K』/Demonstrative pronoun, Accusative, Plural, Neuter, Kai/g
s/『D-APN』/Demonstrative pronoun, Accusative, Plural, Neuter/g
s/『D-ASF』/Demonstrative pronoun, Accusative, Singular, Feminine/g
s/『D-ASM-C』/Demonstrative pronoun, Accusative, Singular, Masculine, Contracted form/g
s/『D-ASM-K』/Demonstrative pronoun, Accusative, Singular, Masculine, Kai/g
s/『D-ASM』/Demonstrative pronoun, Accusative, Singular, Masculine/g
s/『D-ASN』/Demonstrative pronoun, Accusative, Singular, Neuter/g
s/『D-DPF』/Demonstrative pronoun, Dative, Plural, Feminine/g
s/『D-DPM-C』/Demonstrative pronoun, Dative, Plural, Masculine, Contracted form/g
s/『D-DPM』/Demonstrative pronoun, Dative, Plural, Masculine/g
s/『D-DPN』/Demonstrative pronoun, Dative, Plural, Neuter/g
s/『D-DSF』/Demonstrative pronoun, Dative, Singular, Feminine/g
s/『D-DSM』/Demonstrative pronoun, Dative, Singular, Masculine/g
s/『D-DSN』/Demonstrative pronoun, Dative, Singular, Neuter/g
s/『D-GPF』/Demonstrative pronoun, Genitive, Plural, Feminine/g
s/『D-GPM』/Demonstrative pronoun, Genitive, Plural, Masculine/g
s/『D-GPN』/Demonstrative pronoun, Genitive, Plural, Neuter/g
s/『D-GSF』/Demonstrative pronoun, Genitive, Singular, Feminine/g
s/『D-GSM』/Demonstrative pronoun, Genitive, Singular, Masculine/g
s/『D-GSN』/Demonstrative pronoun, Genitive, Singular, Neuter/g
s/『D-NPF』/Demonstrative pronoun, Nominative, Plural, Feminine/g
s/『D-NPM-C』/Demonstrative pronoun, Nominative, Plural, Masculine, Contracted form/g
s/『D-NPM-K』/Demonstrative pronoun, Nominative, Plural, Masculine, Kai/g
s/『D-NPM』/Demonstrative pronoun, Nominative, Plural, Masculine/g
s/『D-NPN-C』/Demonstrative pronoun, Nominative, Plural, Neuter, Contracted form/g
s/『D-NPN-K』/Demonstrative pronoun, Nominative, Plural, Neuter, Kai/g
s/『D-NPN』/Demonstrative pronoun, Nominative, Plural, Neuter/g
s/『D-NSF』/Demonstrative pronoun, Nominative, Singular, Feminine/g
s/『D-NSM-C』/Demonstrative pronoun, Nominative, Singular, Masculine, Contracted form/g
s/『D-NSM-K』/Demonstrative pronoun, Nominative, Singular, Masculine, Kai/g
s/『D-NSM』/Demonstrative pronoun, Nominative, Singular, Masculine/g
s/『D-NSN』/Demonstrative pronoun, Nominative, Singular, Neuter/g
s/『F-1APM』/reFlexive pronoun, first, Accusative, Plural, Masculine/g
s/『F-1ASM』/reFlexive pronoun, first, Accusative, Singular, Masculine/g
s/『F-1DPM』/reFlexive pronoun, first, Dative, Plural, Masculine/g
s/『F-1DSM』/reFlexive pronoun, first, Dative, Singular, Masculine/g
s/『F-1GPM』/reFlexive pronoun, first, Genitive, Plural, Masculine/g
s/『F-1GSM』/reFlexive pronoun, first, Genitive, Singular, Masculine/g
s/『F-2APF』/reFlexive pronoun, second, Accusative, Plural, Feminine/g
s/『F-2APM』/reFlexive pronoun, second, Accusative, Plural, Masculine/g
s/『F-2APN』/reFlexive pronoun, second, Accusative, Plural, Neuter/g
s/『F-2ASM-C』/reFlexive pronoun, second, Accusative, Singular, Masculine, Contracted form/g
s/『F-2ASM』/reFlexive pronoun, second, Accusative, Singular, Masculine/g
s/『F-2DPF』/reFlexive pronoun, second, Dative, Plural, Feminine/g
s/『F-2DPM』/reFlexive pronoun, second, Dative, Plural, Masculine/g
s/『F-2DSM』/reFlexive pronoun, second, Dative, Singular, Masculine/g
s/『F-2GPM』/reFlexive pronoun, second, Genitive, Plural, Masculine/g
s/『F-2GSM』/reFlexive pronoun, second, Genitive, Singular, Masculine/g
s/『F-3APF』/reFlexive pronoun, third, Accusative, Plural, Feminine/g
s/『F-3APM』/reFlexive pronoun, third, Accusative, Plural, Masculine/g
s/『F-3APN』/reFlexive pronoun, third, Accusative, Plural, Neuter/g
s/『F-3ASF』/reFlexive pronoun, third, Accusative, Singular, Feminine/g
s/『F-3ASM』/reFlexive pronoun, third, Accusative, Singular, Masculine/g
s/『F-3ASN』/reFlexive pronoun, third, Accusative, Singular, Neuter/g
s/『F-3DPF』/reFlexive pronoun, third, Dative, Plural, Feminine/g
s/『F-3DPM』/reFlexive pronoun, third, Dative, Plural, Masculine/g
s/『F-3DSF』/reFlexive pronoun, third, Dative, Singular, Feminine/g
s/『F-3DSM』/reFlexive pronoun, third, Dative, Singular, Masculine/g
s/『F-3GPF』/reFlexive pronoun, third, Genitive, Plural, Feminine/g
s/『F-3GPM』/reFlexive pronoun, third, Genitive, Plural, Masculine/g
s/『F-3GPN』/reFlexive pronoun, third, Genitive, Plural, Neuter/g
s/『F-3GSF』/reFlexive pronoun, third, Genitive, Singular, Feminine/g
s/『F-3GSM』/reFlexive pronoun, third, Genitive, Singular, Masculine/g
s/『F-3GSN』/reFlexive pronoun, third, Genitive, Singular, Neuter/g
s/『F-3NSM』/reFlexive pronoun, third, Nominative, Singular, Masculine/g
s/『F-GPF』/reFlexive pronoun, Genitive, Plural, Feminine/g
s/『HEB-T』/HEBrew, Title/g
s/『HEB』/HEBrew transliterated word (indeclinable)/g
s/『I-APF』/Interrogative pronoun, Accusative, Plural, Feminine/g
s/『I-APM』/Interrogative pronoun, Accusative, Plural, Masculine/g
s/『I-APN』/Interrogative pronoun, Accusative, Plural, Neuter/g
s/『I-ASF』/Interrogative pronoun, Accusative, Singular, Feminine/g
s/『I-ASM』/Interrogative pronoun, Accusative, Singular, Masculine/g
s/『I-ASN』/Interrogative pronoun, Accusative, Singular, Neuter/g
s/『I-DPM』/Interrogative pronoun, Dative, Plural, Masculine/g
s/『I-DPN』/Interrogative pronoun, Dative, Plural, Neuter/g
s/『I-DSF』/Interrogative pronoun, Dative, Singular, Feminine/g
s/『I-DSM』/Interrogative pronoun, Dative, Singular, Masculine/g
s/『I-DSN』/Interrogative pronoun, Dative, Singular, Neuter/g
s/『I-GPM』/Interrogative pronoun, Genitive, Plural, Masculine/g
s/『I-GPN』/Interrogative pronoun, Genitive, Plural, Neuter/g
s/『I-GSF』/Interrogative pronoun, Genitive, Singular, Feminine/g
s/『I-GSM』/Interrogative pronoun, Genitive, Singular, Masculine/g
s/『I-GSN』/Interrogative pronoun, Genitive, Singular, Neuter/g
s/『I-NPF』/Interrogative pronoun, Nominative, Plural, Feminine/g
s/『I-NPM』/Interrogative pronoun, Nominative, Plural, Masculine/g
s/『I-NPN』/Interrogative pronoun, Nominative, Plural, Neuter/g
s/『I-NSF』/Interrogative pronoun, Nominative, Singular, Feminine/g
s/『I-NSM』/Interrogative pronoun, Nominative, Singular, Masculine/g
s/『I-NSN』/Interrogative pronoun, Nominative, Singular, Neuter/g
s/『INJ』/INterJection/g
s/『K-APF』/correlative pronoun, Accusative, Plural, Feminine/g
s/『K-APM』/correlative pronoun, Accusative, Plural, Masculine/g
s/『K-APN』/correlative pronoun, Accusative, Plural, Neuter/g
s/『K-ASM』/correlative pronoun, Accusative, Singular, Masculine/g
s/『K-ASN』/correlative pronoun, Accusative, Singular, Neuter/g
s/『K-DSN』/correlative pronoun, Dative, Singular, Neuter/g
s/『K-GPM』/correlative pronoun, Genitive, Plural, Masculine/g
s/『K-GSN』/correlative pronoun, Genitive, Singular, Neuter/g
s/『K-NPF』/correlative pronoun, Nominative, Plural, Feminine/g
s/『K-NPM』/correlative pronoun, Nominative, Plural, Masculine/g
s/『K-NPN』/correlative pronoun, Nominative, Plural, Neuter/g
s/『K-NSF』/correlative pronoun, Nominative, Singular, Feminine/g
s/『K-NSM』/correlative pronoun, Nominative, Singular, Masculine/g
s/『K-NSN』/correlative pronoun, Nominative, Singular, Neuter/g
s/『N-APF-C』/Noun, Accusative, Plural, Feminine, Contracted form/g
s/『N-APF-L』/Noun, Accusative, Plural, Feminine, Location/g
s/『N-APF-S』/Noun, Accusative, Plural, Feminine, Superlative/g
s/『N-APF』/Noun, Accusative, Plural, Feminine/g
s/『N-APM-L』/Noun, Accusative, Plural, Masculine, Location/g
s/『N-APM-LG』/Noun, Accusative, Plural, Masculine, Location Gentilic/g
s/『N-APM-P』/Noun, Accusative, Plural, Masculine, Person/g
s/『N-APM-PG』/Noun, Accusative, Plural, Masculine, Person Gentilic/g
s/『N-APM-T』/Noun, Accusative, Plural, Masculine, Title/g
s/『N-APM』/Noun, Accusative, Plural, Masculine/g
s/『N-APN-C』/Noun, Accusative, Plural, Neuter, Contracted form/g
s/『N-APN-L』/Noun, Accusative, Plural, Neuter, Location/g
s/『N-APN-S』/Noun, Accusative, Plural, Neuter, Superlative/g
s/『N-APN』/Noun, Accusative, Plural, Neuter/g
s/『N-ASF-C』/Noun, Accusative, Singular, Feminine, Contracted form/g
s/『N-ASF-L』/Noun, Accusative, Singular, Feminine, Location/g
s/『N-ASF-P』/Noun, Accusative, Singular, Feminine, Person/g
s/『N-ASF-S』/Noun, Accusative, Singular, Feminine, Superlative/g
s/『N-ASF-T』/Noun, Accusative, Singular, Feminine, Title/g
s/『N-ASF』/Noun, Accusative, Singular, Feminine/g
s/『N-ASM-L』/Noun, Accusative, Singular, Masculine, Location/g
s/『N-ASM-LG』/Noun, Accusative, Singular, Masculine, Location Gentilic/g
s/『N-ASM-P』/Noun, Accusative, Singular, Masculine, Person/g
s/『N-ASM-S』/Noun, Accusative, Singular, Masculine, Superlative/g
s/『N-ASM-T』/Noun, Accusative, Singular, Masculine, Title/g
s/『N-ASM』/Noun, Accusative, Singular, Masculine/g
s/『N-ASN-L』/Noun, Accusative, Singular, Neuter, Location/g
s/『N-ASN』/Noun, Accusative, Singular, Neuter/g
s/『N-DPF-L』/Noun, Dative, Plural, Feminine, Location/g
s/『N-DPF』/Noun, Dative, Plural, Feminine/g
s/『N-DPM-L』/Noun, Dative, Plural, Masculine, Location/g
s/『N-DPM-LG』/Noun, Dative, Plural, Masculine, Location Gentilic/g
s/『N-DPM-S』/Noun, Dative, Plural, Masculine, Superlative/g
s/『N-DPM-T』/Noun, Dative, Plural, Masculine, Title/g
s/『N-DPM』/Noun, Dative, Plural, Masculine/g
s/『N-DPN-L』/Noun, Dative, Plural, Neuter, Location/g
s/『N-DPN』/Noun, Dative, Plural, Neuter/g
s/『N-DSF-L』/Noun, Dative, Singular, Feminine, Location/g
s/『N-DSF-LG』/Noun, Dative, Singular, Feminine, Location Gentilic/g
s/『N-DSF-P』/Noun, Dative, Singular, Feminine, Person/g
s/『N-DSF-T』/Noun, Dative, Singular, Feminine, Title/g
s/『N-DSF』/Noun, Dative, Singular, Feminine/g
s/『N-DSM-L』/Noun, Dative, Singular, Masculine, Location/g
s/『N-DSM-LG』/Noun, Dative, Singular, Masculine, Location Gentilic/g
s/『N-DSM-P』/Noun, Dative, Singular, Masculine, Person/g
s/『N-DSM-T』/Noun, Dative, Singular, Masculine, Title/g
s/『N-DSM』/Noun, Dative, Singular, Masculine/g
s/『N-DSN-L』/Noun, Dative, Singular, Neuter, Location/g
s/『N-DSN』/Noun, Dative, Singular, Neuter/g
s/『N-GMP』/Noun, Genitive, Masculine, Particle attached/g
s/『N-GPF-L』/Noun, Genitive, Plural, Feminine, Location/g
s/『N-GPF-LG』/Noun, Genitive, Plural, Feminine, Location Gentilic/g
s/『N-GPF』/Noun, Genitive, Plural, Feminine/g
s/『N-GPM-L』/Noun, Genitive, Plural, Masculine, Location/g
s/『N-GPM-LG』/Noun, Genitive, Plural, Masculine, Location Gentilic/g
s/『N-GPM-PG』/Noun, Genitive, Plural, Masculine, Person Gentilic/g
s/『N-GPM-T』/Noun, Genitive, Plural, Masculine, Title/g
s/『N-GPM』/Noun, Genitive, Plural, Masculine/g
s/『N-GPN-L』/Noun, Genitive, Plural, Neuter, Location/g
s/『N-GPN』/Noun, Genitive, Plural, Neuter/g
s/『N-GSF-L』/Noun, Genitive, Singular, Feminine, Location/g
s/『N-GSF-LG』/Noun, Genitive, Singular, Feminine, Location Gentilic/g
s/『N-GSF-P』/Noun, Genitive, Singular, Feminine, Person/g
s/『N-GSF-T』/Noun, Genitive, Singular, Feminine, Title/g
s/『N-GSF』/Noun, Genitive, Singular, Feminine/g
s/『N-GSM-L』/Noun, Genitive, Singular, Masculine, Location/g
s/『N-GSM-LG』/Noun, Genitive, Singular, Masculine, Location Gentilic/g
s/『N-GSM-P』/Noun, Genitive, Singular, Masculine, Person/g
s/『N-GSM-PG』/Noun, Genitive, Singular, Masculine, Person Gentilic/g
s/『N-GSM-T』/Noun, Genitive, Singular, Masculine, Title/g
s/『N-GSM』/Noun, Genitive, Singular, Masculine/g
s/『N-GSN-L』/Noun, Genitive, Singular, Neuter, Location/g
s/『N-GSN』/Noun, Genitive, Singular, Neuter/g
s/『N-LI』/Indeclinable Letter (Noun)/g
s/『N-NAM』/Noun, Nominative/g
s/『N-NPF』/Noun, Nominative, Plural, Feminine/g
s/『N-NPM-L』/Noun, Nominative, Plural, Masculine, Location/g
s/『N-NPM-LG』/Noun, Nominative, Plural, Masculine, Location Gentilic/g
s/『N-NPM-PG』/Noun, Nominative, Plural, Masculine, Person Gentilic/g
s/『N-NPM-S』/Noun, Nominative, Plural, Masculine, Superlative/g
s/『N-NPM-T』/Noun, Nominative, Plural, Masculine, Title/g
s/『N-NPM』/Noun, Nominative, Plural, Masculine/g
s/『N-NPN-L』/Noun, Nominative, Plural, Neuter, Location/g
s/『N-NPN-T』/Noun, Nominative, Plural, Neuter, Title/g
s/『N-NPN』/Noun, Nominative, Plural, Neuter/g
s/『N-NSF-L』/Noun, Nominative, Singular, Feminine, Location/g
s/『N-NSF-LG』/Noun, Nominative, Singular, Feminine, Location Gentilic/g
s/『N-NSF-P』/Noun, Nominative, Singular, Feminine, Person/g
s/『N-NSF-T』/Noun, Nominative, Singular, Feminine, Title/g
s/『N-NSF』/Noun, Nominative, Singular, Feminine/g
s/『N-NSM-C』/Noun, Nominative, Singular, Masculine, Comparative/g
s/『N-NSM-L』/Noun, Nominative, Singular, Masculine, Location/g
s/『N-NSM-LG』/Noun, Nominative, Singular, Masculine, Location Gentilic/g
s/『N-NSM-P』/Noun, Nominative, Singular, Masculine, Person/g
s/『N-NSM-PG』/Noun, Nominative, Singular, Masculine, Person Gentilic/g
s/『N-NSM-T』/Noun, Nominative, Singular, Masculine, Title/g
s/『N-NSM』/Noun, Nominative, Singular, Masculine/g
s/『N-NSN-C』/Noun, Nominative, Singular, Neuter, Contracted form/g
s/『N-NSN-L』/Noun, Nominative, Singular, Neuter, Location/g
s/『N-NSN-LI』/Noun, Nominative, Singular, Neuter, Letter Indeclinable (N)/g
s/『N-NSN-T』/Noun, Nominative, Singular, Neuter, Title/g
s/『N-NSN』/Noun, Nominative, Singular, Neuter/g
s/『N-OI』/Indeclinable Noun of Other type/g
s/『N-PRI』/Indeclinable PRoper Noun/g
s/『N-VPF』/Noun, Vocative, Plural, Feminine/g
s/『N-VPM-LG』/Noun, Vocative, Plural, Masculine, Location Gentilic/g
s/『N-VPM-PG』/Noun, Vocative, Plural, Masculine, Person Gentilic/g
s/『N-VPM-T』/Noun, Vocative, Plural, Masculine, Title/g
s/『N-VPM』/Noun, Vocative, Plural, Masculine/g
s/『N-VPN』/Noun, Vocative, Plural, Neuter/g
s/『N-VSF-L』/Noun, Vocative, Singular, Feminine, Location/g
s/『N-VSF-P』/Noun, Vocative, Singular, Feminine, Person/g
s/『N-VSF』/Noun, Vocative, Singular, Feminine/g
s/『N-VSM-L』/Noun, Vocative, Singular, Masculine, Location/g
s/『N-VSM-P』/Noun, Vocative, Singular, Masculine, Person/g
s/『N-VSM-T』/Noun, Vocative, Singular, Masculine, Title/g
s/『N-VSM』/Noun, Vocative, Singular, Masculine/g
s/『N-VSN』/Noun, Vocative, Singular, Neuter/g
s/『P-1AP』/Personal pronoun, first, Accusative, Plural/g
s/『P-1AS-C』/Personal pronoun, first, Accusative, Singular, Contracted form/g
s/『P-1AS-K』/Personal pronoun, first, Accusative, Singular, Kai/g
s/『P-1AS』/Personal pronoun, first, Accusative, Singular/g
s/『P-1DP』/Personal pronoun, first, Dative, Plural/g
s/『P-1DS-C』/Personal pronoun, first, Dative, Singular, Contracted form/g
s/『P-1DS-K』/Personal pronoun, first, Dative, Singular, Kai/g
s/『P-1DS』/Personal pronoun, first, Dative, Singular/g
s/『P-1GP』/Personal pronoun, first, Genitive, Plural/g
s/『P-1GS』/Personal pronoun, first, Genitive, Singular/g
s/『P-1NP』/Personal pronoun, first, Nominative, Plural/g
s/『P-1NS-C』/Personal pronoun, first, Nominative, Singular, Contracted form/g
s/『P-1NS-K』/Personal pronoun, first, Nominative, Singular, Kai/g
s/『P-1NS』/Personal pronoun, first, Nominative, Singular/g
s/『P-2AP』/Personal pronoun, second, Accusative, Plural/g
s/『P-2AS』/Personal pronoun, second, Accusative, Singular/g
s/『P-2DP』/Personal pronoun, second, Dative, Plural/g
s/『P-2DS』/Personal pronoun, second, Dative, Singular/g
s/『P-2GP』/Personal pronoun, second, Genitive, Plural/g
s/『P-2GS』/Personal pronoun, second, Genitive, Singular/g
s/『P-2NP』/Personal pronoun, second, Nominative, Plural/g
s/『P-2NS』/Personal pronoun, second, Nominative, Singular/g
s/『P-APF』/Personal pronoun, Accusative, Plural, Feminine/g
s/『P-APM』/Personal pronoun, Accusative, Plural, Masculine/g
s/『P-APN』/Personal pronoun, Accusative, Plural, Neuter/g
s/『P-ASF』/Personal pronoun, Accusative, Singular, Feminine/g
s/『P-ASM』/Personal pronoun, Accusative, Singular, Masculine/g
s/『P-ASN』/Personal pronoun, Accusative, Singular, Neuter/g
s/『P-DPF』/Personal pronoun, Dative, Plural, Feminine/g
s/『P-DPM』/Personal pronoun, Dative, Plural, Masculine/g
s/『P-DPN』/Personal pronoun, Dative, Plural, Neuter/g
s/『P-DSF』/Personal pronoun, Dative, Singular, Feminine/g
s/『P-DSM』/Personal pronoun, Dative, Singular, Masculine/g
s/『P-DSN』/Personal pronoun, Dative, Singular, Neuter/g
s/『P-GPF』/Personal pronoun, Genitive, Plural, Feminine/g
s/『P-GPM』/Personal pronoun, Genitive, Plural, Masculine/g
s/『P-GPN』/Personal pronoun, Genitive, Plural, Neuter/g
s/『P-GSF』/Personal pronoun, Genitive, Singular, Feminine/g
s/『P-GSM』/Personal pronoun, Genitive, Singular, Masculine/g
s/『P-GSN』/Personal pronoun, Genitive, Singular, Neuter/g
s/『P-NPM』/Personal pronoun, Nominative, Plural, Masculine/g
s/『P-NPN』/Personal pronoun, Nominative, Plural, Neuter/g
s/『P-NSF』/Personal pronoun, Nominative, Singular, Feminine/g
s/『P-NSM』/Personal pronoun, Nominative, Singular, Masculine/g
s/『P-NSN』/Personal pronoun, Nominative, Singular, Neuter/g
s/『PREP』/PREPosition/g
s/『PRT-I』/PaRTicle, Interrogative/g
s/『PRT-N』/PaRTicle, Negative/g
s/『PRT』/PaRTicle, disjunctive particle/g
s/『Q-APF』/correlative or interrogative pronoun, Accusative, Plural, Feminine/g
s/『Q-APM』/correlative or interrogative pronoun, Accusative, Plural, Masculine/g
s/『Q-APN』/correlative or interrogative pronoun, Accusative, Plural, Neuter/g
s/『Q-ASF』/correlative or interrogative pronoun, Accusative, Singular, Feminine/g
s/『Q-ASN』/correlative or interrogative pronoun, Accusative, Singular, Neuter/g
s/『Q-DSN』/correlative or interrogative pronoun, Dative, Singular, Neuter/g
s/『Q-GPF』/correlative or interrogative pronoun, Genitive, Plural, Feminine/g
s/『Q-GPN』/correlative or interrogative pronoun, Genitive, Plural, Neuter/g
s/『Q-NPF』/correlative or interrogative pronoun, Nominative, Plural, Feminine/g
s/『Q-NPM』/correlative or interrogative pronoun, Nominative, Plural, Masculine/g
s/『Q-NSM』/correlative or interrogative pronoun, Nominative, Singular, Masculine/g
s/『Q-NSN』/correlative or interrogative pronoun, Nominative, Singular, Neuter/g
s/『R-APF』/Relative pronoun, Accusative, Plural, Feminine/g
s/『R-APM』/Relative pronoun, Accusative, Plural, Masculine/g
s/『R-APN』/Relative pronoun, Accusative, Plural, Neuter/g
s/『R-ASF』/Relative pronoun, Accusative, Singular, Feminine/g
s/『R-ASM-P』/Relative pronoun, Accusative, Singular, Masculine, Particle attached/g
s/『R-ASM』/Relative pronoun, Accusative, Singular, Masculine/g
s/『R-ASN』/Relative pronoun, Accusative, Singular, Neuter/g
s/『R-DPF』/Relative pronoun, Dative, Plural, Feminine/g
s/『R-DPM』/Relative pronoun, Dative, Plural, Masculine/g
s/『R-DPN』/Relative pronoun, Dative, Plural, Neuter/g
s/『R-DSF』/Relative pronoun, Dative, Singular, Feminine/g
s/『R-DSM』/Relative pronoun, Dative, Singular, Masculine/g
s/『R-DSN』/Relative pronoun, Dative, Singular, Neuter/g
s/『R-GPF』/Relative pronoun, Genitive, Plural, Feminine/g
s/『R-GPM』/Relative pronoun, Genitive, Plural, Masculine/g
s/『R-GPN』/Relative pronoun, Genitive, Plural, Neuter/g
s/『R-GSF』/Relative pronoun, Genitive, Singular, Feminine/g
s/『R-GSM』/Relative pronoun, Genitive, Singular, Masculine/g
s/『R-GSN-ATT』/Relative pronoun, Genitive, Singular, Neuter, ATTic Greek form/g
s/『R-GSN』/Relative pronoun, Genitive, Singular, Neuter/g
s/『R-NPF』/Relative pronoun, Nominative, Plural, Feminine/g
s/『R-NPM』/Relative pronoun, Nominative, Plural, Masculine/g
s/『R-NPN』/Relative pronoun, Nominative, Plural, Neuter/g
s/『R-NSF』/Relative pronoun, Nominative, Singular, Feminine/g
s/『R-NSM』/Relative pronoun, Nominative, Singular, Masculine/g
s/『R-NSN』/Relative pronoun, Nominative, Singular, Neuter/g
s/『S-1APF』/poSessive pronoun, first, Accusative, Plural, Feminine/g
s/『S-1APM』/poSessive pronoun, first, Accusative, Plural, Masculine/g
s/『S-1APN』/poSessive pronoun, first, Accusative, Plural, Neuter/g
s/『S-1ASF』/poSessive pronoun, first, Accusative, Singular, Feminine/g
s/『S-1ASM』/poSessive pronoun, first, Accusative, Singular, Masculine/g
s/『S-1ASN』/poSessive pronoun, first, Accusative, Singular, Neuter/g
s/『S-1DPF』/poSessive pronoun, first, Dative, Plural, Feminine/g
s/『S-1DPM』/poSessive pronoun, first, Dative, Plural, Masculine/g
s/『S-1DPN』/poSessive pronoun, first, Dative, Plural, Neuter/g
s/『S-1DSF』/poSessive pronoun, first, Dative, Singular, Feminine/g
s/『S-1DSM』/poSessive pronoun, first, Dative, Singular, Masculine/g
s/『S-1DSN』/poSessive pronoun, first, Dative, Singular, Neuter/g
s/『S-1GPF』/poSessive pronoun, first, Genitive, Plural, Feminine/g
s/『S-1GPN』/poSessive pronoun, first, Genitive, Plural, Neuter/g
s/『S-1GSF』/poSessive pronoun, first, Genitive, Singular, Feminine/g
s/『S-1NPF』/poSessive pronoun, first, Nominative, Plural, Feminine/g
s/『S-1NPM』/poSessive pronoun, first, Nominative, Plural, Masculine/g
s/『S-1NPN』/poSessive pronoun, first, Nominative, Plural, Neuter/g
s/『S-1NSF』/poSessive pronoun, first, Nominative, Singular, Feminine/g
s/『S-1NSM』/poSessive pronoun, first, Nominative, Singular, Masculine/g
s/『S-1NSN』/poSessive pronoun, first, Nominative, Singular, Neuter/g
s/『S-1PASF』/poSsessive pronoun, first, Plural, Accusative, Singular, Feminine/g
s/『S-1PASN』/poSsessive pronoun, first, Plural, Accusative, Singular, Neuter/g
s/『S-1PDPF』/poSsessive pronoun, first, Plural, Dative, Plural, Feminine/g
s/『S-1PDPM』/poSsessive pronoun, first, Plural, Dative, Plural, Masculine/g
s/『S-1PGPF』/poSsessive pronoun, first, Plural, Genitive, Plural, Feminine/g
s/『S-1PGSF』/poSsessive pronoun, first, Plural, Genitive, Singular, Feminine/g
s/『S-1PNPM』/poSsessive pronoun, first, Plural, Nominative, Plural, Masculine/g
s/『S-1PNSF』/poSsessive pronoun, first, Plural, Nominative, Singular, Feminine/g
s/『S-1SAPF』/poSsessive pronoun, first, Singular, Accusative, Plural, Feminine/g
s/『S-1SAPM』/poSsessive pronoun, first, Singular, Accusative, Plural, Masculine/g
s/『S-1SAPN』/poSsessive pronoun, first, Singular, Accusative, Plural, Neuter/g
s/『S-1SASF』/poSsessive pronoun, first, Singular, Accusative, Singular, Feminine/g
s/『S-1SASM』/poSsessive pronoun, first, Singular, Accusative, Singular, Masculine/g
s/『S-1SASN』/poSsessive pronoun, first, Singular, Accusative, Singular, Neuter/g
s/『S-1SDPN』/poSsessive pronoun, first, Singular, Dative, Plural, Neuter/g
s/『S-1SDSF』/poSsessive pronoun, first, Singular, Dative, Singular, Feminine/g
s/『S-1SDSM』/poSsessive pronoun, first, Singular, Dative, Singular, Masculine/g
s/『S-1SDSN』/poSsessive pronoun, first, Singular, Dative, Singular, Neuter/g
s/『S-1SGPN』/poSsessive pronoun, first, Singular, Genitive, Plural, Neuter/g
s/『S-1SGSF』/poSsessive pronoun, first, Singular, Genitive, Singular, Feminine/g
s/『S-1SGSN』/poSsessive pronoun, first, Singular, Genitive, Singular, Neuter/g
s/『S-1SNPM』/poSsessive pronoun, first, Singular, Nominative, Plural, Masculine/g
s/『S-1SNPN』/poSsessive pronoun, first, Singular, Nominative, Plural, Neuter/g
s/『S-1SNSF』/poSsessive pronoun, first, Singular, Nominative, Singular, Feminine/g
s/『S-1SNSM』/poSsessive pronoun, first, Singular, Nominative, Singular, Masculine/g
s/『S-1SNSN』/poSsessive pronoun, first, Singular, Nominative, Singular, Neuter/g
s/『S-2APF』/poSessive pronoun, second, Accusative, Plural, Feminine/g
s/『S-2APM』/poSessive pronoun, second, Accusative, Plural, Masculine/g
s/『S-2APN』/poSessive pronoun, second, Accusative, Plural, Neuter/g
s/『S-2ASF』/poSessive pronoun, second, Accusative, Singular, Feminine/g
s/『S-2ASN』/poSessive pronoun, second, Accusative, Singular, Neuter/g
s/『S-2DPF』/poSessive pronoun, second, Dative, Plural, Feminine/g
s/『S-2DPM』/poSessive pronoun, second, Dative, Plural, Masculine/g
s/『S-2DSF』/poSessive pronoun, second, Dative, Singular, Feminine/g
s/『S-2DSM』/poSessive pronoun, second, Dative, Singular, Masculine/g
s/『S-2GPF』/poSessive pronoun, second, Genitive, Plural, Feminine/g
s/『S-2GSF』/poSessive pronoun, second, Genitive, Singular, Feminine/g
s/『S-2NPF』/poSessive pronoun, second, Nominative, Plural, Feminine/g
s/『S-2NPM』/poSessive pronoun, second, Nominative, Plural, Masculine/g
s/『S-2NPN』/poSessive pronoun, second, Nominative, Plural, Neuter/g
s/『S-2NSM』/poSessive pronoun, second, Nominative, Singular, Masculine/g
s/『S-2NSN』/poSessive pronoun, second, Nominative, Singular, Neuter/g
s/『S-2PASF』/poSsessive pronoun, second, Plural, Accusative, Singular, Feminine/g
s/『S-2PASM』/poSsessive pronoun, second, Plural, Accusative, Singular, Masculine/g
s/『S-2PASN』/poSsessive pronoun, second, Plural, Accusative, Singular, Neuter/g
s/『S-2PDSF』/poSsessive pronoun, second, Plural, Dative, Singular, Feminine/g
s/『S-2PDSM』/poSsessive pronoun, second, Plural, Dative, Singular, Masculine/g
s/『S-2PDSN』/poSsessive pronoun, second, Plural, Dative, Singular, Neuter/g
s/『S-2PGSF』/poSsessive pronoun, second, Plural, Genitive, Singular, Feminine/g
s/『S-2PNSF』/poSsessive pronoun, second, Plural, Nominative, Singular, Feminine/g
s/『S-2PNSM』/poSsessive pronoun, second, Plural, Nominative, Singular, Masculine/g
s/『S-2SAPM』/poSsessive pronoun, second, Singular, Accusative, Plural, Masculine/g
s/『S-2SAPN』/poSsessive pronoun, second, Singular, Accusative, Plural, Neuter/g
s/『S-2SASF』/poSsessive pronoun, second, Singular, Accusative, Singular, Feminine/g
s/『S-2SASN』/poSsessive pronoun, second, Singular, Accusative, Singular, Neuter/g
s/『S-2SDSF』/poSsessive pronoun, second, Singular, Dative, Singular, Feminine/g
s/『S-2SDSM』/poSsessive pronoun, second, Singular, Dative, Singular, Masculine/g
s/『S-2SDSN』/poSsessive pronoun, second, Singular, Dative, Singular, Neuter/g
s/『S-2SGSF』/poSsessive pronoun, second, Singular, Genitive, Singular, Feminine/g
s/『S-2SNPM』/poSsessive pronoun, second, Singular, Nominative, Plural, Masculine/g
s/『S-2SNPN』/poSsessive pronoun, second, Singular, Nominative, Plural, Neuter/g
s/『S-2SNSM』/poSsessive pronoun, second, Singular, Nominative, Singular, Masculine/g
s/『S-2SNSN』/poSsessive pronoun, second, Singular, Nominative, Singular, Neuter/g
s/『T-APF』/definite article, Accusative, Plural, Feminine/g
s/『T-APM』/definite article, Accusative, Plural, Masculine/g
s/『T-APN』/definite article, Accusative, Plural, Neuter/g
s/『T-ASF』/definite article, Accusative, Singular, Feminine/g
s/『T-ASM』/definite article, Accusative, Singular, Masculine/g
s/『T-ASN』/definite article, Accusative, Singular, Neuter/g
s/『T-DPF』/definite article, Dative, Plural, Feminine/g
s/『T-DPM』/definite article, Dative, Plural, Masculine/g
s/『T-DPN』/definite article, Dative, Plural, Neuter/g
s/『T-DSF』/definite article, Dative, Singular, Feminine/g
s/『T-DSM』/definite article, Dative, Singular, Masculine/g
s/『T-DSN』/definite article, Dative, Singular, Neuter/g
s/『T-GPF』/definite article, Genitive, Plural, Feminine/g
s/『T-GPM』/definite article, Genitive, Plural, Masculine/g
s/『T-GPN』/definite article, Genitive, Plural, Neuter/g
s/『T-GSF』/definite article, Genitive, Singular, Feminine/g
s/『T-GSM』/definite article, Genitive, Singular, Masculine/g
s/『T-GSN』/definite article, Genitive, Singular, Neuter/g
s/『T-NPF』/definite article, Nominative, Plural, Feminine/g
s/『T-NPM』/definite article, Nominative, Plural, Masculine/g
s/『T-NPN』/definite article, Nominative, Plural, Neuter/g
s/『T-NSF』/definite article, Nominative, Singular, Feminine/g
s/『T-NSM』/definite article, Nominative, Singular, Masculine/g
s/『T-NSN』/definite article, Nominative, Singular, Neuter/g
s/『T-VPF』/definite article, Vocative, Plural, Feminine/g
s/『T-VPM』/definite article, Vocative, Plural, Masculine/g
s/『T-VPN』/definite article, Vocative, Plural, Neuter/g
s/『T-VSF』/definite article, Vocative, Singular, Feminine/g
s/『T-VSM』/definite article, Vocative, Singular, Masculine/g
s/『T-VSN』/definite article, Vocative, Singular, Neuter/g
s/『V-2AAI-1P』/Verb, second Aorist, Active, Indicative, first, Plural/g
s/『V-2AAI-1S』/Verb, second Aorist, Active, Indicative, first, Singular/g
s/『V-2AAI-2P』/Verb, second Aorist, Active, Indicative, second, Plural/g
s/『V-2AAI-2S』/Verb, second Aorist, Active, Indicative, second, Singular/g
s/『V-2AAI-3P-ATT』/Verb, second Aorist, Active, Indicative, third, Plural, ATTic form/g
s/『V-2AAI-3P』/Verb, second Aorist, Active, Indicative, third, Plural/g
s/『V-2AAI-3S』/Verb, second Aorist, Active, Indicative, third, Singular/g
s/『V-2AAM-2P』/Verb, second Aorist, Active, iMperative, second, Plural/g
s/『V-2AAM-2S-AP』/Verb, second Aorist, Active, iMperative, second, Singular, Apocopated form/g
s/『V-2AAM-2S-ATT』/Verb, second Aorist, Active, iMperative, second, Singular, ATTic form/g
s/『V-2AAM-2S』/Verb, second Aorist, Active, iMperative, second, Singular/g
s/『V-2AAM-3P』/Verb, second Aorist, Active, iMperative, third, Plural/g
s/『V-2AAM-3S』/Verb, second Aorist, Active, iMperative, third, Singular/g
s/『V-2AAN』/Verb, second Aorist, Active, iNfinitive/g
s/『V-2AAO-3P』/Verb, second Aorist, Active, Optative, third, Plural/g
s/『V-2AAO-3S』/Verb, second Aorist, Active, Optative, third, Singular/g
s/『V-2AAP-APF』/Verb, second Aorist, Active, Participle, Accusative, Plural, Feminine/g
s/『V-2AAP-APM』/Verb, second Aorist, Active, Participle, Accusative, Plural, Masculine/g
s/『V-2AAP-ASF』/Verb, second Aorist, Active, Participle, Accusative, Singular, Feminine/g
s/『V-2AAP-ASM』/Verb, second Aorist, Active, Participle, Accusative, Singular, Masculine/g
s/『V-2AAP-ASN』/Verb, second Aorist, Active, Participle, Accusative, Singular, Neuter/g
s/『V-2AAP-DPF』/Verb, second Aorist, Active, Participle, Dative, Plural, Feminine/g
s/『V-2AAP-DPM』/Verb, second Aorist, Active, Participle, Dative, Plural, Masculine/g
s/『V-2AAP-DSF』/Verb, second Aorist, Active, Participle, Dative, Singular, Feminine/g
s/『V-2AAP-DSM』/Verb, second Aorist, Active, Participle, Dative, Singular, Masculine/g
s/『V-2AAP-GPM』/Verb, second Aorist, Active, Participle, Genitive, Plural, Masculine/g
s/『V-2AAP-GSF』/Verb, second Aorist, Active, Participle, Genitive, Singular, Feminine/g
s/『V-2AAP-GSM』/Verb, second Aorist, Active, Participle, Genitive, Singular, Masculine/g
s/『V-2AAP-GSN』/Verb, second Aorist, Active, Participle, Genitive, Singular, Neuter/g
s/『V-2AAP-NPF』/Verb, second Aorist, Active, Participle, Nominative, Plural, Feminine/g
s/『V-2AAP-NPM』/Verb, second Aorist, Active, Participle, Nominative, Plural, Masculine/g
s/『V-2AAP-NPN』/Verb, second Aorist, Active, Participle, Nominative, Plural, Neuter/g
s/『V-2AAP-NSF』/Verb, second Aorist, Active, Participle, Nominative, Singular, Feminine/g
s/『V-2AAP-NSM』/Verb, second Aorist, Active, Participle, Nominative, Singular, Masculine/g
s/『V-2AAP-NSN』/Verb, second Aorist, Active, Participle, Nominative, Singular, Neuter/g
s/『V-2AAS-1P』/Verb, second Aorist, Active, Subjunctive, first, Plural/g
s/『V-2AAS-1S』/Verb, second Aorist, Active, Subjunctive, first, Singular/g
s/『V-2AAS-2P』/Verb, second Aorist, Active, Subjunctive, second, Plural/g
s/『V-2AAS-2S』/Verb, second Aorist, Active, Subjunctive, second, Singular/g
s/『V-2AAS-3P』/Verb, second Aorist, Active, Subjunctive, third, Plural/g
s/『V-2AAS-3S』/Verb, second Aorist, Active, Subjunctive, third, Singular/g
s/『V-2ADI-1S』/Verb, second Aorist, middle Deponent, Indicative, first, Singular/g
s/『V-2ADI-2P』/Verb, second Aorist, middle Deponent, Indicative, second, Plural/g
s/『V-2ADI-2S』/Verb, second Aorist, middle Deponent, Indicative, second, Singular/g
s/『V-2ADI-3P』/Verb, second Aorist, middle Deponent, Indicative, third, Plural/g
s/『V-2ADI-3S』/Verb, second Aorist, middle Deponent, Indicative, third, Singular/g
s/『V-2ADM-2P』/Verb, second Aorist, middle Deponent, iMperative, second, Plural/g
s/『V-2ADM-2S』/Verb, second Aorist, middle Deponent, iMperative, second, Singular/g
s/『V-2ADM-3S』/Verb, second Aorist, middle Deponent, iMperative, third, Singular/g
s/『V-2ADN』/Verb, second Aorist, middle Deponent, iNfinitive/g
s/『V-2ADO-1S』/Verb, second Aorist, middle Deponent, Optative, first, Singular/g
s/『V-2ADO-3S』/Verb, second Aorist, middle Deponent, Optative, third, Singular/g
s/『V-2ADP-APM』/Verb, second Aorist, middle Deponent, Participle, Accusative, Plural, Masculine/g
s/『V-2ADP-APN』/Verb, second Aorist, middle Deponent, Participle, Accusative, Plural, Neuter/g
s/『V-2ADP-ASF』/Verb, second Aorist, middle Deponent, Participle, Accusative, Singular, Feminine/g
s/『V-2ADP-ASM』/Verb, second Aorist, middle Deponent, Participle, Accusative, Singular, Masculine/g
s/『V-2ADP-ASN』/Verb, second Aorist, middle Deponent, Participle, Accusative, Singular, Neuter/g
s/『V-2ADP-DPM』/Verb, second Aorist, middle Deponent, Participle, Dative, Plural, Masculine/g
s/『V-2ADP-DPN』/Verb, second Aorist, middle Deponent, Participle, Dative, Plural, Neuter/g
s/『V-2ADP-GPF』/Verb, second Aorist, middle Deponent, Participle, Genitive, Plural, Feminine/g
s/『V-2ADP-GPM』/Verb, second Aorist, middle Deponent, Participle, Genitive, Plural, Masculine/g
s/『V-2ADP-GPN』/Verb, second Aorist, middle Deponent, Participle, Genitive, Plural, Neuter/g
s/『V-2ADP-GSF』/Verb, second Aorist, middle Deponent, Participle, Genitive, Singular, Feminine/g
s/『V-2ADP-GSM』/Verb, second Aorist, middle Deponent, Participle, Genitive, Singular, Masculine/g
s/『V-2ADP-GSN』/Verb, second Aorist, middle Deponent, Participle, Genitive, Singular, Neuter/g
s/『V-2ADP-NPF』/Verb, second Aorist, middle Deponent, Participle, Nominative, Plural, Feminine/g
s/『V-2ADP-NPM』/Verb, second Aorist, middle Deponent, Participle, Nominative, Plural, Masculine/g
s/『V-2ADP-NSM』/Verb, second Aorist, middle Deponent, Participle, Nominative, Singular, Masculine/g
s/『V-2ADS-1P』/Verb, second Aorist, middle Deponent, Subjunctive, first, Plural/g
s/『V-2ADS-1S』/Verb, second Aorist, middle Deponent, Subjunctive, first, Singular/g
s/『V-2ADS-2P』/Verb, second Aorist, middle Deponent, Subjunctive, second, Plural/g
s/『V-2ADS-3P』/Verb, second Aorist, middle Deponent, Subjunctive, third, Plural/g
s/『V-2ADS-3S』/Verb, second Aorist, middle Deponent, Subjunctive, third, Singular/g
s/『V-2AMI-1P』/Verb, second Aorist, Middle, Indicative, first, Plural/g
s/『V-2AMI-1S』/Verb, second Aorist, Middle, Indicative, first, Singular/g
s/『V-2AMI-2P』/Verb, second Aorist, Middle, Indicative, second, Plural/g
s/『V-2AMI-2S』/Verb, second Aorist, Middle, Indicative, second, Singular/g
s/『V-2AMI-3P』/Verb, second Aorist, Middle, Indicative, third, Plural/g
s/『V-2AMI-3S』/Verb, second Aorist, Middle, Indicative, third, Singular/g
s/『V-2AMM-2P』/Verb, second Aorist, Middle, iMperative, second, Plural/g
s/『V-2AMM-2S』/Verb, second Aorist, Middle, iMperative, second, Singular/g
s/『V-2AMN』/Verb, second Aorist, Middle, iNfinitive/g
s/『V-2AMP-GSM』/Verb, second Aorist, Middle, Participle, Genitive, Singular, Masculine/g
s/『V-2AMP-NPM』/Verb, second Aorist, Middle, Participle, Nominative, Plural, Masculine/g
s/『V-2AMP-NSM』/Verb, second Aorist, Middle, Participle, Nominative, Singular, Masculine/g
s/『V-2AMS-1P』/Verb, second Aorist, Middle, Subjunctive, first, Plural/g
s/『V-2AMS-1S』/Verb, second Aorist, Middle, Subjunctive, first, Singular/g
s/『V-2AMS-2S』/Verb, second Aorist, Middle, Subjunctive, second, Singular/g
s/『V-2AMS-3P』/Verb, second Aorist, Middle, Subjunctive, third, Plural/g
s/『V-2AMS-3S』/Verb, second Aorist, Middle, Subjunctive, third, Singular/g
s/『V-2AOI-1P』/Verb, second Aorist, passive depOnent, Indicative, first, Plural/g
s/『V-2AOI-1S』/Verb, second Aorist, passive depOnent, Indicative, first, Singular/g
s/『V-2AOI-2P』/Verb, second Aorist, passive depOnent, Indicative, second, Plural/g
s/『V-2AOI-3P』/Verb, second Aorist, passive depOnent, Indicative, third, Plural/g
s/『V-2AOI-3S』/Verb, second Aorist, passive depOnent, Indicative, third, Singular/g
s/『V-2AOM-2P』/Verb, second Aorist, passive depOnent, iMperative, second, Plural/g
s/『V-2AON』/Verb, second Aorist, passive depOnent, iNfinitive/g
s/『V-2AOS-2P』/Verb, second Aorist, passive depOnent, Subjunctive, second, Plural/g
s/『V-2API-1P』/Verb, second Aorist, Passive, Indicative, first, Plural/g
s/『V-2API-1S』/Verb, second Aorist, Passive, Indicative, first, Singular/g
s/『V-2API-2P』/Verb, second Aorist, Passive, Indicative, second, Plural/g
s/『V-2API-2S』/Verb, second Aorist, Passive, Indicative, second, Singular/g
s/『V-2API-3P』/Verb, second Aorist, Passive, Indicative, third, Plural/g
s/『V-2API-3S』/Verb, second Aorist, Passive, Indicative, third, Singular/g
s/『V-2APM-2P』/Verb, second Aorist, Passive, iMperative, second, Plural/g
s/『V-2APM-2S』/Verb, second Aorist, Passive, iMperative, second, Singular/g
s/『V-2APM-3S』/Verb, second Aorist, Passive, iMperative, third, Singular/g
s/『V-2APN』/Verb, second Aorist, Passive, iNfinitive/g
s/『V-2APP-ASM』/Verb, second Aorist, Passive, Participle, Accusative, Singular, Masculine/g
s/『V-2APP-DSN』/Verb, second Aorist, Passive, Participle, Dative, Singular, Neuter/g
s/『V-2APP-GPM』/Verb, second Aorist, Passive, Participle, Genitive, Plural, Masculine/g
s/『V-2APP-NPF』/Verb, second Aorist, Passive, Participle, Nominative, Plural, Feminine/g
s/『V-2APP-NPM』/Verb, second Aorist, Passive, Participle, Nominative, Plural, Masculine/g
s/『V-2APP-NSF』/Verb, second Aorist, Passive, Participle, Nominative, Singular, Feminine/g
s/『V-2APP-NSM』/Verb, second Aorist, Passive, Participle, Nominative, Singular, Masculine/g
s/『V-2APP-NSN』/Verb, second Aorist, Passive, Participle, Nominative, Singular, Neuter/g
s/『V-2APS-1P』/Verb, second Aorist, Passive, Subjunctive, first, Plural/g
s/『V-2APS-2P』/Verb, second Aorist, Passive, Subjunctive, second, Plural/g
s/『V-2APS-2S』/Verb, second Aorist, Passive, Subjunctive, second, Singular/g
s/『V-2APS-3P』/Verb, second Aorist, Passive, Subjunctive, third, Plural/g
s/『V-2APS-3S』/Verb, second Aorist, Passive, Subjunctive, third, Singular/g
s/『V-2AXM-2P』/Verb, second Aorist, no voice stated, iMperative, second, Plural/g
s/『V-2AXP-GPM』/Verb, second Aorist, no voice stated, Participle, Genitive, Plural, Masculine/g
s/『V-2AXS-2P』/Verb, second Aorist, no voice stated, Subjunctive, second, Plural/g
s/『V-2FAI-1S』/Verb, second Future, Active, Indicative, first, Singular/g
s/『V-2FAI-3S』/Verb, second Future, Active, Indicative, third, Singular/g
s/『V-2FDI-2S』/Verb, second Future, middle Deponent, Indicative, second, Singular/g
s/『V-2FDI-3P』/Verb, second Future, middle Deponent, Indicative, third, Plural/g
s/『V-2FDI-3S』/Verb, second Future, middle Deponent, Indicative, third, Singular/g
s/『V-2FMI-3S』/Verb, second Future, Middle, Indicative, third, Singular/g
s/『V-2FOI-1S』/Verb, second Future, passive depOnent, Indicative, first, Singular/g
s/『V-2FOI-3P』/Verb, second Future, passive depOnent, Indicative, third, Plural/g
s/『V-2FOI-3S』/Verb, second Future, passive depOnent, Indicative, third, Singular/g
s/『V-2FPI-1P』/Verb, second Future, Passive, Indicative, first, Plural/g
s/『V-2FPI-2P』/Verb, second Future, Passive, Indicative, second, Plural/g
s/『V-2FPI-2S』/Verb, second Future, Passive, Indicative, second, Singular/g
s/『V-2FPI-3P』/Verb, second Future, Passive, Indicative, third, Plural/g
s/『V-2FPI-3S』/Verb, second Future, Passive, Indicative, third, Singular/g
s/『V-2LAI-1S』/Verb, second pLuperfect, Active, Indicative, first, Singular/g
s/『V-2LAI-2P』/Verb, second pLuperfect, Active, Indicative, second, Plural/g
s/『V-2LAI-2S』/Verb, second pLuperfect, Active, Indicative, second, Singular/g
s/『V-2LAI-3P』/Verb, second pLuperfect, Active, Indicative, third, Plural/g
s/『V-2LAI-3S』/Verb, second pLuperfect, Active, Indicative, third, Singular/g
s/『V-2PAI-2S』/Verb, second Present, Active, Indicative, second, Singular/g
s/『V-2PAN』/Verb, second Present, Active, iNfinitive/g
s/『V-2RAI-1P-ATT』/Verb, second peRfect, Active, Indicative, first, Plural, ATTic form/g
s/『V-2RAI-1P』/Verb, second peRfect, Active, Indicative, first, Plural/g
s/『V-2RAI-1S』/Verb, second peRfect, Active, Indicative, first, Singular/g
s/『V-2RAI-2P-ATT』/Verb, second peRfect, Active, Indicative, second, Plural, ATTic form/g
s/『V-2RAI-2P』/Verb, second peRfect, Active, Indicative, second, Plural/g
s/『V-2RAI-2S』/Verb, second peRfect, Active, Indicative, second, Singular/g
s/『V-2RAI-3P-ATT』/Verb, second peRfect, Active, Indicative, third, Plural, ATTic form/g
s/『V-2RAI-3P-C』/Verb, second peRfect, Active, Indicative, third, Plural, Contracted form/g
s/『V-2RAI-3P』/Verb, second peRfect, Active, Indicative, third, Plural/g
s/『V-2RAI-3S-ATT』/Verb, second peRfect, Active, Indicative, third, Singular, ATTic form/g
s/『V-2RAI-3S』/Verb, second peRfect, Active, Indicative, third, Singular/g
s/『V-2RAN』/Verb, second peRfect, Active, iNfinitive/g
s/『V-2RAP-APM-ATT』/Verb, second peRfect, Active, Participle, Accusative, Plural, Masculine, ATTic form/g
s/『V-2RAP-APM』/Verb, second peRfect, Active, Participle, Accusative, Plural, Masculine/g
s/『V-2RAP-APN』/Verb, second peRfect, Active, Participle, Accusative, Plural, Neuter/g
s/『V-2RAP-ASF』/Verb, second peRfect, Active, Participle, Accusative, Singular, Feminine/g
s/『V-2RAP-ASM』/Verb, second peRfect, Active, Participle, Accusative, Singular, Masculine/g
s/『V-2RAP-ASN』/Verb, second peRfect, Active, Participle, Accusative, Singular, Neuter/g
s/『V-2RAP-DSN』/Verb, second peRfect, Active, Participle, Dative, Singular, Neuter/g
s/『V-2RAP-GPN』/Verb, second peRfect, Active, Participle, Genitive, Plural, Neuter/g
s/『V-2RAP-NPF』/Verb, second peRfect, Active, Participle, Nominative, Plural, Feminine/g
s/『V-2RAP-NPM』/Verb, second peRfect, Active, Participle, Nominative, Plural, Masculine/g
s/『V-2RAP-NSF』/Verb, second peRfect, Active, Participle, Nominative, Singular, Feminine/g
s/『V-2RAP-NSM』/Verb, second peRfect, Active, Participle, Nominative, Singular, Masculine/g
s/『V-2RAP-NSN』/Verb, second peRfect, Active, Participle, Nominative, Singular, Neuter/g
s/『V-2RPP-APF』/Verb, second peRfect, Passive, Participle, Accusative, Plural, Feminine/g
s/『V-2RPP-ASM』/Verb, second peRfect, Passive, Participle, Accusative, Singular, Masculine/g
s/『V-2RPP-ASN』/Verb, second peRfect, Passive, Participle, Accusative, Singular, Neuter/g
s/『V-2RPP-GSF』/Verb, second peRfect, Passive, Participle, Genitive, Singular, Feminine/g
s/『V-2RPP-NSM』/Verb, second peRfect, Passive, Participle, Nominative, Singular, Masculine/g
s/『V-AAI-1P』/Verb, Aorist, Active, Indicative, first, Plural/g
s/『V-AAI-1S』/Verb, Aorist, Active, Indicative, first, Singular/g
s/『V-AAI-2P』/Verb, Aorist, Active, Indicative, second, Plural/g
s/『V-AAI-2S』/Verb, Aorist, Active, Indicative, second, Singular/g
s/『V-AAI-3P』/Verb, Aorist, Active, Indicative, third, Plural/g
s/『V-AAI-3S』/Verb, Aorist, Active, Indicative, third, Singular/g
s/『V-AAM-2P』/Verb, Aorist, Active, iMperative, second, Plural/g
s/『V-AAM-2S』/Verb, Aorist, Active, iMperative, second, Singular/g
s/『V-AAM-3P』/Verb, Aorist, Active, iMperative, third, Plural/g
s/『V-AAM-3S』/Verb, Aorist, Active, iMperative, third, Singular/g
s/『V-AAN』/Verb, Aorist, Active, iNfinitive/g
s/『V-AAO-3P-A』/Verb, Aorist, Active, Optative, third, Plural, Aeolic/g
s/『V-AAO-3P』/Verb, Aorist, Active, Optative, third, Plural/g
s/『V-AAO-3S』/Verb, Aorist, Active, Optative, third, Singular/g
s/『V-AAP-APM』/Verb, Aorist, Active, Participle, Accusative, Plural, Masculine/g
s/『V-AAP-APN』/Verb, Aorist, Active, Participle, Accusative, Plural, Neuter/g
s/『V-AAP-ASF』/Verb, Aorist, Active, Participle, Accusative, Singular, Feminine/g
s/『V-AAP-ASM』/Verb, Aorist, Active, Participle, Accusative, Singular, Masculine/g
s/『V-AAP-ASN』/Verb, Aorist, Active, Participle, Accusative, Singular, Neuter/g
s/『V-AAP-DPM』/Verb, Aorist, Active, Participle, Dative, Plural, Masculine/g
s/『V-AAP-DSM』/Verb, Aorist, Active, Participle, Dative, Singular, Masculine/g
s/『V-AAP-GPM』/Verb, Aorist, Active, Participle, Genitive, Plural, Masculine/g
s/『V-AAP-GSF』/Verb, Aorist, Active, Participle, Genitive, Singular, Feminine/g
s/『V-AAP-GSM』/Verb, Aorist, Active, Participle, Genitive, Singular, Masculine/g
s/『V-AAP-NPF』/Verb, Aorist, Active, Participle, Nominative, Plural, Feminine/g
s/『V-AAP-NPM』/Verb, Aorist, Active, Participle, Nominative, Plural, Masculine/g
s/『V-AAP-NSF』/Verb, Aorist, Active, Participle, Nominative, Singular, Feminine/g
s/『V-AAP-NSM』/Verb, Aorist, Active, Participle, Nominative, Singular, Masculine/g
s/『V-AAP-NSN』/Verb, Aorist, Active, Participle, Nominative, Singular, Neuter/g
s/『V-AAPNS』/Verb, Aorist, Active, Participle, Nominative, Singular/g
s/『V-AAS-1P』/Verb, Aorist, Active, Subjunctive, first, Plural/g
s/『V-AAS-1S』/Verb, Aorist, Active, Subjunctive, first, Singular/g
s/『V-AAS-2P』/Verb, Aorist, Active, Subjunctive, second, Plural/g
s/『V-AAS-2S』/Verb, Aorist, Active, Subjunctive, second, Singular/g
s/『V-AAS-3P』/Verb, Aorist, Active, Subjunctive, third, Plural/g
s/『V-AAS-3S』/Verb, Aorist, Active, Subjunctive, third, Singular/g
s/『V-ADI-1P』/Verb, Aorist, middle Deponent, Indicative, first, Plural/g
s/『V-ADI-1S』/Verb, Aorist, middle Deponent, Indicative, first, Singular/g
s/『V-ADI-2P』/Verb, Aorist, middle Deponent, Indicative, second, Plural/g
s/『V-ADI-2S』/Verb, Aorist, middle Deponent, Indicative, second, Singular/g
s/『V-ADI-3P』/Verb, Aorist, middle Deponent, Indicative, third, Plural/g
s/『V-ADI-3S』/Verb, Aorist, middle Deponent, Indicative, third, Singular/g
s/『V-ADM-2P』/Verb, Aorist, middle Deponent, iMperative, second, Plural/g
s/『V-ADM-2S』/Verb, Aorist, middle Deponent, iMperative, second, Singular/g
s/『V-ADM-3P』/Verb, Aorist, middle Deponent, iMperative, third, Plural/g
s/『V-ADM-3S』/Verb, Aorist, middle Deponent, iMperative, third, Singular/g
s/『V-ADN』/Verb, Aorist, middle Deponent, iNfinitive/g
s/『V-ADO-1S』/Verb, Aorist, middle Deponent, Optative, first, Singular/g
s/『V-ADP-APM』/Verb, Aorist, middle Deponent, Participle, Accusative, Plural, Masculine/g
s/『V-ADP-ASM』/Verb, Aorist, middle Deponent, Participle, Accusative, Singular, Masculine/g
s/『V-ADP-DPM』/Verb, Aorist, middle Deponent, Participle, Dative, Plural, Masculine/g
s/『V-ADP-GSF』/Verb, Aorist, middle Deponent, Participle, Genitive, Singular, Feminine/g
s/『V-ADP-NPM』/Verb, Aorist, middle Deponent, Participle, Nominative, Plural, Masculine/g
s/『V-ADP-NSF』/Verb, Aorist, middle Deponent, Participle, Nominative, Singular, Feminine/g
s/『V-ADP-NSM』/Verb, Aorist, middle Deponent, Participle, Nominative, Singular, Masculine/g
s/『V-ADS-1P』/Verb, Aorist, middle Deponent, Subjunctive, first, Plural/g
s/『V-ADS-1S』/Verb, Aorist, middle Deponent, Subjunctive, first, Singular/g
s/『V-ADS-2P』/Verb, Aorist, middle Deponent, Subjunctive, second, Plural/g
s/『V-ADS-2S』/Verb, Aorist, middle Deponent, Subjunctive, second, Singular/g
s/『V-ADS-3P』/Verb, Aorist, middle Deponent, Subjunctive, third, Plural/g
s/『V-ADS-3S』/Verb, Aorist, middle Deponent, Subjunctive, third, Singular/g
s/『V-AMI-1P』/Verb, Aorist, Middle, Indicative, first, Plural/g
s/『V-AMI-1S』/Verb, Aorist, Middle, Indicative, first, Singular/g
s/『V-AMI-2P』/Verb, Aorist, Middle, Indicative, second, Plural/g
s/『V-AMI-2S』/Verb, Aorist, Middle, Indicative, second, Singular/g
s/『V-AMI-3P』/Verb, Aorist, Middle, Indicative, third, Plural/g
s/『V-AMI-3S』/Verb, Aorist, Middle, Indicative, third, Singular/g
s/『V-AMM-2P』/Verb, Aorist, Middle, iMperative, second, Plural/g
s/『V-AMM-2S』/Verb, Aorist, Middle, iMperative, second, Singular/g
s/『V-AMM-3S』/Verb, Aorist, Middle, iMperative, third, Singular/g
s/『V-AMN』/Verb, Aorist, Middle, iNfinitive/g
s/『V-AMP-APM』/Verb, Aorist, Middle, Participle, Accusative, Plural, Masculine/g
s/『V-AMP-ASN』/Verb, Aorist, Middle, Participle, Accusative, Singular, Neuter/g
s/『V-AMP-DPM』/Verb, Aorist, Middle, Participle, Dative, Plural, Masculine/g
s/『V-AMP-GPM』/Verb, Aorist, Middle, Participle, Genitive, Plural, Masculine/g
s/『V-AMP-GSM』/Verb, Aorist, Middle, Participle, Genitive, Singular, Masculine/g
s/『V-AMP-NPM』/Verb, Aorist, Middle, Participle, Nominative, Plural, Masculine/g
s/『V-AMP-NSF』/Verb, Aorist, Middle, Participle, Nominative, Singular, Feminine/g
s/『V-AMP-NSM』/Verb, Aorist, Middle, Participle, Nominative, Singular, Masculine/g
s/『V-AMP-NSN』/Verb, Aorist, Middle, Participle, Nominative, Singular, Neuter/g
s/『V-AMPNP』/Verb, Aorist, Middle, Participle, Nominative, Plural/g
s/『V-AMS-1P』/Verb, Aorist, Middle, Subjunctive, first, Plural/g
s/『V-AMS-1S』/Verb, Aorist, Middle, Subjunctive, first, Singular/g
s/『V-AMS-2P』/Verb, Aorist, Middle, Subjunctive, second, Plural/g
s/『V-AMS-2S』/Verb, Aorist, Middle, Subjunctive, second, Singular/g
s/『V-AMS-3P』/Verb, Aorist, Middle, Subjunctive, third, Plural/g
s/『V-AMS-3S』/Verb, Aorist, Middle, Subjunctive, third, Singular/g
s/『V-ANI-3P』/Verb, Aorist, middle or passive depoNent, Indicative, third, Plural/g
s/『V-ANI-3S』/Verb, Aorist, middle or passive depoNent, Indicative, third, Singular/g
s/『V-ANP-NSM』/Verb, Aorist, middle or passive depoNent, Participle, Nominative, Singular, Masculine/g
s/『V-ANP-NSN』/Verb, Aorist, middle or passive depoNent, Participle, Nominative, Singular, Neuter/g
s/『V-AOI-1P-ATT』/Verb, Aorist, passive depOnent, Indicative, first, Plural, ATTic form/g
s/『V-AOI-1P』/Verb, Aorist, passive depOnent, Indicative, first, Plural/g
s/『V-AOI-1S-ATT』/Verb, Aorist, passive depOnent, Indicative, first, Singular, ATTic form/g
s/『V-AOI-1S』/Verb, Aorist, passive depOnent, Indicative, first, Singular/g
s/『V-AOI-2P-ATT』/Verb, Aorist, passive depOnent, Indicative, second, Plural, ATTic form/g
s/『V-AOI-2P』/Verb, Aorist, passive depOnent, Indicative, second, Plural/g
s/『V-AOI-3P-ATT』/Verb, Aorist, passive depOnent, Indicative, third, Plural, ATTic form/g
s/『V-AOI-3P』/Verb, Aorist, passive depOnent, Indicative, third, Plural/g
s/『V-AOI-3S-ATT』/Verb, Aorist, passive depOnent, Indicative, third, Singular, ATTic form/g
s/『V-AOI-3S』/Verb, Aorist, passive depOnent, Indicative, third, Singular/g
s/『V-AOM-2P』/Verb, Aorist, passive depOnent, iMperative, second, Plural/g
s/『V-AOM-2S』/Verb, Aorist, passive depOnent, iMperative, second, Singular/g
s/『V-AOM-3S』/Verb, Aorist, passive depOnent, iMperative, third, Singular/g
s/『V-AON』/Verb, Aorist, passive depOnent, iNfinitive/g
s/『V-AOO-3S』/Verb, Aorist, passive depOnent, Optative, third, Singular/g
s/『V-AOP-APM』/Verb, Aorist, passive depOnent, Participle, Accusative, Plural, Masculine/g
s/『V-AOP-ASM』/Verb, Aorist, passive depOnent, Participle, Accusative, Singular, Masculine/g
s/『V-AOP-DSM』/Verb, Aorist, passive depOnent, Participle, Dative, Singular, Masculine/g
s/『V-AOP-GPM』/Verb, Aorist, passive depOnent, Participle, Genitive, Plural, Masculine/g
s/『V-AOP-GPN』/Verb, Aorist, passive depOnent, Participle, Genitive, Plural, Neuter/g
s/『V-AOP-GSM』/Verb, Aorist, passive depOnent, Participle, Genitive, Singular, Masculine/g
s/『V-AOP-NPF』/Verb, Aorist, passive depOnent, Participle, Nominative, Plural, Feminine/g
s/『V-AOP-NPM』/Verb, Aorist, passive depOnent, Participle, Nominative, Plural, Masculine/g
s/『V-AOP-NSF』/Verb, Aorist, passive depOnent, Participle, Nominative, Singular, Feminine/g
s/『V-AOP-NSM』/Verb, Aorist, passive depOnent, Participle, Nominative, Singular, Masculine/g
s/『V-AOP-NSN』/Verb, Aorist, passive depOnent, Participle, Nominative, Singular, Neuter/g
s/『V-AOS-1P』/Verb, Aorist, passive depOnent, Subjunctive, first, Plural/g
s/『V-AOS-1S』/Verb, Aorist, passive depOnent, Subjunctive, first, Singular/g
s/『V-AOS-2P』/Verb, Aorist, passive depOnent, Subjunctive, second, Plural/g
s/『V-AOS-2S』/Verb, Aorist, passive depOnent, Subjunctive, second, Singular/g
s/『V-AOS-3P』/Verb, Aorist, passive depOnent, Subjunctive, third, Plural/g
s/『V-AOS-3S』/Verb, Aorist, passive depOnent, Subjunctive, third, Singular/g
s/『V-API-1P』/Verb, Aorist, Passive, Indicative, first, Plural/g
s/『V-API-1S』/Verb, Aorist, Passive, Indicative, first, Singular/g
s/『V-API-2P』/Verb, Aorist, Passive, Indicative, second, Plural/g
s/『V-API-2S』/Verb, Aorist, Passive, Indicative, second, Singular/g
s/『V-API-3P』/Verb, Aorist, Passive, Indicative, third, Plural/g
s/『V-API-3S-M』/Verb, Aorist, Passive, Indicative, third, Singular, Middle significance/g
s/『V-API-3S』/Verb, Aorist, Passive, Indicative, third, Singular/g
s/『V-API』/Verb, Aorist, Passive, Indicative/g
s/『V-APM-2P』/Verb, Aorist, Passive, iMperative, second, Plural/g
s/『V-APM-2S』/Verb, Aorist, Passive, iMperative, second, Singular/g
s/『V-APM-3P』/Verb, Aorist, Passive, iMperative, third, Plural/g
s/『V-APM-3S』/Verb, Aorist, Passive, iMperative, third, Singular/g
s/『V-APN-M』/Verb, Aorist, Passive, iNfinitive, Masculine/g
s/『V-APN』/Verb, Aorist, Passive, iNfinitive/g
s/『V-APO-3S』/Verb, Aorist, Passive, Optative, third, Singular/g
s/『V-APP-APM』/Verb, Aorist, Passive, Participle, Accusative, Plural, Masculine/g
s/『V-APP-APN』/Verb, Aorist, Passive, Participle, Accusative, Plural, Neuter/g
s/『V-APP-ASF』/Verb, Aorist, Passive, Participle, Accusative, Singular, Feminine/g
s/『V-APP-ASM』/Verb, Aorist, Passive, Participle, Accusative, Singular, Masculine/g
s/『V-APP-ASN』/Verb, Aorist, Passive, Participle, Accusative, Singular, Neuter/g
s/『V-APP-DPN』/Verb, Aorist, Passive, Participle, Dative, Plural, Neuter/g
s/『V-APP-DSF』/Verb, Aorist, Passive, Participle, Dative, Singular, Feminine/g
s/『V-APP-DSM』/Verb, Aorist, Passive, Participle, Dative, Singular, Masculine/g
s/『V-APP-GPF』/Verb, Aorist, Passive, Participle, Genitive, Plural, Feminine/g
s/『V-APP-GPM』/Verb, Aorist, Passive, Participle, Genitive, Plural, Masculine/g
s/『V-APP-GPN』/Verb, Aorist, Passive, Participle, Genitive, Plural, Neuter/g
s/『V-APP-GSF』/Verb, Aorist, Passive, Participle, Genitive, Singular, Feminine/g
s/『V-APP-GSM』/Verb, Aorist, Passive, Participle, Genitive, Singular, Masculine/g
s/『V-APP-GSN』/Verb, Aorist, Passive, Participle, Genitive, Singular, Neuter/g
s/『V-APP-NPM』/Verb, Aorist, Passive, Participle, Nominative, Plural, Masculine/g
s/『V-APP-NPN』/Verb, Aorist, Passive, Participle, Nominative, Plural, Neuter/g
s/『V-APP-NSF』/Verb, Aorist, Passive, Participle, Nominative, Singular, Feminine/g
s/『V-APP-NSM-M』/Verb, Aorist, Passive, Participle, Nominative, Singular, Masculine, Middle significance/g
s/『V-APP-NSM』/Verb, Aorist, Passive, Participle, Nominative, Singular, Masculine/g
s/『V-APP-NSN』/Verb, Aorist, Passive, Participle, Nominative, Singular, Neuter/g
s/『V-APS-1P』/Verb, Aorist, Passive, Subjunctive, first, Plural/g
s/『V-APS-1S』/Verb, Aorist, Passive, Subjunctive, first, Singular/g
s/『V-APS-2P』/Verb, Aorist, Passive, Subjunctive, second, Plural/g
s/『V-APS-2S』/Verb, Aorist, Passive, Subjunctive, second, Singular/g
s/『V-APS-3P』/Verb, Aorist, Passive, Subjunctive, third, Plural/g
s/『V-APS-3S』/Verb, Aorist, Passive, Subjunctive, third, Singular/g
s/『V-FAI-1P』/Verb, Future, Active, Indicative, first, Plural/g
s/『V-FAI-1S-ATT』/Verb, Future, Active, Indicative, first, Singular, ATTic form/g
s/『V-FAI-1S』/Verb, Future, Active, Indicative, first, Singular/g
s/『V-FAI-2P』/Verb, Future, Active, Indicative, second, Plural/g
s/『V-FAI-2S』/Verb, Future, Active, Indicative, second, Singular/g
s/『V-FAI-3P-ATT』/Verb, Future, Active, Indicative, third, Plural, ATTic form/g
s/『V-FAI-3P』/Verb, Future, Active, Indicative, third, Plural/g
s/『V-FAI-3S-ATT』/Verb, Future, Active, Indicative, third, Singular, ATTic form/g
s/『V-FAI-3S』/Verb, Future, Active, Indicative, third, Singular/g
s/『V-FAN』/Verb, Future, Active, iNfinitive/g
s/『V-FAP-APN』/Verb, Future, Active, Participle, Accusative, Plural, Neuter/g
s/『V-FAP-GPM』/Verb, Future, Active, Participle, Genitive, Plural, Masculine/g
s/『V-FAP-NPM』/Verb, Future, Active, Participle, Nominative, Plural, Masculine/g
s/『V-FAP-NSM』/Verb, Future, Active, Participle, Nominative, Singular, Masculine/g
s/『V-FDI-1P』/Verb, Future, middle Deponent, Indicative, first, Plural/g
s/『V-FDI-1S』/Verb, Future, middle Deponent, Indicative, first, Singular/g
s/『V-FDI-2P-ATT』/Verb, Future, middle Deponent, Indicative, second, Plural, ATTic form/g
s/『V-FDI-2P』/Verb, Future, middle Deponent, Indicative, second, Plural/g
s/『V-FDI-2S-ATT』/Verb, Future, middle Deponent, Indicative, second, Singular, ATTic form/g
s/『V-FDI-2S』/Verb, Future, middle Deponent, Indicative, second, Singular/g
s/『V-FDI-3P』/Verb, Future, middle Deponent, Indicative, third, Plural/g
s/『V-FDI-3S-ATT』/Verb, Future, middle Deponent, Indicative, third, Singular, ATTic form/g
s/『V-FDI-3S』/Verb, Future, middle Deponent, Indicative, third, Singular/g
s/『V-FDN』/Verb, Future, middle Deponent, iNfinitive/g
s/『V-FDP-ASN』/Verb, Future, middle Deponent, Participle, Accusative, Singular, Neuter/g
s/『V-FDP-NPM』/Verb, Future, middle Deponent, Participle, Nominative, Plural, Masculine/g
s/『V-FMI-1P』/Verb, Future, Middle, Indicative, first, Plural/g
s/『V-FMI-1S』/Verb, Future, Middle, Indicative, first, Singular/g
s/『V-FMI-2P』/Verb, Future, Middle, Indicative, second, Plural/g
s/『V-FMI-2S』/Verb, Future, Middle, Indicative, second, Singular/g
s/『V-FMI-3P』/Verb, Future, Middle, Indicative, third, Plural/g
s/『V-FMI-3S』/Verb, Future, Middle, Indicative, third, Singular/g
s/『V-FNI-3P』/Verb, Future, middle or passive depoNent, Indicative, third, Plural/g
s/『V-FNI-3S』/Verb, Future, middle or passive depoNent, Indicative, third, Singular/g
s/『V-FOI-1S』/Verb, Future, passive depOnent, Indicative, first, Singular/g
s/『V-FOI-3P』/Verb, Future, passive depOnent, Indicative, third, Plural/g
s/『V-FOI-3S』/Verb, Future, passive depOnent, Indicative, third, Singular/g
s/『V-FPI-1P』/Verb, Future, Passive, Indicative, first, Plural/g
s/『V-FPI-1S』/Verb, Future, Passive, Indicative, first, Singular/g
s/『V-FPI-2P』/Verb, Future, Passive, Indicative, second, Plural/g
s/『V-FPI-2S』/Verb, Future, Passive, Indicative, second, Singular/g
s/『V-FPI-3P』/Verb, Future, Passive, Indicative, third, Plural/g
s/『V-FPI-3S』/Verb, Future, Passive, Indicative, third, Singular/g
s/『V-FPP-GPN』/Verb, Future, Passive, Participle, Genitive, Plural, Neuter/g
s/『V-FPS-1S』/Verb, Future, Passive, Subjunctive, first, Singular/g
s/『V-FXI-1P』/Verb, Future, no voice stated, Indicative, first, Plural/g
s/『V-FXI-1S』/Verb, Future, no voice stated, Indicative, first, Singular/g
s/『V-FXI-2P』/Verb, Future, no voice stated, Indicative, second, Plural/g
s/『V-FXI-2S』/Verb, Future, no voice stated, Indicative, second, Singular/g
s/『V-FXI-3P』/Verb, Future, no voice stated, Indicative, third, Plural/g
s/『V-FXI-3S』/Verb, Future, no voice stated, Indicative, third, Singular/g
s/『V-FXN』/Verb, Future, no voice stated, iNfinitive/g
s/『V-FXP-ASN』/Verb, Future, no voice stated, Participle, Accusative, Singular, Neuter/g
s/『V-FXP-NSM』/Verb, Future, no voice stated, Participle, Nominative, Singular, Masculine/g
s/『V-IAI-1P』/Verb, Imperfect, Active, Indicative, first, Plural/g
s/『V-IAI-1S-ATT』/Verb, Imperfect, Active, Indicative, first, Singular, ATTic form/g
s/『V-IAI-1S』/Verb, Imperfect, Active, Indicative, first, Singular/g
s/『V-IAI-2P』/Verb, Imperfect, Active, Indicative, second, Plural/g
s/『V-IAI-2S』/Verb, Imperfect, Active, Indicative, second, Singular/g
s/『V-IAI-3P-ATT』/Verb, Imperfect, Active, Indicative, third, Plural, ATTic form/g
s/『V-IAI-3P』/Verb, Imperfect, Active, Indicative, third, Plural/g
s/『V-IAI-3S-ATT』/Verb, Imperfect, Active, Indicative, third, Singular, ATTic form/g
s/『V-IAI-3S』/Verb, Imperfect, Active, Indicative, third, Singular/g
s/『V-IDI-3P』/Verb, Imperfect, middle Deponent, Indicative, third, Plural/g
s/『V-IEI-3S』/Verb, Imperfect, Either middle or passive, Indicative, third, Singular/g
s/『V-IMI-1P』/Verb, Imperfect, Middle, Indicative, first, Plural/g
s/『V-IMI-1S』/Verb, Imperfect, Middle, Indicative, first, Singular/g
s/『V-IMI-2P』/Verb, Imperfect, Middle, Indicative, second, Plural/g
s/『V-IMI-2S』/Verb, Imperfect, Middle, Indicative, second, Singular/g
s/『V-IMI-3P』/Verb, Imperfect, Middle, Indicative, third, Plural/g
s/『V-IMI-3S』/Verb, Imperfect, Middle, Indicative, third, Singular/g
s/『V-INI-1P』/Verb, Imperfect, middle or passive depoNent, Indicative, first, Plural/g
s/『V-INI-1S』/Verb, Imperfect, middle or passive depoNent, Indicative, first, Singular/g
s/『V-INI-2P-ATT』/Verb, Imperfect, middle or passive depoNent, Indicative, second, Plural, ATTic form/g
s/『V-INI-2P』/Verb, Imperfect, middle or passive depoNent, Indicative, second, Plural/g
s/『V-INI-2S』/Verb, Imperfect, middle or passive depoNent, Indicative, second, Singular/g
s/『V-INI-3P-ATT』/Verb, Imperfect, middle or passive depoNent, Indicative, third, Plural, ATTic form/g
s/『V-INI-3P』/Verb, Imperfect, middle or passive depoNent, Indicative, third, Plural/g
s/『V-INI-3S-ATT』/Verb, Imperfect, middle or passive depoNent, Indicative, third, Singular, ATTic form/g
s/『V-INI-3S』/Verb, Imperfect, middle or passive depoNent, Indicative, third, Singular/g
s/『V-IPI-1P』/Verb, Imperfect, Passive, Indicative, first, Plural/g
s/『V-IPI-1S』/Verb, Imperfect, Passive, Indicative, first, Singular/g
s/『V-IPI-2P』/Verb, Imperfect, Passive, Indicative, second, Plural/g
s/『V-IPI-3P』/Verb, Imperfect, Passive, Indicative, third, Plural/g
s/『V-IPI-3S』/Verb, Imperfect, Passive, Indicative, third, Singular/g
s/『V-IQI-3S』/Verb, Imperfect, impersonal active, Indicative, third, Singular/g
s/『V-IXI-1P』/Verb, Imperfect, no voice stated, Indicative, first, Plural/g
s/『V-IXI-1S』/Verb, Imperfect, no voice stated, Indicative, first, Singular/g
s/『V-IXI-2P』/Verb, Imperfect, no voice stated, Indicative, second, Plural/g
s/『V-IXI-2S』/Verb, Imperfect, no voice stated, Indicative, second, Singular/g
s/『V-IXI-3P』/Verb, Imperfect, no voice stated, Indicative, third, Plural/g
s/『V-IXI-3S』/Verb, Imperfect, no voice stated, Indicative, third, Singular/g
s/『V-LAI-1S』/Verb, pLuperfect, Active, Indicative, first, Singular/g
s/『V-LAI-2P』/Verb, pLuperfect, Active, Indicative, second, Plural/g
s/『V-LAI-2S』/Verb, pLuperfect, Active, Indicative, second, Singular/g
s/『V-LAI-3P-ATT』/Verb, pLuperfect, Active, Indicative, third, Plural, ATTic form/g
s/『V-LAI-3P』/Verb, pLuperfect, Active, Indicative, third, Plural/g
s/『V-LAI-3S-ATT』/Verb, pLuperfect, Active, Indicative, third, Singular, ATTic form/g
s/『V-LAI-3S』/Verb, pLuperfect, Active, Indicative, third, Singular/g
s/『V-LDI-3S』/Verb, pLuperfect, middle Deponent, Indicative, third, Singular/g
s/『V-LMI-3P』/Verb, pLuperfect, Middle, Indicative, third, Plural/g
s/『V-LPI-3S』/Verb, pLuperfect, Passive, Indicative, third, Singular/g
s/『V-PAI-1P』/Verb, Present, Active, Indicative, first, Plural/g
s/『V-PAI-1S-C』/Verb, Present, Active, Indicative, first, Singular, Contracted form/g
s/『V-PAI-1S』/Verb, Present, Active, Indicative, first, Singular/g
s/『V-PAI-2P』/Verb, Present, Active, Indicative, second, Plural/g
s/『V-PAI-2S-IRR』/Verb, Present, Active, Indicative, second, Singular, IRRegular or inpure form/g
s/『V-PAI-2S』/Verb, Present, Active, Indicative, second, Singular/g
s/『V-PAI-3P \(V-PAP-DPM\)』/Verb, Present, Active, Indicative, third, Plural (Verb, Present, Active, Participle, Dative, Plural, Masculine)/g
s/『V-PAI-3P-ATT』/Verb, Present, Active, Indicative, third, Plural, ATTic form/g
s/『V-PAI-3P』/Verb, Present, Active, Indicative, third, Plural/g
s/『V-PAI-3S』/Verb, Present, Active, Indicative, third, Singular/g
s/『V-PAM-2P』/Verb, Present, Active, iMperative, second, Plural/g
s/『V-PAM-2S』/Verb, Present, Active, iMperative, second, Singular/g
s/『V-PAM-3P』/Verb, Present, Active, iMperative, third, Plural/g
s/『V-PAM-3S』/Verb, Present, Active, iMperative, third, Singular/g
s/『V-PAN』/Verb, Present, Active, iNfinitive/g
s/『V-PAO-2P』/Verb, Present, Active, Optative, second, Plural/g
s/『V-PAO-3P』/Verb, Present, Active, Optative, third, Plural/g
s/『V-PAO-3S』/Verb, Present, Active, Optative, third, Singular/g
s/『V-PAP-APF』/Verb, Present, Active, Participle, Accusative, Plural, Feminine/g
s/『V-PAP-APM』/Verb, Present, Active, Participle, Accusative, Plural, Masculine/g
s/『V-PAP-APN』/Verb, Present, Active, Participle, Accusative, Plural, Neuter/g
s/『V-PAP-ASF』/Verb, Present, Active, Participle, Accusative, Singular, Feminine/g
s/『V-PAP-ASM』/Verb, Present, Active, Participle, Accusative, Singular, Masculine/g
s/『V-PAP-ASN』/Verb, Present, Active, Participle, Accusative, Singular, Neuter/g
s/『V-PAP-DPF』/Verb, Present, Active, Participle, Dative, Plural, Feminine/g
s/『V-PAP-DPM』/Verb, Present, Active, Participle, Dative, Plural, Masculine/g
s/『V-PAP-DPN』/Verb, Present, Active, Participle, Dative, Plural, Neuter/g
s/『V-PAP-DSF』/Verb, Present, Active, Participle, Dative, Singular, Feminine/g
s/『V-PAP-DSM』/Verb, Present, Active, Participle, Dative, Singular, Masculine/g
s/『V-PAP-DSN』/Verb, Present, Active, Participle, Dative, Singular, Neuter/g
s/『V-PAP-GPF』/Verb, Present, Active, Participle, Genitive, Plural, Feminine/g
s/『V-PAP-GPM』/Verb, Present, Active, Participle, Genitive, Plural, Masculine/g
s/『V-PAP-GPN』/Verb, Present, Active, Participle, Genitive, Plural, Neuter/g
s/『V-PAP-GSF』/Verb, Present, Active, Participle, Genitive, Singular, Feminine/g
s/『V-PAP-GSM』/Verb, Present, Active, Participle, Genitive, Singular, Masculine/g
s/『V-PAP-GSN』/Verb, Present, Active, Participle, Genitive, Singular, Neuter/g
s/『V-PAP-NPF』/Verb, Present, Active, Participle, Nominative, Plural, Feminine/g
s/『V-PAP-NPM』/Verb, Present, Active, Participle, Nominative, Plural, Masculine/g
s/『V-PAP-NPN』/Verb, Present, Active, Participle, Nominative, Plural, Neuter/g
s/『V-PAP-NSF』/Verb, Present, Active, Participle, Nominative, Singular, Feminine/g
s/『V-PAP-NSM』/Verb, Present, Active, Participle, Nominative, Singular, Masculine/g
s/『V-PAP-NSN』/Verb, Present, Active, Participle, Nominative, Singular, Neuter/g
s/『V-PAP-VPM』/Verb, Present, Active, Participle, Vocative, Plural, Masculine/g
s/『V-PAP-VSF』/Verb, Present, Active, Participle, Vocative, Singular, Feminine/g
s/『V-PAP-VSM』/Verb, Present, Active, Participle, Vocative, Singular, Masculine/g
s/『V-PAPDP』/Verb, Present, Active, Participle, Dative, Plural/g
s/『V-PAS-1P』/Verb, Present, Active, Subjunctive, first, Plural/g
s/『V-PAS-1S』/Verb, Present, Active, Subjunctive, first, Singular/g
s/『V-PAS-2P』/Verb, Present, Active, Subjunctive, second, Plural/g
s/『V-PAS-2S』/Verb, Present, Active, Subjunctive, second, Singular/g
s/『V-PAS-3P』/Verb, Present, Active, Subjunctive, third, Plural/g
s/『V-PAS-3S』/Verb, Present, Active, Subjunctive, third, Singular/g
s/『V-PDP-NPM』/Verb, Present, middle Deponent, Participle, Nominative, Plural, Masculine/g
s/『V-PEI-1P』/Verb, Present, Either middle or passive, Indicative, first, Plural/g
s/『V-PEI-1S』/Verb, Present, Either middle or passive, Indicative, first, Singular/g
s/『V-PEI-2P』/Verb, Present, Either middle or passive, Indicative, second, Plural/g
s/『V-PEI-3P』/Verb, Present, Either middle or passive, Indicative, third, Plural/g
s/『V-PEI-3S』/Verb, Present, Either middle or passive, Indicative, third, Singular/g
s/『V-PEM-2P』/Verb, Present, Either middle or passive, iMperative, second, Plural/g
s/『V-PEM-2S』/Verb, Present, Either middle or passive, iMperative, second, Singular/g
s/『V-PEN』/Verb, Present, Either middle or passive, iNfinitive/g
s/『V-PEP-ASM』/Verb, Present, Either middle or passive, Participle, Accusative, Singular, Masculine/g
s/『V-PEP-DPM』/Verb, Present, Either middle or passive, Participle, Dative, Plural, Masculine/g
s/『V-PEP-DSM』/Verb, Present, Either middle or passive, Participle, Dative, Singular, Masculine/g
s/『V-PEP-GPN』/Verb, Present, Either middle or passive, Participle, Genitive, Plural, Neuter/g
s/『V-PEP-GSF』/Verb, Present, Either middle or passive, Participle, Genitive, Singular, Feminine/g
s/『V-PEP-GSM』/Verb, Present, Either middle or passive, Participle, Genitive, Singular, Masculine/g
s/『V-PEP-NPF』/Verb, Present, Either middle or passive, Participle, Nominative, Plural, Feminine/g
s/『V-PEP-NPM』/Verb, Present, Either middle or passive, Participle, Nominative, Plural, Masculine/g
s/『V-PEP-NSF』/Verb, Present, Either middle or passive, Participle, Nominative, Singular, Feminine/g
s/『V-PMI-1P』/Verb, Present, Middle, Indicative, first, Plural/g
s/『V-PMI-1S』/Verb, Present, Middle, Indicative, first, Singular/g
s/『V-PMI-2P』/Verb, Present, Middle, Indicative, second, Plural/g
s/『V-PMI-2S』/Verb, Present, Middle, Indicative, second, Singular/g
s/『V-PMI-3P』/Verb, Present, Middle, Indicative, third, Plural/g
s/『V-PMI-3S』/Verb, Present, Middle, Indicative, third, Singular/g
s/『V-PMM-2P』/Verb, Present, Middle, iMperative, second, Plural/g
s/『V-PMM-2S』/Verb, Present, Middle, iMperative, second, Singular/g
s/『V-PMM-3P』/Verb, Present, Middle, iMperative, third, Plural/g
s/『V-PMM-3S』/Verb, Present, Middle, iMperative, third, Singular/g
s/『V-PMN』/Verb, Present, Middle, iNfinitive/g
s/『V-PMP-APF』/Verb, Present, Middle, Participle, Accusative, Plural, Feminine/g
s/『V-PMP-APM』/Verb, Present, Middle, Participle, Accusative, Plural, Masculine/g
s/『V-PMP-APN』/Verb, Present, Middle, Participle, Accusative, Plural, Neuter/g
s/『V-PMP-ASF』/Verb, Present, Middle, Participle, Accusative, Singular, Feminine/g
s/『V-PMP-ASM』/Verb, Present, Middle, Participle, Accusative, Singular, Masculine/g
s/『V-PMP-ASN』/Verb, Present, Middle, Participle, Accusative, Singular, Neuter/g
s/『V-PMP-DPM』/Verb, Present, Middle, Participle, Dative, Plural, Masculine/g
s/『V-PMP-DSF』/Verb, Present, Middle, Participle, Dative, Singular, Feminine/g
s/『V-PMP-DSM』/Verb, Present, Middle, Participle, Dative, Singular, Masculine/g
s/『V-PMP-GPF』/Verb, Present, Middle, Participle, Genitive, Plural, Feminine/g
s/『V-PMP-GPM』/Verb, Present, Middle, Participle, Genitive, Plural, Masculine/g
s/『V-PMP-GPN』/Verb, Present, Middle, Participle, Genitive, Plural, Neuter/g
s/『V-PMP-GSF』/Verb, Present, Middle, Participle, Genitive, Singular, Feminine/g
s/『V-PMP-GSM-T』/Verb, Present, Middle, Participle, Genitive, Singular, Masculine, Transitive/g
s/『V-PMP-GSM』/Verb, Present, Middle, Participle, Genitive, Singular, Masculine/g
s/『V-PMP-GSN』/Verb, Present, Middle, Participle, Genitive, Singular, Neuter/g
s/『V-PMP-NPF』/Verb, Present, Middle, Participle, Nominative, Plural, Feminine/g
s/『V-PMP-NPM』/Verb, Present, Middle, Participle, Nominative, Plural, Masculine/g
s/『V-PMP-NSF』/Verb, Present, Middle, Participle, Nominative, Singular, Feminine/g
s/『V-PMP-NSM』/Verb, Present, Middle, Participle, Nominative, Singular, Masculine/g
s/『V-PMP-NSN』/Verb, Present, Middle, Participle, Nominative, Singular, Neuter/g
s/『V-PMS-1P』/Verb, Present, Middle, Subjunctive, first, Plural/g
s/『V-PMS-1S』/Verb, Present, Middle, Subjunctive, first, Singular/g
s/『V-PMS-2S』/Verb, Present, Middle, Subjunctive, second, Singular/g
s/『V-PMS-3S』/Verb, Present, Middle, Subjunctive, third, Singular/g
s/『V-PNI-1P』/Verb, Present, middle or passive depoNent, Indicative, first, Plural/g
s/『V-PNI-1S-C』/Verb, Present, middle or passive depoNent, Indicative, first, Singular, Contracted form/g
s/『V-PNI-1S』/Verb, Present, middle or passive depoNent, Indicative, first, Singular/g
s/『V-PNI-2P』/Verb, Present, middle or passive depoNent, Indicative, second, Plural/g
s/『V-PNI-2S-ATT』/Verb, Present, middle or passive depoNent, Indicative, second, Singular, ATTic form/g
s/『V-PNI-2S-C』/Verb, Present, middle or passive depoNent, Indicative, second, Singular, Contracted form/g
s/『V-PNI-2S』/Verb, Present, middle or passive depoNent, Indicative, second, Singular/g
s/『V-PNI-3P』/Verb, Present, middle or passive depoNent, Indicative, third, Plural/g
s/『V-PNI-3S-I』/Verb, Present, middle or passive depoNent, Indicative, third, Singular/g
s/『V-PNI-3S』/Verb, Present, middle or passive depoNent, Indicative, third, Singular/g
s/『V-PNM-2P』/Verb, Present, middle or passive depoNent, iMperative, second, Plural/g
s/『V-PNM-2S』/Verb, Present, middle or passive depoNent, iMperative, second, Singular/g
s/『V-PNM-3P』/Verb, Present, middle or passive depoNent, iMperative, third, Plural/g
s/『V-PNM-3S』/Verb, Present, middle or passive depoNent, iMperative, third, Singular/g
s/『V-PNN』/Verb, Present, middle or passive depoNent, iNfinitive/g
s/『V-PNO-1S』/Verb, Present, middle or passive depoNent, Optative, first, Singular/g
s/『V-PNO-3P』/Verb, Present, middle or passive depoNent, Optative, third, Plural/g
s/『V-PNO-3S』/Verb, Present, middle or passive depoNent, Optative, third, Singular/g
s/『V-PNP-APF』/Verb, Present, middle or passive depoNent, Participle, Accusative, Plural, Feminine/g
s/『V-PNP-APM』/Verb, Present, middle or passive depoNent, Participle, Accusative, Plural, Masculine/g
s/『V-PNP-APN』/Verb, Present, middle or passive depoNent, Participle, Accusative, Plural, Neuter/g
s/『V-PNP-ASF』/Verb, Present, middle or passive depoNent, Participle, Accusative, Singular, Feminine/g
s/『V-PNP-ASM』/Verb, Present, middle or passive depoNent, Participle, Accusative, Singular, Masculine/g
s/『V-PNP-ASN』/Verb, Present, middle or passive depoNent, Participle, Accusative, Singular, Neuter/g
s/『V-PNP-DPF』/Verb, Present, middle or passive depoNent, Participle, Dative, Plural, Feminine/g
s/『V-PNP-DPM』/Verb, Present, middle or passive depoNent, Participle, Dative, Plural, Masculine/g
s/『V-PNP-DPN』/Verb, Present, middle or passive depoNent, Participle, Dative, Plural, Neuter/g
s/『V-PNP-DSF』/Verb, Present, middle or passive depoNent, Participle, Dative, Singular, Feminine/g
s/『V-PNP-DSM』/Verb, Present, middle or passive depoNent, Participle, Dative, Singular, Masculine/g
s/『V-PNP-DSN』/Verb, Present, middle or passive depoNent, Participle, Dative, Singular, Neuter/g
s/『V-PNP-GPF』/Verb, Present, middle or passive depoNent, Participle, Genitive, Plural, Feminine/g
s/『V-PNP-GPM』/Verb, Present, middle or passive depoNent, Participle, Genitive, Plural, Masculine/g
s/『V-PNP-GPN』/Verb, Present, middle or passive depoNent, Participle, Genitive, Plural, Neuter/g
s/『V-PNP-GSF』/Verb, Present, middle or passive depoNent, Participle, Genitive, Singular, Feminine/g
s/『V-PNP-GSM』/Verb, Present, middle or passive depoNent, Participle, Genitive, Singular, Masculine/g
s/『V-PNP-GSN』/Verb, Present, middle or passive depoNent, Participle, Genitive, Singular, Neuter/g
s/『V-PNP-NPF』/Verb, Present, middle or passive depoNent, Participle, Nominative, Plural, Feminine/g
s/『V-PNP-NPM』/Verb, Present, middle or passive depoNent, Participle, Nominative, Plural, Masculine/g
s/『V-PNP-NPN』/Verb, Present, middle or passive depoNent, Participle, Nominative, Plural, Neuter/g
s/『V-PNP-NSF』/Verb, Present, middle or passive depoNent, Participle, Nominative, Singular, Feminine/g
s/『V-PNP-NSM』/Verb, Present, middle or passive depoNent, Participle, Nominative, Singular, Masculine/g
s/『V-PNP-NSN』/Verb, Present, middle or passive depoNent, Participle, Nominative, Singular, Neuter/g
s/『V-PNP-VPM』/Verb, Present, middle or passive depoNent, Participle, Vocative, Plural, Masculine/g
s/『V-PNP-VSM』/Verb, Present, middle or passive depoNent, Participle, Vocative, Singular, Masculine/g
s/『V-PNS-1P』/Verb, Present, middle or passive depoNent, Subjunctive, first, Plural/g
s/『V-PNS-1S』/Verb, Present, middle or passive depoNent, Subjunctive, first, Singular/g
s/『V-PNS-2P』/Verb, Present, middle or passive depoNent, Subjunctive, second, Plural/g
s/『V-PNS-2S』/Verb, Present, middle or passive depoNent, Subjunctive, second, Singular/g
s/『V-PNS-3P』/Verb, Present, middle or passive depoNent, Subjunctive, third, Plural/g
s/『V-PNS-3S』/Verb, Present, middle or passive depoNent, Subjunctive, third, Singular/g
s/『V-POP-NPM』/Verb, Present, passive depOnent, Participle, Nominative, Plural, Masculine/g
s/『V-PPI-1P』/Verb, Present, Passive, Indicative, first, Plural/g
s/『V-PPI-1S』/Verb, Present, Passive, Indicative, first, Singular/g
s/『V-PPI-2P』/Verb, Present, Passive, Indicative, second, Plural/g
s/『V-PPI-2S-IRR』/Verb, Present, Passive, Indicative, second, Singular, IRRegular or inpure form/g
s/『V-PPI-2S』/Verb, Present, Passive, Indicative, second, Singular/g
s/『V-PPI-3P』/Verb, Present, Passive, Indicative, third, Plural/g
s/『V-PPI-3S』/Verb, Present, Passive, Indicative, third, Singular/g
s/『V-PPM-2P』/Verb, Present, Passive, iMperative, second, Plural/g
s/『V-PPM-2S』/Verb, Present, Passive, iMperative, second, Singular/g
s/『V-PPM-3P』/Verb, Present, Passive, iMperative, third, Plural/g
s/『V-PPM-3S』/Verb, Present, Passive, iMperative, third, Singular/g
s/『V-PPN-2P』/Verb, Present, Passive, iNfinitive, second, Plural/g
s/『V-PPN』/Verb, Present, Passive, iNfinitive/g
s/『V-PPP-APF』/Verb, Present, Passive, Participle, Accusative, Plural, Feminine/g
s/『V-PPP-APM』/Verb, Present, Passive, Participle, Accusative, Plural, Masculine/g
s/『V-PPP-APN』/Verb, Present, Passive, Participle, Accusative, Plural, Neuter/g
s/『V-PPP-ASF』/Verb, Present, Passive, Participle, Accusative, Singular, Feminine/g
s/『V-PPP-ASM』/Verb, Present, Passive, Participle, Accusative, Singular, Masculine/g
s/『V-PPP-ASN』/Verb, Present, Passive, Participle, Accusative, Singular, Neuter/g
s/『V-PPP-DPM』/Verb, Present, Passive, Participle, Dative, Plural, Masculine/g
s/『V-PPP-DPN』/Verb, Present, Passive, Participle, Dative, Plural, Neuter/g
s/『V-PPP-DSF』/Verb, Present, Passive, Participle, Dative, Singular, Feminine/g
s/『V-PPP-DSM』/Verb, Present, Passive, Participle, Dative, Singular, Masculine/g
s/『V-PPP-DSN』/Verb, Present, Passive, Participle, Dative, Singular, Neuter/g
s/『V-PPP-GPM』/Verb, Present, Passive, Participle, Genitive, Plural, Masculine/g
s/『V-PPP-GPN』/Verb, Present, Passive, Participle, Genitive, Plural, Neuter/g
s/『V-PPP-GSF』/Verb, Present, Passive, Participle, Genitive, Singular, Feminine/g
s/『V-PPP-GSM』/Verb, Present, Passive, Participle, Genitive, Singular, Masculine/g
s/『V-PPP-GSN』/Verb, Present, Passive, Participle, Genitive, Singular, Neuter/g
s/『V-PPP-NPF』/Verb, Present, Passive, Participle, Nominative, Plural, Feminine/g
s/『V-PPP-NPM』/Verb, Present, Passive, Participle, Nominative, Plural, Masculine/g
s/『V-PPP-NPN』/Verb, Present, Passive, Participle, Nominative, Plural, Neuter/g
s/『V-PPP-NSF』/Verb, Present, Passive, Participle, Nominative, Singular, Feminine/g
s/『V-PPP-NSM』/Verb, Present, Passive, Participle, Nominative, Singular, Masculine/g
s/『V-PPP-NSN』/Verb, Present, Passive, Participle, Nominative, Singular, Neuter/g
s/『V-PPS-1P』/Verb, Present, Passive, Subjunctive, first, Plural/g
s/『V-PPS-1S』/Verb, Present, Passive, Subjunctive, first, Singular/g
s/『V-PPS-2P』/Verb, Present, Passive, Subjunctive, second, Plural/g
s/『V-PPS-3P』/Verb, Present, Passive, Subjunctive, third, Plural/g
s/『V-PPS-3S』/Verb, Present, Passive, Subjunctive, third, Singular/g
s/『V-PQI-3S』/Verb, Present, impersonal active, Indicative, third, Singular/g
s/『V-PQN』/Verb, Present, impersonal active, iNfinitive/g
s/『V-PQP-APN』/Verb, Present, impersonal active, Participle, Accusative, Plural, Neuter/g
s/『V-PQP-NSN』/Verb, Present, impersonal active, Participle, Nominative, Singular, Neuter/g
s/『V-PQS-3S』/Verb, Present, impersonal active, Subjunctive, third, Singular/g
s/『V-PXI-1P』/Verb, Present, no voice stated, Indicative, first, Plural/g
s/『V-PXI-1S』/Verb, Present, no voice stated, Indicative, first, Singular/g
s/『V-PXI-2P』/Verb, Present, no voice stated, Indicative, second, Plural/g
s/『V-PXI-2S』/Verb, Present, no voice stated, Indicative, second, Singular/g
s/『V-PXI-3P』/Verb, Present, no voice stated, Indicative, third, Plural/g
s/『V-PXI-3S』/Verb, Present, no voice stated, Indicative, third, Singular/g
s/『V-PXM-2S』/Verb, Present, no voice stated, iMperative, second, Singular/g
s/『V-PXM-3P』/Verb, Present, no voice stated, iMperative, third, Plural/g
s/『V-PXM-3S』/Verb, Present, no voice stated, iMperative, third, Singular/g
s/『V-PXN』/Verb, Present, no voice stated, iNfinitive/g
s/『V-PXO-2S』/Verb, Present, no voice stated, Optative, second, Singular/g
s/『V-PXO-3S』/Verb, Present, no voice stated, Optative, third, Singular/g
s/『V-PXP-APM』/Verb, Present, no voice stated, Participle, Accusative, Plural, Masculine/g
s/『V-PXP-APN』/Verb, Present, no voice stated, Participle, Accusative, Plural, Neuter/g
s/『V-PXP-ASF』/Verb, Present, no voice stated, Participle, Accusative, Singular, Feminine/g
s/『V-PXP-ASM』/Verb, Present, no voice stated, Participle, Accusative, Singular, Masculine/g
s/『V-PXP-ASN』/Verb, Present, no voice stated, Participle, Accusative, Singular, Neuter/g
s/『V-PXP-DPM』/Verb, Present, no voice stated, Participle, Dative, Plural, Masculine/g
s/『V-PXP-DPN』/Verb, Present, no voice stated, Participle, Dative, Plural, Neuter/g
s/『V-PXP-DSF』/Verb, Present, no voice stated, Participle, Dative, Singular, Feminine/g
s/『V-PXP-DSM』/Verb, Present, no voice stated, Participle, Dative, Singular, Masculine/g
s/『V-PXP-GPF』/Verb, Present, no voice stated, Participle, Genitive, Plural, Feminine/g
s/『V-PXP-GPM』/Verb, Present, no voice stated, Participle, Genitive, Plural, Masculine/g
s/『V-PXP-GPN』/Verb, Present, no voice stated, Participle, Genitive, Plural, Neuter/g
s/『V-PXP-GSF』/Verb, Present, no voice stated, Participle, Genitive, Singular, Feminine/g
s/『V-PXP-GSM』/Verb, Present, no voice stated, Participle, Genitive, Singular, Masculine/g
s/『V-PXP-GSN』/Verb, Present, no voice stated, Participle, Genitive, Singular, Neuter/g
s/『V-PXP-NPF』/Verb, Present, no voice stated, Participle, Nominative, Plural, Feminine/g
s/『V-PXP-NPM』/Verb, Present, no voice stated, Participle, Nominative, Plural, Masculine/g
s/『V-PXP-NPN』/Verb, Present, no voice stated, Participle, Nominative, Plural, Neuter/g
s/『V-PXP-NSF』/Verb, Present, no voice stated, Participle, Nominative, Singular, Feminine/g
s/『V-PXP-NSM』/Verb, Present, no voice stated, Participle, Nominative, Singular, Masculine/g
s/『V-PXP-NSN』/Verb, Present, no voice stated, Participle, Nominative, Singular, Neuter/g
s/『V-PXS-1P』/Verb, Present, no voice stated, Subjunctive, first, Plural/g
s/『V-PXS-1S』/Verb, Present, no voice stated, Subjunctive, first, Singular/g
s/『V-PXS-2P』/Verb, Present, no voice stated, Subjunctive, second, Plural/g
s/『V-PXS-2S』/Verb, Present, no voice stated, Subjunctive, second, Singular/g
s/『V-PXS-3P』/Verb, Present, no voice stated, Subjunctive, third, Plural/g
s/『V-PXS-3S』/Verb, Present, no voice stated, Subjunctive, third, Singular/g
s/『V-RAI-1P-ATT』/Verb, peRfect, Active, Indicative, first, Plural, ATTic form/g
s/『V-RAI-1P』/Verb, peRfect, Active, Indicative, first, Plural/g
s/『V-RAI-1S-ATT』/Verb, peRfect, Active, Indicative, first, Singular, ATTic form/g
s/『V-RAI-1S』/Verb, perfect, Active, Indicative, first, Singular/g
s/『V-RAI-2P-ATT』/Verb, peRfect, Active, Indicative, second, Plural, ATTic form/g
s/『V-RAI-2P』/Verb, peRfect, Active, Indicative, second, Plural/g
s/『V-RAI-2S-ATT』/Verb, peRfect, Active, Indicative, second, Singular, ATTic form/g
s/『V-RAI-2S』/Verb, peRfect, Active, Indicative, second, Singular/g
s/『V-RAI-3P-ATT』/Verb, peRfect, Active, Indicative, third, Plural, ATTic form/g
s/『V-RAI-3P』/Verb, peRfect, Active, Indicative, third, Plural/g
s/『V-RAI-3S-ATT』/Verb, peRfect, Active, Indicative, third, Singular, ATTic form/g
s/『V-RAI-3S』/Verb, peRfect, Active, Indicative, third, Singular/g
s/『V-RAM-2P』/Verb, peRfect, Active, iMperative, second, Plural/g
s/『V-RAN-ATT』/Verb, peRfect, Active, iNfinitive, Accusative/g
s/『V-RAN』/Verb, peRfect, Active, iNfinitive/g
s/『V-RAP-APM』/Verb, peRfect, Active, Participle, Accusative, Plural, Masculine/g
s/『V-RAP-APN』/Verb, peRfect, Active, Participle, Accusative, Plural, Neuter/g
s/『V-RAP-ASF』/Verb, peRfect, Active, Participle, Accusative, Singular, Feminine/g
s/『V-RAP-ASM-C』/Verb, peRfect, Active, Participle, Accusative, Singular, Masculine, Contracted form/g
s/『V-RAP-ASM』/Verb, peRfect, Active, Participle, Accusative, Singular, Masculine/g
s/『V-RAP-ASN』/Verb, peRfect, Active, Participle, Accusative, Singular, Neuter/g
s/『V-RAP-DPM』/Verb, peRfect, Active, Participle, Dative, Plural, Masculine/g
s/『V-RAP-DSM』/Verb, peRfect, Active, Participle, Dative, Singular, Masculine/g
s/『V-RAP-DSN』/Verb, peRfect, Active, Participle, Dative, Singular, Neuter/g
s/『V-RAP-GPM』/Verb, peRfect, Active, Participle, Genitive, Plural, Masculine/g
s/『V-RAP-GPN』/Verb, peRfect, Active, Participle, Genitive, Plural, Neuter/g
s/『V-RAP-GSF』/Verb, peRfect, Active, Participle, Genitive, Singular, Feminine/g
s/『V-RAP-GSM-ATT』/Verb, peRfect, Active, Participle, Genitive, Singular, Masculine, ATTic form/g
s/『V-RAP-GSM』/Verb, peRfect, Active, Participle, Genitive, Singular, Masculine/g
s/『V-RAP-GSN-ATT』/Verb, peRfect, Active, Participle, Genitive, Singular, Neuter, ATTic form/g
s/『V-RAP-NPF』/Verb, peRfect, Active, Participle, Nominative, Plural, Feminine/g
s/『V-RAP-NPM-ATT』/Verb, peRfect, Active, Participle, Nominative, Plural, Masculine, ATTic form/g
s/『V-RAP-NPM-C』/Verb, peRfect, Active, Participle, Nominative, Plural, Masculine, Contracted form/g
s/『V-RAP-NPM』/Verb, peRfect, Active, Participle, Nominative, Plural, Masculine/g
s/『V-RAP-NPN』/Verb, peRfect, Active, Participle, Nominative, Plural, Neuter/g
s/『V-RAP-NSF』/Verb, peRfect, Active, Participle, Nominative, Singular, Feminine/g
s/『V-RAP-NSM-ATT』/Verb, peRfect, Active, Participle, Nominative, Singular, Masculine, ATTic form/g
s/『V-RAP-NSM』/Verb, peRfect, Active, Participle, Nominative, Singular, Masculine/g
s/『V-RAP-NSN』/Verb, peRfect, Active, Participle, Nominative, Singular, Neuter/g
s/『V-RAS-1P』/Verb, peRfect, Active, Subjunctive, first, Plural/g
s/『V-RAS-1S』/Verb, peRfect, Active, Subjunctive, first, Singular/g
s/『V-RAS-2P』/Verb, peRfect, Active, Subjunctive, second, Plural/g
s/『V-RAS-2S』/Verb, peRfect, Active, Subjunctive, second, Singular/g
s/『V-RDI-3S』/Verb, peRfect, middle Deponent, Indicative, third, Singular/g
s/『V-REP-NSF』/Verb, peRfect, Either middle or passive, Participle, Nominative, Singular, Feminine/g
s/『V-REP-VSF』/Verb, peRfect, Either middle or passive, Participle, Vocative, Singular, Feminine/g
s/『V-RMI-1S』/Verb, peRfect, Middle, Indicative, first, Singular/g
s/『V-RMI-2P』/Verb, peRfect, Middle, Indicative, second, Plural/g
s/『V-RMI-2S』/Verb, peRfect, Middle, Indicative, second, Singular/g
s/『V-RMI-3S』/Verb, peRfect, Middle, Indicative, third, Singular/g
s/『V-RMM-2P』/Verb, peRfect, Middle, iMperative, second, Plural/g
s/『V-RMP-APM』/Verb, peRfect, Middle, Participle, Accusative, Plural, Masculine/g
s/『V-RMP-ASM』/Verb, peRfect, Middle, Participle, Accusative, Singular, Masculine/g
s/『V-RMP-DPM』/Verb, peRfect, Middle, Participle, Dative, Plural, Masculine/g
s/『V-RMP-GPM』/Verb, peRfect, Middle, Participle, Genitive, Plural, Masculine/g
s/『V-RMP-GSF』/Verb, peRfect, Middle, Participle, Genitive, Singular, Feminine/g
s/『V-RMP-NPM』/Verb, peRfect, Middle, Participle, Nominative, Plural, Masculine/g
s/『V-RMP-NSM』/Verb, peRfect, Middle, Participle, Nominative, Singular, Masculine/g
s/『V-RNI-1P』/Verb, peRfect, middle or passive depoNent, Indicative, first, Plural/g
s/『V-RNI-1S』/Verb, peRfect, middle or passive depoNent, Indicative, first, Singular/g
s/『V-RNI-3S』/Verb, peRfect, middle or passive depoNent, Indicative, third, Singular/g
s/『V-RNN』/Verb, peRfect, middle or passive depoNent, iNfinitive/g
s/『V-RNP-APM』/Verb, peRfect, middle or passive depoNent, Participle, Accusative, Plural, Masculine/g
s/『V-RNP-ASF』/Verb, peRfect, middle or passive depoNent, Participle, Accusative, Singular, Feminine/g
s/『V-RNP-DPF』/Verb, peRfect, middle or passive depoNent, Participle, Dative, Plural, Feminine/g
s/『V-RNP-NPM』/Verb, peRfect, middle or passive depoNent, Participle, Nominative, Plural, Masculine/g
s/『V-RNP-NSM』/Verb, peRfect, middle or passive depoNent, Participle, Nominative, Singular, Masculine/g
s/『V-RPI-1P』/Verb, peRfect, Passive, Indicative, first, Plural/g
s/『V-RPI-1S』/Verb, peRfect, Passive, Indicative, first, Singular/g
s/『V-RPI-2P』/Verb, peRfect, Passive, Indicative, second, Plural/g
s/『V-RPI-2S』/Verb, peRfect, Passive, Indicative, second, Singular/g
s/『V-RPI-3P』/Verb, peRfect, Passive, Indicative, third, Plural/g
s/『V-RPI-3S』/Verb, peRfect, Passive, Indicative, third, Singular/g
s/『V-RPM-2P』/Verb, peRfect, Passive, iMperative, second, Plural/g
s/『V-RPM-2S』/Verb, peRfect, Passive, iMperative, second, Singular/g
s/『V-RPN』/Verb, peRfect, Passive, iNfinitive/g
s/『V-RPP-APF』/Verb, peRfect, Passive, Participle, Accusative, Plural, Feminine/g
s/『V-RPP-APM』/Verb, peRfect, Passive, Participle, Accusative, Plural, Masculine/g
s/『V-RPP-APN』/Verb, peRfect, Passive, Participle, Accusative, Plural, Neuter/g
s/『V-RPP-ASF』/Verb, peRfect, Passive, Participle, Accusative, Singular, Feminine/g
s/『V-RPP-ASM』/Verb, peRfect, Passive, Participle, Accusative, Singular, Masculine/g
s/『V-RPP-ASN-ATT』/Verb, peRfect, Passive, Participle, Accusative, Singular, Neuter, ATTic form/g
s/『V-RPP-ASN』/Verb, peRfect, Passive, Participle, Accusative, Singular, Neuter/g
s/『V-RPP-DPM』/Verb, peRfect, Passive, Participle, Dative, Plural, Masculine/g
s/『V-RPP-DPN』/Verb, peRfect, Passive, Participle, Dative, Plural, Neuter/g
s/『V-RPP-DSF』/Verb, peRfect, Passive, Participle, Dative, Singular, Feminine/g
s/『V-RPP-DSM』/Verb, peRfect, Passive, Participle, Dative, Singular, Masculine/g
s/『V-RPP-DSN』/Verb, peRfect, Passive, Participle, Dative, Singular, Neuter/g
s/『V-RPP-GPF』/Verb, peRfect, Passive, Participle, Genitive, Plural, Feminine/g
s/『V-RPP-GPM』/Verb, peRfect, Passive, Participle, Genitive, Plural, Masculine/g
s/『V-RPP-GPN』/Verb, peRfect, Passive, Participle, Genitive, Plural, Neuter/g
s/『V-RPP-GSF』/Verb, peRfect, Passive, Participle, Genitive, Singular, Feminine/g
s/『V-RPP-GSM』/Verb, peRfect, Passive, Participle, Genitive, Singular, Masculine/g
s/『V-RPP-GSN』/Verb, peRfect, Passive, Participle, Genitive, Singular, Neuter/g
s/『V-RPP-NPF』/Verb, peRfect, Passive, Participle, Nominative, Plural, Feminine/g
s/『V-RPP-NPM』/Verb, peRfect, Passive, Participle, Nominative, Plural, Masculine/g
s/『V-RPP-NPN』/Verb, peRfect, Passive, Participle, Nominative, Plural, Neuter/g
s/『V-RPP-NSF』/Verb, peRfect, Passive, Participle, Nominative, Singular, Feminine/g
s/『V-RPP-NSM』/Verb, peRfect, Passive, Participle, Nominative, Singular, Masculine/g
s/『V-RPP-NSN-ATT』/Verb, peRfect, Passive, Participle, Nominative, Singular, Neuter, ATTic form/g
s/『V-RPP-NSN』/Verb, peRfect, Passive, Participle, Nominative, Singular, Neuter/g
s/『V-RPP-VPM』/Verb, peRfect, Passive, Participle, Vocative, Plural, Masculine/g
s/『V-RPP-VSF』/Verb, peRfect, Passive, Participle, Vocative, Singular, Feminine/g
s/『V-RPP-VSM』/Verb, peRfect, Passive, Participle, Vocative, Singular, Masculine/g
s/『V-XXM-2P』/Verb, no tense stated (adverbial imperative), no voice stated, iMperative, second, Plural/g
s/『V-XXM-2S』/Verb, no tense stated (adverbial imperative), no voice stated, iMperative, second, Singular/g
s/『X-APF』/indefinite pronoun, Accusative, Plural, Feminine/g
s/『X-APM』/indefinite pronoun, Accusative, Plural, Masculine/g
s/『X-APN』/indefinite pronoun, Accusative, Plural, Neuter/g
s/『X-ASF』/indefinite pronoun, Accusative, Singular, Feminine/g
s/『X-ASM』/indefinite pronoun, Accusative, Singular, Masculine/g
s/『X-ASN』/indefinite pronoun, Accusative, Singular, Neuter/g
s/『X-DPM』/indefinite pronoun, Dative, Plural, Masculine/g
s/『X-DSF』/indefinite pronoun, Dative, Singular, Feminine/g
s/『X-DSM』/indefinite pronoun, Dative, Singular, Masculine/g
s/『X-DSN』/indefinite pronoun, Dative, Singular, Neuter/g
s/『X-GPF』/indefinite pronoun, Genitive, Plural, Feminine/g
s/『X-GPM』/indefinite pronoun, Genitive, Plural, Masculine/g
s/『X-GPN』/indefinite pronoun, Genitive, Plural, Neuter/g
s/『X-GSF』/indefinite pronoun, Genitive, Singular, Feminine/g
s/『X-GSM』/indefinite pronoun, Genitive, Singular, Masculine/g
s/『X-GSN』/indefinite pronoun, Genitive, Singular, Neuter/g
s/『X-NPF』/indefinite pronoun, Nominative, Plural, Feminine/g
s/『X-NPM』/indefinite pronoun, Nominative, Plural, Masculine/g
s/『X-NPN』/indefinite pronoun, Nominative, Plural, Neuter/g
s/『X-NSF』/indefinite pronoun, Nominative, Singular, Feminine/g
s/『X-NSM』/indefinite pronoun, Nominative, Singular, Masculine/g
s/『X-NSN』/indefinite pronoun, Nominative, Singular, Neuter/g
