#! /usr/bin/sed -E -i .bak -f
#s/<FIND>/<REPLACE>/g
s/『G1』/alpha/g
s/『G2』/Aaron/g
s/『G3』/Abaddon/g
s/『G4』/not burdensome/g
s/『G5』/Father/g
s/『G6』/Abel/g
s/『G7』/Abijah/g
s/『G8』/Abiathar/g
s/『G9』/Abilene/g
s/『G10』/Abiud/g
s/『G11』/Abraham/g
s/『G12』/abyss/g
s/『G13』/Agabus/g
s/『G14』/to do good/g
s/『G15』/to do good/g
s/『G16』/doing good/g
s/『G17』/doing good/g
s/『G18』/good-doer/g
s/『G19』/goodness/g
s/『G20』/joy/g
s/『G21』/to rejoice/g
s/『G22』/unmarried/g
s/『G23』/be indignant/g
s/『G24』/indignation/g
s/『G25』/to love/g
s/『G26』/love/g
s/『G27』/beloved/g
s/『G28』/Hagar/g
s/『G29』/to force/g
s/『G30』/jar/g
s/『G31』/message/g
s/『G32』/angel/g
s/『G33』/to lead/g
s/『G34』/herd/g
s/『G35』/without genealogy/g
s/『G36』/lowly/g
s/『G37』/to sanctify/g
s/『G38』/holiness/g
s/『G39』/holy/g
s/『G40』/holy/g
s/『G41』/holiness/g
s/『G42』/holiness/g
s/『G43』/arm/g
s/『G44』/fishhook/g
s/『G45』/anchor/g
s/『G46』/unshrunk/g
s/『G47』/purity/g
s/『G48』/to purify/g
s/『G49』/purification/g
s/『G50』/be ignorant/g
s/『G51』/error/g
s/『G52』/ignorance/g
s/『G53』/pure/g
s/『G54』/purity/g
s/『G55』/purely/g
s/『G56』/ignorance/g
s/『G57』/unknown/g
s/『G58』/marketplace/g
s/『G59』/to buy/g
s/『G60』/of the marketplace/g
s/『G61』/catch/g
s/『G62』/unschooled/g
s/『G63』/to live outside/g
s/『G64』/to catch/g
s/『G65』/wild olive tree/g
s/『G66』/wild/g
s/『G67』/Agrippa/g
s/『G68』/field/g
s/『G69』/be watchful/g
s/『G70』/sleeplessness/g
s/『G71』/to bring/g
s/『G72』/self-conduct/g
s/『G73』/fight/g
s/『G74』/a struggle/g
s/『G75』/to struggle/g
s/『G76』/Adam/g
s/『G77』/free/g
s/『G78』/Addi/g
s/『G79』/sister/g
s/『G80』/brother/g
s/『G81』/brotherhood/g
s/『G82』/unclear/g
s/『G83』/uncertainty/g
s/『G84』/uncertainly/g
s/『G85』/be distressed/g
s/『G86』/Hades/g
s/『G87』/impartial/g
s/『G88』/continuous/g
s/『G89』/unceasingly/g
s/『G90』/integrity/g
s/『G91』/to harm/g
s/『G92』/crime/g
s/『G93』/unrighteousness/g
s/『G94』/unjust/g
s/『G95』/unjustly/g
s/『G96』/failing/g
s/『G97』/pure/g
s/『G98』/Adramyttene/g
s/『G99』/Adriatic Sea/g
s/『G100』/abundance/g
s/『G101』/not to be able/g
s/『G102』/unable/g
s/『G103』/to sing/g
s/『G104』/always/g
s/『G105』/eagle/g
s/『G106』/unleavened/g
s/『G107』/Azor/g
s/『G108』/Azotus/g
s/『G109』/air/g
s/『G110』/immortality/g
s/『G111』/unlawful/g
s/『G112』/without God/g
s/『G113』/lawless/g
s/『G114』/to reject/g
s/『G115』/nullification/g
s/『G116』/Athens/g
s/『G117』/Athenian/g
s/『G118』/to compete/g
s/『G119』/struggle/g
s/『G120』/be discouraged/g
s/『G121』/innocent/g
s/『G122』/goat's/g
s/『G123』/shore/g
s/『G124』/Egyptian/g
s/『G125』/Egypt/g
s/『G126』/eternal/g
s/『G127』/modesty/g
s/『G128』/Ethiopian/g
s/『G129』/blood/g
s/『G130』/bloodshed/g
s/『G131』/to bleed/g
s/『G132』/Aeneas/g
s/『G133』/praise/g
s/『G134』/to praise/g
s/『G135』/obscure thing/g
s/『G136』/praise/g
s/『G137』/Aenon/g
s/『G138』/to choose/g
s/『G139』/sect/g
s/『G140』/to choose/g
s/『G141』/schismatic/g
s/『G142』/to take up/g
s/『G143』/to perceive/g
s/『G144』/insight/g
s/『G145』/sense/g
s/『G146』/greedy/g
s/『G147』/greedily/g
s/『G148』/obscenity/g
s/『G149』/shameful/g
s/『G150』/shameful/g
s/『G151』/obscenity/g
s/『G152』/shame/g
s/『G153』/be ashamed/g
s/『G154』/to ask/g
s/『G155』/request/g
s/『G156』/cause\/charge/g
s/『G157』/charge/g
s/『G158』/reason for charge/g
s/『G159』/causer/g
s/『G160』/sudden/g
s/『G161』/captivity/g
s/『G162』/to take captive/g
s/『G163』/to capture/g
s/『G164』/captive/g
s/『G165』/an age/g
s/『G166』/eternal/g
s/『G167』/impurity/g
s/『G168』/uncleanness/g
s/『G169』/unclean/g
s/『G170』/to lack opportunity/g
s/『G171』/unseasonably/g
s/『G172』/innocent/g
s/『G173』/a thorn/g
s/『G174』/thorny/g
s/『G175』/unfruitful/g
s/『G176』/beyond reproach/g
s/『G177』/uncovered/g
s/『G178』/uncondemned/g
s/『G179』/indestructible/g
s/『G180』/unceasing/g
s/『G181』/disorder/g
s/『G182』/restless/g
s/『G183』/uncontrollable/g
s/『G184』/Akeldama/g
s/『G185』/innocent/g
s/『G186』/unwavering/g
s/『G187』/to ripen/g
s/『G188』/still/g
s/『G189』/hearing/g
s/『G190』/to follow/g
s/『G191』/to hear/g
s/『G192』/self-indulgence/g
s/『G193』/intemperate/g
s/『G194』/undiluted/g
s/『G195』/strictness/g
s/『G196』/strictest/g
s/『G197』/stricter/g
s/『G198』/be exactly/g
s/『G199』/exactly/g
s/『G200』/locust/g
s/『G201』/hall/g
s/『G202』/hearer/g
s/『G203』/uncircumcision/g
s/『G204』/cornerstone/g
s/『G205』/fine spoils/g
s/『G206』/end/g
s/『G207』/Aquila/g
s/『G208』/to nullify/g
s/『G209』/freely/g
s/『G210』/unwilling/g
s/『G211』/jar/g
s/『G212』/boasting/g
s/『G213』/braggart/g
s/『G214』/to wail/g
s/『G215』/inexpressible/g
s/『G216』/mute/g
s/『G217』/salt/g
s/『G218』/to anoint/g
s/『G219』/crowing/g
s/『G220』/rooster/g
s/『G221』/Alexandrian/g
s/『G222』/Alexandrian/g
s/『G223』/Alexander/g
s/『G224』/flour/g
s/『G225』/truth/g
s/『G226』/be truthful/g
s/『G227』/true/g
s/『G228』/true/g
s/『G229』/to grind/g
s/『G230』/truly/g
s/『G231』/fisherman/g
s/『G232』/to fish/g
s/『G233』/to salt/g
s/『G234』/defilement/g
s/『G235』/but/g
s/『G236』/to change/g
s/『G237』/from elsewhere/g
s/『G238』/to use an analogy/g
s/『G239』/hallelujah/g
s/『G240』/one another/g
s/『G241』/foreign/g
s/『G242』/to spring/g
s/『G243』/another/g
s/『G244』/meddler/g
s/『G245』/another’s/g
s/『G246』/foreigner/g
s/『G247』/otherwise/g
s/『G248』/to thresh/g
s/『G249』/unreasonable/g
s/『G250』/aloes/g
s/『G251』/salt/g
s/『G252』/salty/g
s/『G253』/without anxiety/g
s/『G254』/chain/g
s/『G255』/unprofitable/g
s/『G256』/Alphaeus/g
s/『G257』/threshing-floor/g
s/『G258』/fox/g
s/『G259』/capture/g
s/『G260』/together/g
s/『G261』/ignorant/g
s/『G262』/unfading/g
s/『G263』/unfading/g
s/『G264』/to sin/g
s/『G265』/sin/g
s/『G266』/sin/g
s/『G267』/without witness/g
s/『G268』/sinful/g
s/『G269』/peacable/g
s/『G270』/to mow/g
s/『G271』/amethyst/g
s/『G272』/to neglect/g
s/『G273』/blameless/g
s/『G274』/blamelessly/g
s/『G275』/untroubled/g
s/『G276』/unchangeable/g
s/『G277』/immovable/g
s/『G278』/irrevocable/g
s/『G279』/unrepentant/g
s/『G280』/immoderate/g
s/『G281』/amen/g
s/『G282』/motherless/g
s/『G283』/pure/g
s/『G284』/Amminadab/g
s/『G285』/sand/g
s/『G286』/lamb/g
s/『G287』/repayment/g
s/『G288』/vine/g
s/『G289』/a vine-worker/g
s/『G290』/vineyard/g
s/『G291』/Ampliatus/g
s/『G292』/to defend/g
s/『G293』/net/g
s/『G294』/to clothe/g
s/『G295』/Amphipolis/g
s/『G296』/street/g
s/『G297』/both/g
s/『G298』/blameless/g
s/『G299』/blameless/g
s/『G300』/Amon/g
s/『G301』/Amos/g
s/『G302』/if/g
s/『G303』/each/g
s/『G304』/stairs/g
s/『G305』/to ascend/g
s/『G306』/to defer/g
s/『G307』/to pull up/g
s/『G308』/to look up\/see again/g
s/『G309』/recovery of sight/g
s/『G310』/to cry out/g
s/『G311』/delay/g
s/『G312』/to report/g
s/『G313』/to beget/g
s/『G314』/to read/g
s/『G315』/to compel/g
s/『G316』/necessary/g
s/『G317』/necessarily/g
s/『G318』/necessity/g
s/『G319』/to recognize/g
s/『G320』/reading/g
s/『G321』/to lead/g
s/『G322』/to appoint/g
s/『G323』/public appearance/g
s/『G324』/to receive/g
s/『G325』/to deliver/g
s/『G326』/to revive/g
s/『G327』/to search/g
s/『G328』/to gird/g
s/『G329』/to rekindle/g
s/『G330』/to renew/g
s/『G331』/devoted/g
s/『G332』/to take an oath/g
s/『G333』/to contemplate/g
s/『G334』/a vow offering/g
s/『G335』/shamelessnes/g
s/『G336』/murder/g
s/『G337』/to do away with/g
s/『G338』/innocent/g
s/『G339』/to sit up/g
s/『G340』/to restore/g
s/『G341』/to renew/g
s/『G342』/renewal/g
s/『G343』/to unveil/g
s/『G344』/to return/g
s/『G345』/to recline/g
s/『G346』/to summarise/g
s/『G347』/to recline/g
s/『G348』/to hinder/g
s/『G349』/to yell/g
s/『G350』/to investigate/g
s/『G351』/investigation/g
s/『G352』/to straighten up/g
s/『G353』/to take up/g
s/『G354』/ascension/g
s/『G355』/to consume/g
s/『G356』/proportion/g
s/『G357』/to consider/g
s/『G358』/unsalty/g
s/『G359』/departure/g
s/『G360』/to depart/g
s/『G361』/sinless/g
s/『G362』/to await/g
s/『G363』/to remind/g
s/『G364』/remembrance/g
s/『G365』/to renew/g
s/『G366』/to regain senses/g
s/『G367』/Ananias/g
s/『G368』/indisputable/g
s/『G369』/without objection/g
s/『G370』/unworthy/g
s/『G371』/unworthily/g
s/『G372』/rest/g
s/『G373』/to give rest/g
s/『G374』/to persuade/g
s/『G375』/to send back/g
s/『G376』/crippled/g
s/『G377』/to recline/g
s/『G378』/to fulfil/g
s/『G379』/inexcusable/g
s/『G380』/to unroll/g
s/『G381』/to kindle/g
s/『G382』/countless/g
s/『G383』/to incite/g
s/『G384』/to upset/g
s/『G385』/to pull up/g
s/『G386』/resurrection/g
s/『G387』/to cause trouble/g
s/『G388』/to recrucify/g
s/『G389』/to sigh deeply/g
s/『G390』/to live\/return/g
s/『G391』/behaviour/g
s/『G392』/to compile/g
s/『G393』/to rise/g
s/『G394』/to set before/g
s/『G395』/east/g
s/『G396』/to overturn/g
s/『G397』/to bring up/g
s/『G398』/to appear/g
s/『G399』/to carry up/g
s/『G400』/to exclaim/g
s/『G401』/outpouring/g
s/『G402』/to leave/g
s/『G403』/refreshment/g
s/『G404』/to refresh/g
s/『G405』/slave-trader/g
s/『G406』/Andrew/g
s/『G407』/to act like a man/g
s/『G408』/Andronicus/g
s/『G409』/murderer/g
s/『G410』/irreproachable/g
s/『G411』/indescribable/g
s/『G412』/inexpressible/g
s/『G413』/inexhaustible/g
s/『G414』/bearable/g
s/『G415』/merciless/g
s/『G416』/be wind-blown/g
s/『G417』/wind/g
s/『G418』/impossible/g
s/『G419』/unsearchable/g
s/『G420』/not resentful/g
s/『G421』/unsearchable/g
s/『G422』/unashamed/g
s/『G423』/irreproachable/g
s/『G424』/to go up/g
s/『G425』/rest/g
s/『G426』/to question/g
s/『G427』/without/g
s/『G428』/unsuitable/g
s/『G429』/to find/g
s/『G430』/to endure/g
s/『G431』/cousin/g
s/『G432』/dill/g
s/『G433』/be fitting/g
s/『G434』/brutal/g
s/『G435』/man/g
s/『G436』/to oppose/g
s/『G437』/to praise/g
s/『G438』/flower/g
s/『G439』/charcoal fire/g
s/『G440』/charcoal/g
s/『G441』/people-pleaser/g
s/『G442』/human/g
s/『G443』/murderer/g
s/『G444』/a human/g
s/『G445』/to act as proconsul/g
s/『G446』/proconsul/g
s/『G447』/to loosen\/leave/g
s/『G448』/merciless/g
s/『G449』/unwashed/g
s/『G450』/to arise/g
s/『G451』/Anna/g
s/『G452』/Annas/g
s/『G453』/foolish/g
s/『G454』/folly/g
s/『G455』/to open/g
s/『G456』/to rebuild/g
s/『G457』/opening/g
s/『G458』/lawlessness/g
s/『G459』/lawless/g
s/『G460』/without law/g
s/『G461』/to restore/g
s/『G462』/unholy/g
s/『G463』/tolerance/g
s/『G464』/to struggle/g
s/『G465』/in exchange/g
s/『G466』/to fill up in turn/g
s/『G467』/to repay/g
s/『G468』/repayment/g
s/『G469』/reward/g
s/『G470』/to contradict/g
s/『G471』/to contradict/g
s/『G472』/to cling to/g
s/『G473』/for/g
s/『G474』/to discuss/g
s/『G475』/to oppose/g
s/『G476』/opponent/g
s/『G477』/opposition/g
s/『G478』/to resist/g
s/『G479』/to invite in return/g
s/『G480』/be an opponent/g
s/『G481』/opposite/g
s/『G482』/to help/g
s/『G483』/to dispute/g
s/『G484』/help/g
s/『G485』/dispute/g
s/『G486』/to retaliate/g
s/『G487』/ransom/g
s/『G488』/to return/g
s/『G489』/recompense/g
s/『G490』/Antioch/g
s/『G491』/Antiochian/g
s/『G492』/to pass/g
s/『G493』/Antipas/g
s/『G494』/Antipatris/g
s/『G495』/opposite/g
s/『G496』/to resist/g
s/『G497』/to wage war against/g
s/『G498』/to resist/g
s/『G499』/representation/g
s/『G500』/antichrist/g
s/『G501』/to draw/g
s/『G502』/bucket/g
s/『G503』/to face/g
s/『G504』/waterless/g
s/『G505』/genuine/g
s/『G506』/insubordinate/g
s/『G507』/above/g
s/『G508』/an upper room/g
s/『G509』/from above\/again/g
s/『G510』/interior/g
s/『G511』/higher/g
s/『G512』/useless/g
s/『G513』/axe/g
s/『G514』/worthy/g
s/『G515』/to deem worthy/g
s/『G516』/appropriately/g
s/『G517』/invisible/g
s/『G518』/to announce/g
s/『G519』/to strangle/g
s/『G520』/to lead away/g
s/『G521』/uninstructed/g
s/『G522』/to take away/g
s/『G523』/to demand/g
s/『G524』/to become callous/g
s/『G525』/to release/g
s/『G526』/to alienate/g
s/『G527』/tender/g
s/『G528』/to meet/g
s/『G529』/meeting/g
s/『G530』/once/g
s/『G531』/permanent/g
s/『G532』/unprepared/g
s/『G533』/to deny/g
s/『G534』/henceforth/g
s/『G535』/completion/g
s/『G536』/firstfruits/g
s/『G537』/all/g
s/『G538』/to deceive/g
s/『G539』/deceit/g
s/『G540』/fatherless/g
s/『G541』/radiance/g
s/『G542』/to fix one's eyes/g
s/『G543』/disobedience/g
s/『G544』/to disobey/g
s/『G545』/disobedient/g
s/『G546』/to threaten/g
s/『G547』/threat/g
s/『G548』/be away/g
s/『G549』/to go/g
s/『G550』/to renounce/g
s/『G551』/untempted/g
s/『G552』/unacquainted/g
s/『G553』/to expect/g
s/『G554』/to take off/g
s/『G555』/removal/g
s/『G556』/to eject/g
s/『G557』/discredit/g
s/『G558』/freedman/g
s/『G559』/Apelles/g
s/『G560』/to despair/g
s/『G561』/opposite/g
s/『G562』/endless/g
s/『G563』/undivided/g
s/『G564』/uncircumcised/g
s/『G565』/to go away/g
s/『G566』/to receive\/be far/g
s/『G567』/to receive\/be far/g
s/『G568』/to have in full/g
s/『G569』/to disbelieve/g
s/『G570』/unbelief/g
s/『G571』/unbelieving/g
s/『G572』/sincerity/g
s/『G573』/sound/g
s/『G574』/without reserve/g
s/『G575』/from/g
s/『G576』/to get out/g
s/『G577』/to throw away/g
s/『G578』/to look ahead/g
s/『G579』/rejected/g
s/『G580』/deprivation/g
s/『G581』/to cease to be/g
s/『G582』/census/g
s/『G583』/to register/g
s/『G584』/to display/g
s/『G585』/demonstration/g
s/『G586』/to tithe/g
s/『G587』/pleasing/g
s/『G588』/to welcome/g
s/『G589』/to go abroad/g
s/『G590』/absent/g
s/『G591』/to pay/g
s/『G592』/to divide/g
s/『G593』/to reject/g
s/『G594』/acceptance/g
s/『G595』/removal/g
s/『G596』/storehouse/g
s/『G597』/to store up/g
s/『G598』/to crowd up to/g
s/『G599』/to die/g
s/『G600』/to restore/g
s/『G601』/to reveal/g
s/『G602』/revelation/g
s/『G603』/eager expectation/g
s/『G604』/to reconcile/g
s/『G605』/restoration/g
s/『G606』/to lay up/g
s/『G607』/to behead/g
s/『G608』/to shut/g
s/『G609』/to cut off/g
s/『G610』/verdict/g
s/『G611』/to answer/g
s/『G612』/answer/g
s/『G613』/to conceal/g
s/『G614』/concealed/g
s/『G615』/to kill/g
s/『G616』/to generate/g
s/『G617』/to roll away/g
s/『G618』/to get back/g
s/『G619』/enjoyment/g
s/『G620』/to leave/g
s/『G621』/to lick/g
s/『G622』/to destroy/g
s/『G623』/Apollyon/g
s/『G624』/Apollonia/g
s/『G625』/Apollos/g
s/『G626』/to defend oneself/g
s/『G627』/defence/g
s/『G628』/to wash off/g
s/『G629』/redemption/g
s/『G630』/to release/g
s/『G631』/to wipe off/g
s/『G632』/to render as due/g
s/『G633』/to wash off/g
s/『G634』/to fall from/g
s/『G635』/to mislead/g
s/『G636』/to set sail/g
s/『G637』/to wash off/g
s/『G638』/to choke/g
s/『G639』/be perplexed/g
s/『G640』/perplexity/g
s/『G641』/to throw off/g
s/『G642』/to orphan/g
s/『G643』/to pack up/g
s/『G644』/shadow/g
s/『G645』/to draw away/g
s/『G646』/apostasy/g
s/『G647』/divorce/g
s/『G648』/to unroof/g
s/『G649』/to send/g
s/『G650』/to defraud/g
s/『G651』/apostleship/g
s/『G652』/apostle/g
s/『G653』/to interrogate/g
s/『G654』/to turn away/g
s/『G655』/to abhor/g
s/『G656』/excommunicated/g
s/『G657』/to leave/g
s/『G658』/to complete/g
s/『G659』/to put aside/g
s/『G660』/to shake off/g
s/『G661』/to repay/g
s/『G662』/be bold/g
s/『G663』/severity/g
s/『G664』/severely/g
s/『G665』/to avoid/g
s/『G666』/absence/g
s/『G667』/to carry off/g
s/『G668』/to escape/g
s/『G669』/to declare/g
s/『G670』/to unload/g
s/『G671』/using up/g
s/『G672』/to leave/g
s/『G673』/to separate from/g
s/『G674』/to faint/g
s/『G675』/Appius/g
s/『G676』/unapproachable/g
s/『G677』/not giving offence/g
s/『G678』/impartially/g
s/『G679』/without falling/g
s/『G680』/to touch/g
s/『G681』/to kindle/g
s/『G682』/Apphia/g
s/『G683』/to reject/g
s/『G684』/destruction/g
s/『G685』/curse/g
s/『G686』/therefore/g
s/『G687』/no?/g
s/『G688』/Arabia/g
s/『G689』/Aram/g
s/『G690』/Arabian/g
s/『G691』/be idle/g
s/『G692』/idle/g
s/『G693』/silver/g
s/『G694』/silver/g
s/『G695』/silversmith/g
s/『G696』/silver/g
s/『G697』/Mars' Hill/g
s/『G698』/Areopagite/g
s/『G699』/pleasing/g
s/『G700』/to please/g
s/『G701』/pleasing/g
s/『G702』/Aretas/g
s/『G703』/virtue/g
s/『G704』/lamb/g
s/『G705』/to number/g
s/『G706』/number/g
s/『G707』/Arimathea/g
s/『G708』/Aristarchus/g
s/『G709』/to eat early meal/g
s/『G710』/left/g
s/『G711』/Aristobulus/g
s/『G712』/early meal/g
s/『G713』/sufficient/g
s/『G714』/be sufficient/g
s/『G715』/bear/g
s/『G716』/chariot/g
s/『G717』/Armageddon/g
s/『G718』/to betroth/g
s/『G719』/joint/g
s/『G720』/to deny/g
s/『G721』/lamb/g
s/『G722』/to plow/g
s/『G723』/plow/g
s/『G724』/plunder/g
s/『G725』/something to grasp/g
s/『G726』/to seize/g
s/『G727』/rapacious/g
s/『G728』/guarantee/g
s/『G729』/seamless/g
s/『G730』/male/g
s/『G731』/inexpressible/g
s/『G732』/ill/g
s/『G733』/sodomy/g
s/『G734』/Artemas/g
s/『G735』/Artemis/g
s/『G736』/foresail/g
s/『G737』/now/g
s/『G738』/newborn/g
s/『G739』/competent/g
s/『G740』/bread/g
s/『G741』/to season/g
s/『G742』/Arphaxad/g
s/『G743』/archangel/g
s/『G744』/ancient/g
s/『G745』/Archelaus/g
s/『G746』/beginning/g
s/『G747』/founder/g
s/『G748』/high-priestly/g
s/『G749』/high-priest/g
s/『G750』/chief shepherd/g
s/『G751』/Archippus/g
s/『G752』/synagogue leader/g
s/『G753』/master-builder/g
s/『G754』/chief tax collector/g
s/『G755』/head waiter/g
s/『G756』/to rule\/begin/g
s/『G757』/be first/g
s/『G758』/ruler/g
s/『G759』/spices/g
s/『G760』/Asa/g
s/『G761』/unshakable/g
s/『G762』/unquenchable/g
s/『G763』/ungodlinessness/g
s/『G764』/be ungodly/g
s/『G765』/ungodly/g
s/『G766』/debauchery/g
s/『G767』/insignificant/g
s/『G768』/Asher/g
s/『G769』/weakness/g
s/『G770』/be weak/g
s/『G771』/weakness/g
s/『G772』/weak/g
s/『G773』/Asia/g
s/『G774』/Asian/g
s/『G775』/Asiarch/g
s/『G776』/fasting/g
s/『G777』/fasting/g
s/『G778』/to strive/g
s/『G779』/wineskin/g
s/『G780』/gladly/g
s/『G781』/unwise/g
s/『G782』/to pay respects to/g
s/『G783』/salutation/g
s/『G784』/spotless/g
s/『G785』/asp/g
s/『G786』/irreconcilable/g
s/『G787』/assarion/g
s/『G788』/nearer/g
s/『G789』/Assos/g
s/『G790』/be unsettled/g
s/『G791』/beautiful/g
s/『G792』/star/g
s/『G793』/unstable/g
s/『G794』/unfeeling/g
s/『G795』/to deviate/g
s/『G796』/lightning/g
s/『G797』/to flash/g
s/『G798』/star/g
s/『G799』/Asyncritus/g
s/『G800』/discordant/g
s/『G801』/senseless/g
s/『G802』/untrustworthy/g
s/『G803』/security/g
s/『G804』/secure/g
s/『G805』/to secure/g
s/『G806』/securely/g
s/『G807』/to act improperly/g
s/『G808』/indecency/g
s/『G809』/indecent/g
s/『G810』/debauchery/g
s/『G811』/in debauchery/g
s/『G812』/be idle/g
s/『G813』/disorderly/g
s/『G814』/idly/g
s/『G815』/childless/g
s/『G816』/to gaze/g
s/『G817』/without/g
s/『G818』/to dishonor/g
s/『G819』/dishonour/g
s/『G820』/dishonored/g
s/『G821』/to dishonor/g
s/『G822』/vapor/g
s/『G823』/instant/g
s/『G824』/wrong/g
s/『G825』/Attalia/g
s/『G826』/to see/g
s/『G827』/daybreak/g
s/『G828』/Augustus/g
s/『G829』/self-willed/g
s/『G830』/self-chosen/g
s/『G831』/to domineer/g
s/『G832』/to play the flute/g
s/『G833』/palace\/courtyard/g
s/『G834』/flute player/g
s/『G835』/to spend the night/g
s/『G836』/flute/g
s/『G837』/to grow/g
s/『G838』/growth/g
s/『G839』/tomorrow/g
s/『G840』/severe/g
s/『G841』/self-sufficiency/g
s/『G842』/self-sufficient/g
s/『G843』/self-condemned/g
s/『G844』/by itself/g
s/『G845』/eyewitness/g
s/『G846』/he\/she\/it\/self/g
s/『G847』/there/g
s/『G848』/him\/herself/g
s/『G849』/with one’s own hand/g
s/『G850』/dingy/g
s/『G851』/to remove/g
s/『G852』/hidden/g
s/『G853』/to destroy/g
s/『G854』/disappearance/g
s/『G855』/disappearing/g
s/『G856』/latrine/g
s/『G857』/unsparing/g
s/『G858』/sincerity/g
s/『G859』/forgiveness/g
s/『G860』/joint/g
s/『G861』/incorruptibility/g
s/『G862』/incorruptible/g
s/『G863』/to release/g
s/『G864』/to reach/g
s/『G865』/hating good/g
s/『G866』/not greedy/g
s/『G867』/departure/g
s/『G868』/to leave/g
s/『G869』/suddenly/g
s/『G870』/fearlessly/g
s/『G871』/to make like/g
s/『G872』/to consider/g
s/『G873』/to separate/g
s/『G874』/opportunity/g
s/『G875』/to foam/g
s/『G876』/foam/g
s/『G877』/foolishness/g
s/『G878』/foolish/g
s/『G879』/to fall sleep/g
s/『G880』/mute/g
s/『G881』/Ahaz/g
s/『G882』/Achaia/g
s/『G883』/Achaicus/g
s/『G884』/ungrateful/g
s/『G885』/Akim/g
s/『G886』/not man-made/g
s/『G887』/mist/g
s/『G888』/worthless/g
s/『G889』/to make worthless/g
s/『G890』/useless/g
s/『G891』/until/g
s/『G892』/chaff/g
s/『G893』/not a liar/g
s/『G894』/wormwood/g
s/『G895』/lifeless/g
s/『G896』/Baal/g
s/『G897』/Babylon/g
s/『G898』/standing/g
s/『G899』/depth/g
s/『G900』/to dig deep/g
s/『G901』/deep/g
s/『G902』/palm branch/g
s/『G903』/Balaam/g
s/『G904』/Balak/g
s/『G905』/purse/g
s/『G906』/to throw/g
s/『G907』/to baptize/g
s/『G908』/baptism/g
s/『G909』/baptism/g
s/『G910』/one who baptizes/g
s/『G911』/to dip/g
s/『G912』/Barabbas/g
s/『G913』/Barak/g
s/『G914』/Berekiah/g
s/『G915』/barbarian/g
s/『G916』/to burden/g
s/『G917』/difficultly/g
s/『G918』/Bartholomew/g
s/『G919』/Bar-Jesus/g
s/『G920』/son of Jonas/g
s/『G921』/Barnabas/g
s/『G922』/burden/g
s/『G923』/Barsabbas/g
s/『G924』/Bartimaeus/g
s/『G925』/to weigh down/g
s/『G926』/weighty/g
s/『G927』/expensive/g
s/『G928』/to torture/g
s/『G929』/torment/g
s/『G930』/torturer/g
s/『G931』/torment/g
s/『G932』/kingdom/g
s/『G933』/palace/g
s/『G934』/kingly/g
s/『G935』/king/g
s/『G936』/to reign/g
s/『G937』/royal/g
s/『G938』/queen/g
s/『G939』/foot/g
s/『G940』/to bewitch/g
s/『G941』/to carry/g
s/『G942』/thorn bush/g
s/『G943』/bath/g
s/『G944』/frog/g
s/『G945』/to babble/g
s/『G946』/abomination/g
s/『G947』/abominable/g
s/『G948』/to abhor/g
s/『G949』/firm/g
s/『G950』/to confirm/g
s/『G951』/confirmation/g
s/『G952』/profane/g
s/『G953』/to profane/g
s/『G954』/Beelzebub/g
s/『G955』/Belial/g
s/『G956』/arrow/g
s/『G957』/better/g
s/『G958』/Benjamin/g
s/『G959』/Bernice/g
s/『G960』/Berea/g
s/『G961』/Berean/g
s/『G962』/Bethabara/g
s/『G963』/Bethany/g
s/『G964』/Bethesda/g
s/『G965』/Bethlehem/g
s/『G966』/Bethsaida/g
s/『G967』/Bethphage/g
s/『G968』/judgement seat/g
s/『G969』/beryl/g
s/『G970』/force/g
s/『G971』/to force/g
s/『G972』/strong/g
s/『G973』/forceful person/g
s/『G974』/little scroll/g
s/『G975』/scroll/g
s/『G976』/book/g
s/『G977』/to eat/g
s/『G978』/Bithynia/g
s/『G979』/life/g
s/『G980』/to live/g
s/『G981』/lifestyle/g
s/『G982』/of this life/g
s/『G983』/harmful/g
s/『G984』/to hurt/g
s/『G985』/to sprout/g
s/『G986』/Blastus/g
s/『G987』/to blaspheme/g
s/『G988』/blasphemy/g
s/『G989』/blasphemous/g
s/『G990』/a look/g
s/『G991』/to see/g
s/『G992』/must be put/g
s/『G993』/Boanerges/g
s/『G994』/to cry out/g
s/『G995』/outcry/g
s/『G996』/help/g
s/『G997』/to help/g
s/『G998』/a helper/g
s/『G999』/pit/g
s/『G1000』/throwing/g
s/『G1001』/to sound/g
s/『G1002』/arrow/g
s/『G1003』/Boaz/g
s/『G1004』/mire/g
s/『G1005』/the north/g
s/『G1006』/to feed/g
s/『G1007』/Beor/g
s/『G1008』/crop/g
s/『G1009』/bunch of grapes/g
s/『G1010』/member of a council/g
s/『G1011』/to plan/g
s/『G1012』/plan/g
s/『G1013』/plan/g
s/『G1014』/to plan/g
s/『G1015』/hill/g
s/『G1016』/ox/g
s/『G1017』/prize/g
s/『G1018』/to rule/g
s/『G1019』/to delay/g
s/『G1020』/to sail slowly/g
s/『G1021』/slow/g
s/『G1022』/slowness/g
s/『G1023』/arm/g
s/『G1024』/little/g
s/『G1025』/infant/g
s/『G1026』/to rain down/g
s/『G1027』/thunder/g
s/『G1028』/rain/g
s/『G1029』/restraint/g
s/『G1030』/gnashing/g
s/『G1031』/to gnash/g
s/『G1032』/to pour/g
s/『G1033』/food/g
s/『G1034』/edible/g
s/『G1035』/eating/g
s/『G1036』/to sink/g
s/『G1037』/the deep/g
s/『G1038』/tanner/g
s/『G1039』/fine linen/g
s/『G1040』/fine linen/g
s/『G1041』/altar/g
s/『G1042』/Gabbatha/g
s/『G1043』/Gabriel/g
s/『G1044』/gangrene/g
s/『G1045』/Gad/g
s/『G1046』/Gadarene/g
s/『G1047』/treasury/g
s/『G1048』/Gazah/g
s/『G1049』/treasury/g
s/『G1050』/Gaius/g
s/『G1051』/milk/g
s/『G1052』/Galatian/g
s/『G1053』/Galatia/g
s/『G1054』/Galatian/g
s/『G1055』/calm/g
s/『G1056』/Galilee/g
s/『G1057』/Galilean/g
s/『G1058』/Gallio/g
s/『G1059』/Gamaliel/g
s/『G1060』/to marry/g
s/『G1061』/to give in marriage/g
s/『G1062』/wedding/g
s/『G1063』/for/g
s/『G1064』/belly/g
s/『G1065』/indeed/g
s/『G1066』/Gideon/g
s/『G1067』/Gehenna/g
s/『G1068』/Gethsemane/g
s/『G1069』/neighbour/g
s/『G1070』/to laugh/g
s/『G1071』/laughter/g
s/『G1072』/to fill/g
s/『G1073』/be full/g
s/『G1074』/generation/g
s/『G1075』/to trace genealogy/g
s/『G1076』/genealogy/g
s/『G1077』/birthday/g
s/『G1078』/origin/g
s/『G1079』/birth/g
s/『G1080』/to beget/g
s/『G1081』/offspring/g
s/『G1082』/Gennesaret/g
s/『G1083』/birth/g
s/『G1084』/born/g
s/『G1085』/family/g
s/『G1086』/Gerasene/g
s/『G1087』/council of elders/g
s/『G1088』/an old man/g
s/『G1089』/to taste/g
s/『G1090』/to farm/g
s/『G1091』/farm field/g
s/『G1092』/farmer/g
s/『G1093』/earth/g
s/『G1094』/old age/g
s/『G1095』/to grow old/g
s/『G1096』/to be/g
s/『G1097』/to know/g
s/『G1098』/sweet wine/g
s/『G1099』/sweet/g
s/『G1100』/tongue/g
s/『G1101』/moneybag/g
s/『G1102』/one who bleaches/g
s/『G1103』/genuine/g
s/『G1104』/genuinely/g
s/『G1105』/darkness/g
s/『G1106』/resolution/g
s/『G1107』/to make known/g
s/『G1108』/knowledge/g
s/『G1109』/expert in/g
s/『G1110』/acquainted with/g
s/『G1111』/to murmur/g
s/『G1112』/murmuring/g
s/『G1113』/a murmurer/g
s/『G1114』/imposter/g
s/『G1115』/Golgotha/g
s/『G1116』/Gomorrah/g
s/『G1117』/cargo/g
s/『G1118』/parent/g
s/『G1119』/a knee/g
s/『G1120』/to kneel/g
s/『G1121』/something written/g
s/『G1122』/scribe/g
s/『G1123』/written/g
s/『G1124』/a writing/g
s/『G1125』/to write/g
s/『G1126』/old wives’ tale/g
s/『G1127』/to keep watch/g
s/『G1128』/to train/g
s/『G1129』/training/g
s/『G1130』/be naked/g
s/『G1131』/naked/g
s/『G1132』/nakedness/g
s/『G1133』/weak-willed woman/g
s/『G1134』/feminine/g
s/『G1135』/woman/g
s/『G1136』/Gog/g
s/『G1137』/corner/g
s/『G1138』/David/g
s/『G1139』/be demonised/g
s/『G1140』/demon/g
s/『G1141』/demonic/g
s/『G1142』/demon/g
s/『G1143』/to bite/g
s/『G1144』/teardrop/g
s/『G1145』/to weep/g
s/『G1146』/ring/g
s/『G1147』/finger/g
s/『G1148』/Dalmanutha/g
s/『G1149』/Dalmatia/g
s/『G1150』/to tame/g
s/『G1151』/heifer/g
s/『G1152』/Damaris/g
s/『G1153』/from Damascus/g
s/『G1154』/Damascus/g
s/『G1155』/to lend\/borrow/g
s/『G1156』/debt/g
s/『G1157』/moneylender/g
s/『G1158』/Daniel/g
s/『G1159』/to spend/g
s/『G1160』/cost/g
s/『G1161』/but\/and/g
s/『G1162』/prayer/g
s/『G1163』/be necessary/g
s/『G1164』/example/g
s/『G1165』/to disgrace/g
s/『G1166』/to show/g
s/『G1167』/timidity/g
s/『G1168』/be timid/g
s/『G1169』/timid/g
s/『G1170』/a certain one/g
s/『G1171』/terribly/g
s/『G1172』/to dine/g
s/『G1173』/dinner/g
s/『G1174』/religious/g
s/『G1175』/religion/g
s/『G1176』/ten/g
s/『G1177』/twelve/g
s/『G1178』/fifteen/g
s/『G1179』/Decapolis/g
s/『G1180』/fourteen/g
s/『G1181』/tenth/g
s/『G1182』/tenth/g
s/『G1183』/to tithe/g
s/『G1184』/acceptable/g
s/『G1185』/to entice/g
s/『G1186』/tree/g
s/『G1187』/slinger/g
s/『G1188』/right/g
s/『G1189』/to pray/g
s/『G1190』/from Derbe/g
s/『G1191』/Derbe/g
s/『G1192』/leather/g
s/『G1193』/made of leather/g
s/『G1194』/to beat up/g
s/『G1195』/to bind/g
s/『G1196』/to bind/g
s/『G1197』/bundle/g
s/『G1198』/prisoner/g
s/『G1199』/chain/g
s/『G1200』/jailer/g
s/『G1201』/prison/g
s/『G1202』/prisoner/g
s/『G1203』/master/g
s/『G1204』/come/g
s/『G1205』/come/g
s/『G1206』/the next day/g
s/『G1207』/second-first/g
s/『G1208』/secondly/g
s/『G1209』/to receive/g
s/『G1210』/to bind/g
s/『G1211』/so/g
s/『G1212』/clear/g
s/『G1213』/to make clear/g
s/『G1214』/Demas/g
s/『G1215』/to give a speech/g
s/『G1216』/Demetrius/g
s/『G1217』/builder/g
s/『G1218』/people/g
s/『G1219』/public/g
s/『G1220』/denarius/g
s/『G1221』/whatever/g
s/『G1222』/surely/g
s/『G1223』/through\/because of/g
s/『G1224』/to cross/g
s/『G1225』/to accuse/g
s/『G1226』/to insist/g
s/『G1227』/to see clearly/g
s/『G1228』/devilish\/the Devil/g
s/『G1229』/to proclaim/g
s/『G1230』/to pass/g
s/『G1231』/to decide/g
s/『G1232』/to report/g
s/『G1233』/decision/g
s/『G1234』/to murmur/g
s/『G1235』/to wake/g
s/『G1236』/to live/g
s/『G1237』/to receive in turn/g
s/『G1238』/diadem/g
s/『G1239』/to distribute/g
s/『G1240』/successor/g
s/『G1241』/to tie around/g
s/『G1242』/covenant/g
s/『G1243』/variety/g
s/『G1244』/to distribute/g
s/『G1245』/to clear out/g
s/『G1246』/to refute/g
s/『G1247』/to serve/g
s/『G1248』/service/g
s/『G1249』/servant/g
s/『G1250』/two hundred/g
s/『G1251』/to give a hearing/g
s/『G1252』/to judge\/doubt/g
s/『G1253』/discernment/g
s/『G1254』/to hinder/g
s/『G1255』/to discuss/g
s/『G1256』/to dispute/g
s/『G1257』/to stop/g
s/『G1258』/language/g
s/『G1259』/be reconciled/g
s/『G1260』/to reason/g
s/『G1261』/reasoning/g
s/『G1262』/to disperse/g
s/『G1263』/to testify solemnly/g
s/『G1264』/to contend sharply/g
s/『G1265』/to remain/g
s/『G1266』/to divide/g
s/『G1267』/division/g
s/『G1268』/to spread/g
s/『G1269』/to signify/g
s/『G1270』/thought/g
s/『G1271』/mind/g
s/『G1272』/to open/g
s/『G1273』/to spend the night/g
s/『G1274』/to continue/g
s/『G1275』/always/g
s/『G1276』/to cross/g
s/『G1277』/to sail across/g
s/『G1278』/be vexed/g
s/『G1279』/to go through/g
s/『G1280』/be perplexed/g
s/『G1281』/to gain in trade/g
s/『G1282』/be furious/g
s/『G1283』/to rob/g
s/『G1284』/to tear/g
s/『G1285』/to explain/g
s/『G1286』/to extort/g
s/『G1287』/to scatter/g
s/『G1288』/to tear apart/g
s/『G1289』/to scatter/g
s/『G1290』/dispersion/g
s/『G1291』/to give orders/g
s/『G1292』/interval/g
s/『G1293』/distinction/g
s/『G1294』/to pervert/g
s/『G1295』/to save/g
s/『G1296』/ordinance/g
s/『G1297』/edict/g
s/『G1298』/to trouble/g
s/『G1299』/to direct/g
s/『G1300』/to continue/g
s/『G1301』/to keep/g
s/『G1302』/why?/g
s/『G1303』/to make a covenant/g
s/『G1304』/to remain/g
s/『G1305』/food/g
s/『G1306』/to shine through/g
s/『G1307』/transparent/g
s/『G1308』/to spread\/surpass/g
s/『G1309』/to escape/g
s/『G1310』/to publish abroad/g
s/『G1311』/to corrupt/g
s/『G1312』/decay/g
s/『G1313』/different/g
s/『G1314』/to protect/g
s/『G1315』/to kill/g
s/『G1316』/be separated/g
s/『G1317』/able to teach/g
s/『G1318』/taught/g
s/『G1319』/teaching/g
s/『G1320』/teacher/g
s/『G1321』/to teach/g
s/『G1322』/teaching/g
s/『G1323』/two-drachma/g
s/『G1324』/Didymus/g
s/『G1325』/to give/g
s/『G1326』/to arouse/g
s/『G1327』/thoroughfare/g
s/『G1328』/interpreter/g
s/『G1329』/to interpret/g
s/『G1330』/to pass through/g
s/『G1331』/to ascertain/g
s/『G1332』/two years old/g
s/『G1333』/two years/g
s/『G1334』/to relate fully/g
s/『G1335』/narrative/g
s/『G1336』/perpetual/g
s/『G1337』/sandbar/g
s/『G1338』/to penetrate/g
s/『G1339』/to pass/g
s/『G1340』/to insist/g
s/『G1341』/justice/g
s/『G1342』/just/g
s/『G1343』/righteousness/g
s/『G1344』/to justify/g
s/『G1345』/righteous act/g
s/『G1346』/rightly/g
s/『G1347』/justification/g
s/『G1348』/judge/g
s/『G1349』/condemnation/g
s/『G1350』/net/g
s/『G1351』/insincere/g
s/『G1352』/therefore/g
s/『G1353』/to go through/g
s/『G1354』/Dionysius/g
s/『G1355』/therefore/g
s/『G1356』/fallen from heaven/g
s/『G1357』/reformation/g
s/『G1358』/to break in/g
s/『G1359』/the twin gods/g
s/『G1360』/because/g
s/『G1361』/Diotrephes/g
s/『G1362』/double/g
s/『G1363』/to double/g
s/『G1364』/twice/g
s/『G1365』/to doubt/g
s/『G1366』/double-edged/g
s/『G1367』/two thousand/g
s/『G1368』/to strain out/g
s/『G1369』/to disunite/g
s/『G1370』/dissension/g
s/『G1371』/to cut in two/g
s/『G1372』/to thirst/g
s/『G1373』/thirst/g
s/『G1374』/double-minded/g
s/『G1375』/persecution/g
s/『G1376』/persecutor/g
s/『G1377』/to pursue/g
s/『G1378』/decree/g
s/『G1379』/to decree/g
s/『G1380』/to think/g
s/『G1381』/to test/g
s/『G1382』/test/g
s/『G1383』/testing/g
s/『G1384』/tested/g
s/『G1385』/plank/g
s/『G1386』/deceitful/g
s/『G1387』/to deceive/g
s/『G1388』/deceit/g
s/『G1389』/to distort/g
s/『G1390』/gift/g
s/『G1391』/glory/g
s/『G1392』/to glorify/g
s/『G1393』/Dorcas/g
s/『G1394』/gift/g
s/『G1395』/giver/g
s/『G1396』/to enslave/g
s/『G1397』/slavery/g
s/『G1398』/be a slave/g
s/『G1399』/female slave/g
s/『G1400』/slave/g
s/『G1401』/slave/g
s/『G1402』/to enslave/g
s/『G1403』/banquet/g
s/『G1404』/dragon/g
s/『G1405』/to catch/g
s/『G1406』/drachma/g
s/『G1407』/sickle/g
s/『G1408』/racecourse/g
s/『G1409』/Drusilla/g
s/『G1410』/be able/g
s/『G1411』/power/g
s/『G1412』/to strengthen/g
s/『G1413』/ruler/g
s/『G1414』/be able/g
s/『G1415』/able/g
s/『G1416』/to set/g
s/『G1417』/two/g
s/『G1418』/hard/g
s/『G1419』/ponderous/g
s/『G1420』/dysentery/g
s/『G1421』/hard to interpret/g
s/『G1422』/difficult/g
s/『G1423』/difficultly/g
s/『G1424』/west/g
s/『G1425』/hard to understand/g
s/『G1426』/slander/g
s/『G1427』/twelve/g
s/『G1428』/twelfth/g
s/『G1429』/twelve tribes/g
s/『G1430』/housetop/g
s/『G1431』/free gift/g
s/『G1432』/freely/g
s/『G1433』/to give/g
s/『G1434』/free gift/g
s/『G1435』/gift/g
s/『G1436』/ha!\/aha!/g
s/『G1437』/if/g
s/『G1438』/my\/your\/him-self/g
s/『G1439』/to allow/g
s/『G1440』/seventy/g
s/『G1441』/seventy times/g
s/『G1442』/seventh/g
s/『G1443』/Eber/g
s/『G1444』/Hebrew/g
s/『G1445』/a Hebrew/g
s/『G1446』/Aramaic/g
s/『G1447』/in Aramaic/g
s/『G1448』/to come near/g
s/『G1449』/to write in/g
s/『G1450』/guarantor/g
s/『G1451』/near/g
s/『G1452』/nearer/g
s/『G1453』/to arise/g
s/『G1454』/resurrection/g
s/『G1455』/a spy/g
s/『G1456』/Feast of Dedication/g
s/『G1457』/to inaugurate/g
s/『G1458』/to accuse/g
s/『G1459』/to leave behind/g
s/『G1460』/to live among/g
s/『G1461』/to ingraft/g
s/『G1462』/accusation/g
s/『G1463』/to clothe oneself/g
s/『G1464』/hindrance/g
s/『G1465』/to hinder/g
s/『G1466』/self-control/g
s/『G1467』/to self-control/g
s/『G1468』/self-controlled/g
s/『G1469』/to classify/g
s/『G1470』/to mix/g
s/『G1471』/pregnant/g
s/『G1472』/to rub on/g
s/『G1473』/I\/we/g
s/『G1474』/to raze/g
s/『G1475』/ground/g
s/『G1476』/steadfast/g
s/『G1477』/foundation/g
s/『G1478』/Hezekiah/g
s/『G1479』/self-made religion/g
s/『G1480』/be accustomed/g
s/『G1481』/governor/g
s/『G1482』/Gentile/g
s/『G1483』/Gentile-like/g
s/『G1484』/Gentiles/g
s/『G1485』/custom/g
s/『G1486』/to have a custom/g
s/『G1487』/if/g
s/『G1488』/you are/g
s/『G1489』/if indeed\/otherwise/g
s/『G1490』/but if not/g
s/『G1491』/appearance/g
s/『G1492』/to know/g
s/『G1493』/idol's temple/g
s/『G1494』/sacrificed to idols/g
s/『G1495』/idolatry/g
s/『G1496』/idolater/g
s/『G1497』/idol/g
s/『G1498』/may be/g
s/『G1499』/if also/g
s/『G1500』/in vain/g
s/『G1501』/twenty/g
s/『G1502』/to yield/g
s/『G1503』/to resemble/g
s/『G1504』/image/g
s/『G1505』/sincerity/g
s/『G1506』/pure/g
s/『G1507』/to roll up/g
s/『G1508』/except/g
s/『G1509』/except what/g
s/『G1510』/to be/g
s/『G1511』/to exist/g
s/『G1512』/if so\/since/g
s/『G1513』/if somehow/g
s/『G1514』/be at peace/g
s/『G1515』/peace/g
s/『G1516』/peaceful/g
s/『G1517』/to make peace/g
s/『G1518』/peacemaker/g
s/『G1519』/toward/g
s/『G1520』/one/g
s/『G1521』/to bring in/g
s/『G1522』/to listen to/g
s/『G1523』/to receive/g
s/『G1524』/to enter/g
s/『G1525』/to enter/g
s/『G1526』/they are/g
s/『G1527』/one by one/g
s/『G1528』/to invite/g
s/『G1529』/entry/g
s/『G1530』/to rush into/g
s/『G1531』/to enter/g
s/『G1532』/to run in/g
s/『G1533』/to bring in/g
s/『G1534』/then/g
s/『G1535』/if/g
s/『G1536』/if any/g
s/『G1537』/of\/from/g
s/『G1538』/each/g
s/『G1539』/always/g
s/『G1540』/hundred/g
s/『G1541』/a hundred years old/g
s/『G1542』/a hundred times/g
s/『G1543』/centurion/g
s/『G1544』/to expel/g
s/『G1545』/way out/g
s/『G1546』/jettisoning/g
s/『G1547』/to marry/g
s/『G1548』/to give in marriage/g
s/『G1549』/descendant/g
s/『G1550』/to expend/g
s/『G1551』/to wait for/g
s/『G1552』/clearly evident/g
s/『G1553』/be away/g
s/『G1554』/to lease/g
s/『G1555』/to tell in detail/g
s/『G1556』/to avenge/g
s/『G1557』/vengeance/g
s/『G1558』/avenging/g
s/『G1559』/to persecute/g
s/『G1560』/handed over/g
s/『G1561』/expectation/g
s/『G1562』/to strip/g
s/『G1563』/there/g
s/『G1564』/from there/g
s/『G1565』/that/g
s/『G1566』/there/g
s/『G1567』/to seek out/g
s/『G1568』/be awe-struck/g
s/『G1569』/astonished/g
s/『G1570』/exposed/g
s/『G1571』/to cleanse/g
s/『G1572』/be enflamed/g
s/『G1573』/to lose heart/g
s/『G1574』/to pierce/g
s/『G1575』/to break off/g
s/『G1576』/to exclude/g
s/『G1577』/assembly/g
s/『G1578』/to turn from/g
s/『G1579』/to swim out/g
s/『G1580』/to carry out/g
s/『G1581』/to cut off/g
s/『G1582』/to hang upon/g
s/『G1583』/to speak out/g
s/『G1584』/to shine out/g
s/『G1585』/to forget/g
s/『G1586』/to select/g
s/『G1587』/to fail/g
s/『G1588』/select/g
s/『G1589』/selecting/g
s/『G1590』/to faint/g
s/『G1591』/to wipe off/g
s/『G1592』/to ridicule/g
s/『G1593』/to withdraw/g
s/『G1594』/to wake up/g
s/『G1595』/voluntary/g
s/『G1596』/voluntarily/g
s/『G1597』/of old/g
s/『G1598』/to test\/tempt/g
s/『G1599』/to send away\/out/g
s/『G1600』/to extend/g
s/『G1601』/to fall out/g
s/『G1602』/to sail out\/away/g
s/『G1603』/to fulfill/g
s/『G1604』/fulfillment/g
s/『G1605』/be astonished/g
s/『G1606』/to expire/g
s/『G1607』/to come\/go out/g
s/『G1608』/to fornicate/g
s/『G1609』/to spit out/g
s/『G1610』/to uproot/g
s/『G1611』/amazement/g
s/『G1612』/be warped/g
s/『G1613』/to disturb greatly/g
s/『G1614』/to stretch out/g
s/『G1615』/to finish up/g
s/『G1616』/earnestness/g
s/『G1617』/earnestly/g
s/『G1618』/deep\/earnest/g
s/『G1619』/intently/g
s/『G1620』/to explain\/expose/g
s/『G1621』/to shake out\/off/g
s/『G1622』/outside\/except/g
s/『G1623』/sixth/g
s/『G1624』/to turn\/wander away/g
s/『G1625』/to nourish\/rear/g
s/『G1626』/untimely birth/g
s/『G1627』/to bring\/carry out/g
s/『G1628』/to escape/g
s/『G1629』/to terrify/g
s/『G1630』/terrified/g
s/『G1631』/to put out/g
s/『G1632』/to pour out/g
s/『G1633』/to go out/g
s/『G1634』/to expire/g
s/『G1635』/voluntarily/g
s/『G1636』/olive tree/g
s/『G1637』/olive oil/g
s/『G1638』/Olivet/g
s/『G1639』/Elamite/g
s/『G1640』/lesser/g
s/『G1641』/to have little/g
s/『G1642』/to make less/g
s/『G1643』/to drive/g
s/『G1644』/lightness/g
s/『G1645』/light/g
s/『G1646』/least/g
s/『G1647』/least/g
s/『G1648』/Eleazar/g
s/『G1649』/rebuke/g
s/『G1650』/rebuke/g
s/『G1651』/to rebuke/g
s/『G1652』/pitiful/g
s/『G1653』/to have mercy/g
s/『G1654』/charity/g
s/『G1655』/merciful/g
s/『G1656』/mercy/g
s/『G1657』/freedom/g
s/『G1658』/free\/freedom/g
s/『G1659』/to set free/g
s/『G1660』/coming/g
s/『G1661』/made of ivory/g
s/『G1662』/Eliakim/g
s/『G1663』/Eliezer/g
s/『G1664』/Eliud/g
s/『G1665』/Elizabeth/g
s/『G1666』/Elisha/g
s/『G1667』/to roll up/g
s/『G1668』/sore/g
s/『G1669』/to have\/cause sores/g
s/『G1670』/to draw\/persuade/g
s/『G1671』/Greece/g
s/『G1672』/a Greek/g
s/『G1673』/Greek/g
s/『G1674』/Greek woman/g
s/『G1675』/Hellenist/g
s/『G1676』/in Greek/g
s/『G1677』/to charge/g
s/『G1678』/Elmadam/g
s/『G1679』/to hope\/expect/g
s/『G1680』/hope/g
s/『G1681』/Elymas/g
s/『G1682』/my God/g
s/『G1683』/myself/g
s/『G1684』/to get into/g
s/『G1685』/to throw in/g
s/『G1686』/to dip in/g
s/『G1687』/to investigate/g
s/『G1688』/to put on board/g
s/『G1689』/to look into\/upon/g
s/『G1690』/be agitated/g
s/『G1691』/me/g
s/『G1692』/to vomit/g
s/『G1693』/be enraged/g
s/『G1694』/Immanuel/g
s/『G1695』/Emmaus/g
s/『G1696』/to abide in\/by/g
s/『G1697』/Hamor/g
s/『G1698』/I/g
s/『G1699』/my/g
s/『G1700』/of me/g
s/『G1701』/jeering/g
s/『G1702』/to mock/g
s/『G1703』/a mocker/g
s/『G1704』/to walk in\/among/g
s/『G1705』/to fill up/g
s/『G1706』/to fall into/g
s/『G1707』/to entangle\/involve/g
s/『G1708』/braiding/g
s/『G1709』/to breath into/g
s/『G1710』/to traffic in/g
s/『G1711』/trade\/business/g
s/『G1712』/marketplace\/trade/g
s/『G1713』/trader\/merchant/g
s/『G1714』/to burn/g
s/『G1715』/before/g
s/『G1716』/to spit on\/at/g
s/『G1717』/revealed/g
s/『G1718』/to show/g
s/『G1719』/afraid/g
s/『G1720』/to breathe into/g
s/『G1721』/implanted\/ingrafted/g
s/『G1722』/in\/on\/among/g
s/『G1723』/to embrace/g
s/『G1724』/marine/g
s/『G1725』/before/g
s/『G1726』/before/g
s/『G1727』/against/g
s/『G1728』/to begin/g
s/『G1729』/impoverished/g
s/『G1730』/evidence/g
s/『G1731』/to show/g
s/『G1732』/demonstration/g
s/『G1733』/eleven/g
s/『G1734』/eleventh/g
s/『G1735』/be possible/g
s/『G1736』/be home/g
s/『G1737』/to dress/g
s/『G1738』/just/g
s/『G1739』/material/g
s/『G1740』/be glorified/g
s/『G1741』/honored/g
s/『G1742』/clothing/g
s/『G1743』/to strengthen/g
s/『G1744』/to sneak/g
s/『G1745』/wearing/g
s/『G1746』/to clothe/g
s/『G1747』/plot\/ambush/g
s/『G1748』/to ambush/g
s/『G1749』/ambush/g
s/『G1750』/to enwrap/g
s/『G1751』/be in/g
s/『G1752』/because of/g
s/『G1753』/active energy/g
s/『G1754』/be active/g
s/『G1755』/working/g
s/『G1756』/effective/g
s/『G1757』/be blessed/g
s/『G1758』/to oppose/g
s/『G1759』/in\/to this place/g
s/『G1760』/to reflect on/g
s/『G1761』/reflection/g
s/『G1762』/there is/g
s/『G1763』/year/g
s/『G1764』/be present/g
s/『G1765』/to strengthen/g
s/『G1766』/ninth \(hour\)/g
s/『G1767』/nine/g
s/『G1768』/ninety/g
s/『G1769』/speechless/g
s/『G1770』/to signify/g
s/『G1771』/thought\/purpose/g
s/『G1772』/under law/g
s/『G1773』/at night/g
s/『G1774』/to dwell in\/with/g
s/『G1775』/unity/g
s/『G1776』/to trouble/g
s/『G1777』/liable for/g
s/『G1778』/precept/g
s/『G1779』/to prepare burial/g
s/『G1780』/burial/g
s/『G1781』/to order/g
s/『G1782』/from here/g
s/『G1783』/intercession/g
s/『G1784』/valued\/honored/g
s/『G1785』/commandment/g
s/『G1786』/resident/g
s/『G1787』/inside/g
s/『G1788』/to cause shame/g
s/『G1789』/be reared/g
s/『G1790』/trembling/g
s/『G1791』/shame/g
s/『G1792』/to revel/g
s/『G1793』/to call on/g
s/『G1794』/to wrap up/g
s/『G1795』/to engrave/g
s/『G1796』/to insult/g
s/『G1797』/to dream/g
s/『G1798』/dream/g
s/『G1799』/before/g
s/『G1800』/Enosh/g
s/『G1801』/to listen to/g
s/『G1802』/Enoch/g
s/『G1803』/six/g
s/『G1804』/to proclaim/g
s/『G1805』/to redeem/g
s/『G1806』/to lead out/g
s/『G1807』/to take out\/select/g
s/『G1808』/to expel/g
s/『G1809』/to demand\/ask for/g
s/『G1810』/suddenly/g
s/『G1811』/to follow/g
s/『G1812』/six hundred/g
s/『G1813』/to blot out/g
s/『G1814』/to leap up/g
s/『G1815』/resurrection/g
s/『G1816』/to sprout up/g
s/『G1817』/to raise up/g
s/『G1818』/to deceive/g
s/『G1819』/suddenly/g
s/『G1820』/to despair/g
s/『G1821』/to send out\/away/g
s/『G1822』/to finish\/furnish/g
s/『G1823』/to flash forth/g
s/『G1824』/immediately/g
s/『G1825』/to raise/g
s/『G1826』/to go out\/away/g
s/『G1827』/to convict/g
s/『G1828』/to drag out\/away/g
s/『G1829』/vomit/g
s/『G1830』/to search out/g
s/『G1831』/to go out/g
s/『G1832』/it is permitted/g
s/『G1833』/to find out/g
s/『G1834』/to tell/g
s/『G1835』/sixty/g
s/『G1836』/next\/afterward/g
s/『G1837』/to ring\/sound out/g
s/『G1838』/habit\/practice/g
s/『G1839』/to amaze/g
s/『G1840』/to have power/g
s/『G1841』/departure/g
s/『G1842』/to root out/g
s/『G1843』/to agree/g
s/『G1844』/to adjure/g
s/『G1845』/exorcist/g
s/『G1846』/to dig through\/out/g
s/『G1847』/be rejected/g
s/『G1848』/to reject/g
s/『G1849』/authority/g
s/『G1850』/to have authority/g
s/『G1851』/prominent/g
s/『G1852』/to awake/g
s/『G1853』/awake/g
s/『G1854』/out\/outside\(r\)/g
s/『G1855』/outside/g
s/『G1856』/to expel/g
s/『G1857』/outer/g
s/『G1858』/to keep a festival/g
s/『G1859』/festival/g
s/『G1860』/promise/g
s/『G1861』/to profess/g
s/『G1862』/a promise/g
s/『G1863』/to bring upon/g
s/『G1864』/to contend/g
s/『G1865』/to collect\/crowd/g
s/『G1866』/Epaenetus/g
s/『G1867』/to praise/g
s/『G1868』/praise/g
s/『G1869』/to lift up/g
s/『G1870』/be ashamed of/g
s/『G1871』/to ask\/beg/g
s/『G1872』/to follow after/g
s/『G1873』/to listen to/g
s/『G1874』/to listen ro/g
s/『G1875』/when\/as soon as/g
s/『G1876』/necessarily/g
s/『G1877』/to put up\/back\/off/g
s/『G1878』/to remind/g
s/『G1879』/to rest\/rely on/g
s/『G1880』/to return/g
s/『G1881』/to rebel against/g
s/『G1882』/correcting/g
s/『G1883』/above/g
s/『G1884』/to help/g
s/『G1885』/province/g
s/『G1886』/residence/g
s/『G1887』/the next day/g
s/『G1888』/in the very act/g
s/『G1889』/Epaphras/g
s/『G1890』/to foam up/g
s/『G1891』/Epaphroditus/g
s/『G1892』/to awaken\/rouse/g
s/『G1893』/since/g
s/『G1894』/since/g
s/『G1895』/since/g
s/『G1896』/to look upon/g
s/『G1897』/since/g
s/『G1898』/introduction/g
s/『G1899』/then/g
s/『G1900』/beyond/g
s/『G1901』/to reach out to/g
s/『G1902』/be clothed/g
s/『G1903』/coat/g
s/『G1904』/to arrive\/invade/g
s/『G1905』/to question/g
s/『G1906』/pledge/g
s/『G1907』/to hold fast\/out/g
s/『G1908』/to mistreat/g
s/『G1909』/upon\/to\/against/g
s/『G1910』/to mount\/board/g
s/『G1911』/to put on\/seize/g
s/『G1912』/to burden/g
s/『G1913』/to mount/g
s/『G1914』/to look upon\/at/g
s/『G1915』/patch/g
s/『G1916』/to cry out/g
s/『G1917』/plot/g
s/『G1918』/to marry/g
s/『G1919』/earthly/g
s/『G1920』/to arise\/spring up/g
s/『G1921』/to come to know/g
s/『G1922』/knowledge/g
s/『G1923』/inscription/g
s/『G1924』/to write on/g
s/『G1925』/to show\/prove/g
s/『G1926』/to welcome/g
s/『G1927』/to sojourn/g
s/『G1928』/to add to/g
s/『G1929』/to give\/deliver/g
s/『G1930』/to straighten out/g
s/『G1931』/to set/g
s/『G1932』/gentleness/g
s/『G1933』/gentle/g
s/『G1934』/to seek after/g
s/『G1935』/condemned to death/g
s/『G1936』/laying on/g
s/『G1937』/to long for/g
s/『G1938』/one who desires/g
s/『G1939』/desire/g
s/『G1940』/to sit on/g
s/『G1941』/to call \(on\)\/name/g
s/『G1942』/covering/g
s/『G1943』/to cover/g
s/『G1944』/cursed/g
s/『G1945』/to lay on/g
s/『G1946』/Epicurean/g
s/『G1947』/help/g
s/『G1948』/to decide/g
s/『G1949』/to catch/g
s/『G1950』/to forget/g
s/『G1951』/to call\/choose/g
s/『G1952』/be insufficient/g
s/『G1953』/forgetfulness/g
s/『G1954』/remaining/g
s/『G1955』/explanation/g
s/『G1956』/to explain/g
s/『G1957』/to testify to/g
s/『G1958』/care/g
s/『G1959』/to care/g
s/『G1960』/carefully/g
s/『G1961』/to remain\/keep on/g
s/『G1962』/to accept/g
s/『G1963』/thought/g
s/『G1964』/to break an oath/g
s/『G1965』/perjurer/g
s/『G1966』/come upon\/after/g
s/『G1967』/daily/g
s/『G1968』/to fall\/press upon/g
s/『G1969』/to rebuke/g
s/『G1970』/to choke/g
s/『G1971』/to long for/g
s/『G1972』/longing/g
s/『G1973』/longed for/g
s/『G1974』/longing/g
s/『G1975』/to come\/go to/g
s/『G1976』/to sew on/g
s/『G1977』/to throw on/g
s/『G1978』/notable/g
s/『G1979』/food/g
s/『G1980』/to visit\/care for/g
s/『G1981』/to rest upon\/dwell/g
s/『G1982』/to overshadow/g
s/『G1983』/to oversee\/care for/g
s/『G1984』/oversight/g
s/『G1985』/overseer/g
s/『G1986』/to uncircumcise/g
s/『G1987』/to know\/understand/g
s/『G1988』/master/g
s/『G1989』/to write to/g
s/『G1990』/knowing/g
s/『G1991』/to strengthen/g
s/『G1992』/epistle/g
s/『G1993』/to silence/g
s/『G1994』/to turn/g
s/『G1995』/conversion/g
s/『G1996』/to gather/g
s/『G1997』/gathering/g
s/『G1998』/to run together/g
s/『G1999』/insurrection/g
s/『G2000』/dangerous\/unsteady/g
s/『G2001』/to insist/g
s/『G2002』/to accumulate/g
s/『G2003』/command/g
s/『G2004』/to command/g
s/『G2005』/to complete/g
s/『G2006』/necessary/g
s/『G2007』/to put\/lay on/g
s/『G2008』/to rebuke/g
s/『G2009』/punishment/g
s/『G2010』/to permit/g
s/『G2011』/commission/g
s/『G2012』/manager/g
s/『G2013』/to obtain/g
s/『G2014』/to appear/g
s/『G2015』/appearing/g
s/『G2016』/glorious/g
s/『G2017』/to shine on/g
s/『G2018』/to inflict/g
s/『G2019』/to shout/g
s/『G2020』/to dawn/g
s/『G2021』/to attempt/g
s/『G2022』/to pour on\/over/g
s/『G2023』/to supply/g
s/『G2024』/supply/g
s/『G2025』/to rub on/g
s/『G2026』/to build up\/upon/g
s/『G2027』/to run aground/g
s/『G2028』/to name/g
s/『G2029』/to observe/g
s/『G2030』/eyewitness/g
s/『G2031』/a word/g
s/『G2032』/heavenly/g
s/『G2033』/seven/g
s/『G2034』/seven times/g
s/『G2035』/seven thousand/g
s/『G2036』/to say/g
s/『G2037』/Erastus/g
s/『G2038』/to work/g
s/『G2039』/work/g
s/『G2040』/worker/g
s/『G2041』/work/g
s/『G2042』/to provoke\/irritate/g
s/『G2043』/to immobilise/g
s/『G2044』/to utter\/proclaim/g
s/『G2045』/to look for\/into/g
s/『G2046』/to speak/g
s/『G2047』/desert/g
s/『G2048』/deserted/g
s/『G2049』/to lay waste/g
s/『G2050』/devastation/g
s/『G2051』/to quarrel/g
s/『G2052』/rivalry/g
s/『G2053』/wool/g
s/『G2054』/quarrel/g
s/『G2055』/a goat/g
s/『G2056』/a goat/g
s/『G2057』/Hermas/g
s/『G2058』/interpretation/g
s/『G2059』/to interpret/g
s/『G2060』/Hermes/g
s/『G2061』/Hermogenes/g
s/『G2062』/reptile/g
s/『G2063』/red/g
s/『G2064』/to come\/go/g
s/『G2065』/to ask/g
s/『G2066』/clothing/g
s/『G2067』/clothing/g
s/『G2068』/to eat/g
s/『G2069』/Esli/g
s/『G2070』/we are/g
s/『G2071』/will be/g
s/『G2072』/mirror/g
s/『G2073』/evening/g
s/『G2074』/Hezron/g
s/『G2075』/you are/g
s/『G2076』/he is/g
s/『G2077』/you should/g
s/『G2078』/last\/least/g
s/『G2079』/extremely/g
s/『G2080』/in\/inner\/inwardly/g
s/『G2081』/inwardly/g
s/『G2082』/inner/g
s/『G2083』/friend/g
s/『G2084』/in another language/g
s/『G2085』/to teach heresy/g
s/『G2086』/to yoke a mismatch/g
s/『G2087』/other/g
s/『G2088』/differently/g
s/『G2089』/still/g
s/『G2090』/to make ready/g
s/『G2091』/readiness/g
s/『G2092』/ready/g
s/『G2093』/readily/g
s/『G2094』/year/g
s/『G2095』/well\/well done!/g
s/『G2096』/Eve/g
s/『G2097』/to speak good news/g
s/『G2098』/gospel/g
s/『G2099』/evangelist/g
s/『G2100』/to please/g
s/『G2101』/well-pleasing/g
s/『G2102』/acceptably/g
s/『G2103』/Eubulus/g
s/『G2104』/of noble birth/g
s/『G2105』/fair weather/g
s/『G2106』/to delight/g
s/『G2107』/goodwill/g
s/『G2108』/good deed/g
s/『G2109』/to do good/g
s/『G2110』/benefactor/g
s/『G2111』/suitable/g
s/『G2112』/immediately/g
s/『G2113』/to sail straight/g
s/『G2114』/be cheerful/g
s/『G2115』/cheerful/g
s/『G2116』/to straighten/g
s/『G2117』/straight\/upright/g
s/『G2118』/righteousness/g
s/『G2119』/to have opportunity/g
s/『G2120』/opportunity/g
s/『G2121』/opportune/g
s/『G2122』/well timed/g
s/『G2123』/easy/g
s/『G2124』/reverence/g
s/『G2125』/to revere/g
s/『G2126』/devout/g
s/『G2127』/to praise\/bless/g
s/『G2128』/praiseworthy/g
s/『G2129』/praise/g
s/『G2130』/generous/g
s/『G2131』/Eunice/g
s/『G2132』/to reconcile/g
s/『G2133』/enthusiasm/g
s/『G2134』/to become a eunuch/g
s/『G2135』/eunuch/g
s/『G2136』/Euodia/g
s/『G2137』/to get along well/g
s/『G2138』/compliant/g
s/『G2139』/thwarting/g
s/『G2140』/doing good/g
s/『G2141』/be prosperous/g
s/『G2142』/prosperity/g
s/『G2143』/beauty/g
s/『G2144』/acceptable/g
s/『G2145』/devoted/g
s/『G2146』/to impress/g
s/『G2147』/to find\/meet/g
s/『G2148』/a north wind/g
s/『G2149』/broad/g
s/『G2150』/piety/g
s/『G2151』/to show piety/g
s/『G2152』/pious/g
s/『G2153』/piously/g
s/『G2154』/intelligible/g
s/『G2155』/compassionate/g
s/『G2156』/properly/g
s/『G2157』/propriety/g
s/『G2158』/proper/g
s/『G2159』/vehemently/g
s/『G2160』/vulgar jesting/g
s/『G2161』/Eutychus/g
s/『G2162』/good report/g
s/『G2163』/commendable/g
s/『G2164』/be fruitful/g
s/『G2165』/to celebrate/g
s/『G2166』/Euphrates/g
s/『G2167』/joy/g
s/『G2168』/to thank/g
s/『G2169』/thankfulness/g
s/『G2170』/thankful/g
s/『G2171』/a vow\/prayer/g
s/『G2172』/to pray\/wish for/g
s/『G2173』/helpful/g
s/『G2174』/be glad/g
s/『G2175』/aroma/g
s/『G2176』/left\/south/g
s/『G2177』/to jump on/g
s/『G2178』/once\/at once/g
s/『G2179』/Ephesian/g
s/『G2180』/Ephesian/g
s/『G2181』/Ephesus/g
s/『G2182』/inventor/g
s/『G2183』/division/g
s/『G2184』/daily/g
s/『G2185』/to reach/g
s/『G2186』/to approach/g
s/『G2187』/Ephraim/g
s/『G2188』/open!/g
s/『G2189』/hostility/g
s/『G2190』/enemy/g
s/『G2191』/snake/g
s/『G2192』/to have\/be/g
s/『G2193』/until/g
s/『G2194』/Zebulun/g
s/『G2195』/Zacchaeus/g
s/『G2196』/Zerah/g
s/『G2197』/Zechariah/g
s/『G2198』/to live/g
s/『G2199』/Zebedee/g
s/『G2200』/hot/g
s/『G2201』/a yoke\/pair/g
s/『G2202』/rope/g
s/『G2203』/Zeus/g
s/『G2204』/be fervent/g
s/『G2205』/zeal/g
s/『G2206』/be eager/g
s/『G2207』/zealot/g
s/『G2208』/Zealot/g
s/『G2209』/damage\/loss/g
s/『G2210』/to lose/g
s/『G2211』/Zenas/g
s/『G2212』/to seek/g
s/『G2213』/a question\/dispute/g
s/『G2214』/controversy/g
s/『G2215』/weed/g
s/『G2216』/Zerubbabel/g
s/『G2217』/darkness/g
s/『G2218』/yoke\/scales/g
s/『G2219』/leaven/g
s/『G2220』/to leaven/g
s/『G2221』/to capture alive/g
s/『G2222』/life/g
s/『G2223』/belt\/sash\/girdle/g
s/『G2224』/to dress/g
s/『G2225』/to give life/g
s/『G2226』/living thing/g
s/『G2227』/to make alive/g
s/『G2228』/or/g
s/『G2229』/surely/g
s/『G2230』/to govern/g
s/『G2231』/reign/g
s/『G2232』/ruler/g
s/『G2233』/to govern/g
s/『G2234』/gladly/g
s/『G2235』/already/g
s/『G2236』/most gladly/g
s/『G2237』/pleasure/g
s/『G2238』/mint/g
s/『G2239』/customs/g
s/『G2240』/to come\/be present/g
s/『G2241』/Eli/g
s/『G2242』/Heli/g
s/『G2243』/Elijah/g
s/『G2244』/age\/height/g
s/『G2245』/how great/g
s/『G2246』/sun/g
s/『G2247』/nail/g
s/『G2248』/us/g
s/『G2249』/we/g
s/『G2250』/day/g
s/『G2251』/our/g
s/『G2252』/I was/g
s/『G2253』/half-dead/g
s/『G2254』/to us/g
s/『G2255』/half/g
s/『G2256』/half an hour/g
s/『G2257』/of us/g
s/『G2258』/was/g
s/『G2259』/when/g
s/『G2260』/than/g
s/『G2261』/gentle/g
s/『G2262』/Er/g
s/『G2263』/quiet/g
s/『G2264』/Herod/g
s/『G2265』/Herodians/g
s/『G2266』/Herodias/g
s/『G2267』/Herodion/g
s/『G2268』/Isaiah/g
s/『G2269』/Esau/g
s/『G2270』/be quiet\/give up/g
s/『G2271』/quietness/g
s/『G2272』/quiet/g
s/『G2273』/whether/g
s/『G2274』/be lesser/g
s/『G2275』/loss/g
s/『G2276』/less\/worse/g
s/『G2277』/let him\/it be/g
s/『G2278』/to resound/g
s/『G2279』/sound/g
s/『G2280』/Thaddaeus/g
s/『G2281』/sea/g
s/『G2282』/to care for/g
s/『G2283』/Tamar/g
s/『G2284』/to astonish/g
s/『G2285』/amazement/g
s/『G2286』/deadly/g
s/『G2287』/deadly/g
s/『G2288』/death/g
s/『G2289』/to kill/g
s/『G2290』/to bury/g
s/『G2291』/Terah/g
s/『G2292』/be confident/g
s/『G2293』/take heart/g
s/『G2294』/courage\/confidence/g
s/『G2295』/marvel/g
s/『G2296』/to marvel/g
s/『G2297』/marvelous/g
s/『G2298』/marvellous/g
s/『G2299』/goddess/g
s/『G2300』/to see/g
s/『G2301』/to expose/g
s/『G2302』/theatre/g
s/『G2303』/sulfur/g
s/『G2304』/divine/g
s/『G2305』/divinity/g
s/『G2306』/sulphurous/g
s/『G2307』/will\/desire/g
s/『G2308』/will/g
s/『G2309』/to will\/desire/g
s/『G2310』/foundation/g
s/『G2311』/to found/g
s/『G2312』/divinely instructed/g
s/『G2313』/to fight God/g
s/『G2314』/opposing God/g
s/『G2315』/God-breathed/g
s/『G2316』/God/g
s/『G2317』/reverence for God/g
s/『G2318』/godly/g
s/『G2319』/God-hating/g
s/『G2320』/deity/g
s/『G2321』/Theophilus/g
s/『G2322』/service/g
s/『G2323』/to serve\/heal/g
s/『G2324』/servant/g
s/『G2325』/to reap/g
s/『G2326』/harvest/g
s/『G2327』/reaper/g
s/『G2328』/to warm/g
s/『G2329』/heat/g
s/『G2330』/summer/g
s/『G2331』/Thessalonian/g
s/『G2332』/Thessalonica/g
s/『G2333』/Theudas/g
s/『G2334』/to see\/experience/g
s/『G2335』/sight/g
s/『G2336』/sheath/g
s/『G2337』/to suckle/g
s/『G2338』/female/g
s/『G2339』/trap/g
s/『G2340』/to hunt\/catch/g
s/『G2341』/to fight beasts/g
s/『G2342』/wild animal/g
s/『G2343』/to store up/g
s/『G2344』/treasure/g
s/『G2345』/to touch/g
s/『G2346』/to press on/g
s/『G2347』/pressure/g
s/『G2348』/to die\/be dead/g
s/『G2349』/mortal/g
s/『G2350』/to make commotion/g
s/『G2351』/commotion/g
s/『G2352』/to crush/g
s/『G2353』/livestock/g
s/『G2354』/to lament/g
s/『G2355』/lamentation/g
s/『G2356』/religion/g
s/『G2357』/religious/g
s/『G2358』/to triumph/g
s/『G2359』/hair/g
s/『G2360』/to alarm/g
s/『G2361』/drop/g
s/『G2362』/throne/g
s/『G2363』/Thyatira/g
s/『G2364』/daughter/g
s/『G2365』/little daughter/g
s/『G2366』/storm/g
s/『G2367』/citron/g
s/『G2368』/incense/g
s/『G2369』/incense altar/g
s/『G2370』/to burn incense/g
s/『G2371』/to quarrel/g
s/『G2372』/wrath/g
s/『G2373』/to anger/g
s/『G2374』/door/g
s/『G2375』/long shield/g
s/『G2376』/window/g
s/『G2377』/gatekeeper/g
s/『G2378』/sacrifice/g
s/『G2379』/altar/g
s/『G2380』/to sacrifice/g
s/『G2381』/Thomas/g
s/『G2382』/breastplate/g
s/『G2383』/Jairus/g
s/『G2384』/Jacob/g
s/『G2385』/James/g
s/『G2386』/healing/g
s/『G2387』/Jambres/g
s/『G2388』/Janna/g
s/『G2389』/Jannes/g
s/『G2390』/to heal/g
s/『G2391』/Jared/g
s/『G2392』/healing/g
s/『G2393』/jasper/g
s/『G2394』/Jason/g
s/『G2395』/physician/g
s/『G2396』/look!/g
s/『G2397』/appearance/g
s/『G2398』/one's own\/private/g
s/『G2399』/unlearned/g
s/『G2400』/look!/g
s/『G2401』/Idumea/g
s/『G2402』/sweat/g
s/『G2403』/Jezebel/g
s/『G2404』/Hierapolis/g
s/『G2405』/priesthood/g
s/『G2406』/priesthood/g
s/『G2407』/to serve as priest/g
s/『G2408』/Jeremiah/g
s/『G2409』/priest/g
s/『G2410』/Jericho/g
s/『G2411』/temple/g
s/『G2412』/reverent/g
s/『G2413』/sacred/g
s/『G2414』/Jerusalem/g
s/『G2415』/of Jerusalem/g
s/『G2416』/to despoil a temple/g
s/『G2417』/temple robber/g
s/『G2418』/to minister/g
s/『G2419』/Jerusalem/g
s/『G2420』/priesthood/g
s/『G2421』/Jesse/g
s/『G2422』/Jephthah/g
s/『G2423』/Jeconiah/g
s/『G2424』/Jesus\/Joshua/g
s/『G2425』/sufficient/g
s/『G2426』/sufficiency/g
s/『G2427』/to qualify/g
s/『G2428』/supplication/g
s/『G2429』/moisture/g
s/『G2430』/Iconium/g
s/『G2431』/cheerful/g
s/『G2432』/cheerfulness/g
s/『G2433』/to propitiate/g
s/『G2434』/propitiation/g
s/『G2435』/propitiation/g
s/『G2436』/propitious\/gracious/g
s/『G2437』/Illyricum/g
s/『G2438』/leather strap/g
s/『G2439』/to dress/g
s/『G2440』/clothing/g
s/『G2441』/clothing/g
s/『G2442』/to desire/g
s/『G2443』/in order that\/to/g
s/『G2444』/why?/g
s/『G2445』/Joppa/g
s/『G2446』/Jordan/g
s/『G2447』/poison\/rust/g
s/『G2448』/Judea/g
s/『G2449』/Judea/g
s/『G2450』/be Jewish/g
s/『G2451』/Jewish/g
s/『G2452』/Jewishly/g
s/『G2453』/Jewish/g
s/『G2454』/Judaism/g
s/『G2455』/Judah\/Judas\/Jude/g
s/『G2456』/Julia/g
s/『G2457』/Julius/g
s/『G2458』/Junias/g
s/『G2459』/Justus/g
s/『G2460』/horseman/g
s/『G2461』/horseman/g
s/『G2462』/horse/g
s/『G2463』/rainbow/g
s/『G2464』/Isaac/g
s/『G2465』/like an angel/g
s/『G2466』/Issachar/g
s/『G2467』/to know/g
s/『G2468』/you should be/g
s/『G2469』/Iscariot/g
s/『G2470』/equal/g
s/『G2471』/equality/g
s/『G2472』/equally valuable/g
s/『G2473』/like-minded/g
s/『G2474』/Israel/g
s/『G2475』/Israelite/g
s/『G2476』/to stand/g
s/『G2477』/to get acquainted/g
s/『G2478』/strong/g
s/『G2479』/strength/g
s/『G2480』/be strong/g
s/『G2481』/perhaps/g
s/『G2482』/Italy/g
s/『G2483』/Italian/g
s/『G2484』/Iturea/g
s/『G2485』/little fish/g
s/『G2486』/fish/g
s/『G2487』/track/g
s/『G2488』/Jotham/g
s/『G2489』/Joanna/g
s/『G2490』/Joannan/g
s/『G2491』/John/g
s/『G2492』/Job/g
s/『G2493』/Joel/g
s/『G2494』/Jonam/g
s/『G2495』/Jonah/g
s/『G2496』/Jehoram/g
s/『G2497』/Jorim/g
s/『G2498』/Jehoshaphat/g
s/『G2499』/Jose/g
s/『G2500』/Joses/g
s/『G2501』/Joseph/g
s/『G2502』/Josiah/g
s/『G2503』/iota/g
s/『G2504』/and I/g
s/『G2505』/as\/just as/g
s/『G2506』/destruction/g
s/『G2507』/to take down/g
s/『G2508』/to prune/g
s/『G2509』/just as/g
s/『G2510』/to attach/g
s/『G2511』/to clean/g
s/『G2512』/cleansing/g
s/『G2513』/clean/g
s/『G2514』/cleanness/g
s/『G2515』/seat/g
s/『G2516』/to sit down/g
s/『G2517』/in order/g
s/『G2518』/to sleep/g
s/『G2519』/teacher/g
s/『G2520』/be fit/g
s/『G2521』/to sit/g
s/『G2522』/daily/g
s/『G2523』/to sit/g
s/『G2524』/to lower/g
s/『G2525』/to appoint\/conduct/g
s/『G2526』/insofar as/g
s/『G2527』/at all/g
s/『G2528』/to arm fully/g
s/『G2529』/to perceive/g
s/『G2530』/as\/just as/g
s/『G2531』/as\/just as/g
s/『G2532』/and/g
s/『G2533』/Caiaphas/g
s/『G2534』/even\/even though/g
s/『G2535』/Cain/g
s/『G2536』/Cainan/g
s/『G2537』/new/g
s/『G2538』/newness/g
s/『G2539』/although/g
s/『G2540』/time\/right time/g
s/『G2541』/Caesar/g
s/『G2542』/Caesarea/g
s/『G2543』/and yet\/although/g
s/『G2544』/and yet\/although/g
s/『G2545』/to kindle\/burn/g
s/『G2546』/and there/g
s/『G2547』/and from there/g
s/『G2548』/and that one/g
s/『G2549』/evil/g
s/『G2550』/malice/g
s/『G2551』/to curse\/revile/g
s/『G2552』/suffering/g
s/『G2553』/to endure/g
s/『G2554』/to do evil\/harm/g
s/『G2555』/wrongdoing/g
s/『G2556』/evil\/harm/g
s/『G2557』/criminal/g
s/『G2558』/to torment/g
s/『G2559』/to harm/g
s/『G2560』/badly/g
s/『G2561』/oppression/g
s/『G2562』/straw\/stubble/g
s/『G2563』/reed\/stick\/pen/g
s/『G2564』/to call/g
s/『G2565』/olive tree/g
s/『G2566』/good/g
s/『G2567』/teaching good/g
s/『G2568』/Fair Havens/g
s/『G2569』/to do good/g
s/『G2570』/good/g
s/『G2571』/veil/g
s/『G2572』/to cover/g
s/『G2573』/well/g
s/『G2574』/camel/g
s/『G2575』/furnace\/oven/g
s/『G2576』/to close/g
s/『G2577』/be weary\/sick/g
s/『G2578』/to bend\/bow/g
s/『G2579』/and\/even if/g
s/『G2580』/Cana/g
s/『G2581』/Zealot/g
s/『G2582』/Candace/g
s/『G2583』/rule/g
s/『G2584』/Capernaum/g
s/『G2585』/to peddle/g
s/『G2586』/smoke/g
s/『G2587』/Cappadocia/g
s/『G2588』/heart/g
s/『G2589』/heart-knower/g
s/『G2590』/fruit/g
s/『G2591』/Carpus/g
s/『G2592』/to bear fruit/g
s/『G2593』/fruitbearing/g
s/『G2594』/to endure/g
s/『G2595』/speck/g
s/『G2596』/according to/g
s/『G2597』/to come\/go down/g
s/『G2598』/to lay\/throw down/g
s/『G2599』/to burden/g
s/『G2600』/descent/g
s/『G2601』/to bring down/g
s/『G2602』/beginning/g
s/『G2603』/to disqualify/g
s/『G2604』/proclaimer/g
s/『G2605』/to proclaim/g
s/『G2606』/to mock/g
s/『G2607』/to condemn/g
s/『G2608』/to break/g
s/『G2609』/to bring down/g
s/『G2610』/to conquer/g
s/『G2611』/to bandage/g
s/『G2612』/evident/g
s/『G2613』/to condemn/g
s/『G2614』/to seek/g
s/『G2615』/to enslave/g
s/『G2616』/to oppress/g
s/『G2617』/to dishonor/g
s/『G2618』/to burn/g
s/『G2619』/to cover/g
s/『G2620』/to boast/g
s/『G2621』/to recline/g
s/『G2622』/to break/g
s/『G2623』/to lock up/g
s/『G2624』/to distribute/g
s/『G2625』/to sit/g
s/『G2626』/to flood/g
s/『G2627』/flood/g
s/『G2628』/to follow/g
s/『G2629』/to cut/g
s/『G2630』/to cast down/g
s/『G2631』/condemnation/g
s/『G2632』/to condemn/g
s/『G2633』/condemnation/g
s/『G2634』/to master/g
s/『G2635』/to slander/g
s/『G2636』/slander/g
s/『G2637』/slanderous/g
s/『G2638』/to take\/realize/g
s/『G2639』/to enrol/g
s/『G2640』/remnant/g
s/『G2641』/to leave/g
s/『G2642』/to stone/g
s/『G2643』/reconciliation/g
s/『G2644』/to reconcile/g
s/『G2645』/remaining/g
s/『G2646』/guest room\/inn/g
s/『G2647』/to destroy\/lodge/g
s/『G2648』/to consider/g
s/『G2649』/to testify against/g
s/『G2650』/to stay/g
s/『G2651』/alone/g
s/『G2652』/curse/g
s/『G2653』/to curse/g
s/『G2654』/to consume/g
s/『G2655』/to burden/g
s/『G2656』/to signal/g
s/『G2657』/to observe/g
s/『G2658』/to come to/g
s/『G2659』/stupor/g
s/『G2660』/to pierce/g
s/『G2661』/to consider worthy/g
s/『G2662』/to trample/g
s/『G2663』/rest/g
s/『G2664』/to keep from/g
s/『G2665』/curtain/g
s/『G2666』/to swallow/g
s/『G2667』/to fall down/g
s/『G2668』/to sail/g
s/『G2669』/to oppress/g
s/『G2670』/to sink/g
s/『G2671』/curse/g
s/『G2672』/to curse/g
s/『G2673』/to end/g
s/『G2674』/to number/g
s/『G2675』/to complete/g
s/『G2676』/perfection/g
s/『G2677』/preparation/g
s/『G2678』/to signal/g
s/『G2679』/to ruin/g
s/『G2680』/to prepare/g
s/『G2681』/to dwell/g
s/『G2682』/dwelling place/g
s/『G2683』/to overshadow/g
s/『G2684』/to spy/g
s/『G2685』/spy/g
s/『G2686』/be treacherous/g
s/『G2687』/to quiet/g
s/『G2688』/behavior/g
s/『G2689』/attire\/behaviour/g
s/『G2690』/to overturn/g
s/『G2691』/to desire/g
s/『G2692』/ruin/g
s/『G2693』/be thrown down/g
s/『G2694』/to drag away/g
s/『G2695』/to slaughter/g
s/『G2696』/to seal/g
s/『G2697』/possession/g
s/『G2698』/to do a favor/g
s/『G2699』/mutilation/g
s/『G2700』/to shoot down/g
s/『G2701』/to rush down/g
s/『G2702』/to vote against/g
s/『G2703』/to flee/g
s/『G2704』/to corrupt/g
s/『G2705』/to kiss/g
s/『G2706』/to despise/g
s/『G2707』/despiser/g
s/『G2708』/to pour/g
s/『G2709』/subterranean/g
s/『G2710』/to use up/g
s/『G2711』/to cool/g
s/『G2712』/idolatrous/g
s/『G2713』/before/g
s/『G2714』/before/g
s/『G2715』/to rule/g
s/『G2716』/to workout\/produce/g
s/『G2718』/to descend/g
s/『G2719』/to devour/g
s/『G2720』/to guide/g
s/『G2721』/to attack/g
s/『G2722』/to hold back\/fast/g
s/『G2723』/to accuse/g
s/『G2724』/accusation/g
s/『G2725』/accuser/g
s/『G2726』/gloominess/g
s/『G2727』/to instruct/g
s/『G2728』/to corrode/g
s/『G2729』/to prevail/g
s/『G2730』/to dwell/g
s/『G2731』/dwelling/g
s/『G2732』/dwelling place/g
s/『G2733』/dwelling/g
s/『G2734』/to reflect/g
s/『G2735』/reformation/g
s/『G2736』/under/g
s/『G2737』/lower/g
s/『G2738』/heat/g
s/『G2739』/to scorch/g
s/『G2740』/burning/g
s/『G2741』/to burn/g
s/『G2742』/heat/g
s/『G2743』/to brand/g
s/『G2744』/to boast/g
s/『G2745』/pride/g
s/『G2746』/pride/g
s/『G2747』/Cenchrea/g
s/『G2748』/Kidron/g
s/『G2749』/to lay\/be appointed/g
s/『G2750』/graveclothes/g
s/『G2751』/to shear/g
s/『G2752』/command/g
s/『G2753』/to order/g
s/『G2754』/empty conceit/g
s/『G2755』/conceited/g
s/『G2756』/empty/g
s/『G2757』/empty talk/g
s/『G2758』/to empty/g
s/『G2759』/sting/g
s/『G2760』/centurion/g
s/『G2761』/vainly/g
s/『G2762』/tittle/g
s/『G2763』/potter/g
s/『G2764』/made of clay/g
s/『G2765』/clay jar/g
s/『G2766』/clay roof tile/g
s/『G2767』/to mix/g
s/『G2768』/horn/g
s/『G2769』/husk/g
s/『G2770』/to gain/g
s/『G2771』/gain/g
s/『G2772』/coin/g
s/『G2773』/moneychanger/g
s/『G2774』/sum/g
s/『G2775』/to strike a head/g
s/『G2776』/head/g
s/『G2777』/scroll/g
s/『G2778』/tax/g
s/『G2779』/garden/g
s/『G2780』/gardener/g
s/『G2781』/honeycomb/g
s/『G2782』/preaching/g
s/『G2783』/preacher/g
s/『G2784』/to preach/g
s/『G2785』/sea monster/g
s/『G2786』/Cephas/g
s/『G2787』/ark/g
s/『G2788』/harp/g
s/『G2789』/to play the harp/g
s/『G2790』/harpist/g
s/『G2791』/Cilicia/g
s/『G2792』/cinnamon/g
s/『G2793』/be in danger/g
s/『G2794』/danger/g
s/『G2795』/to move/g
s/『G2796』/motion/g
s/『G2797』/Kish/g
s/『G2798』/branch/g
s/『G2799』/to weep/g
s/『G2800』/breaking/g
s/『G2801』/fragment/g
s/『G2802』/Cauda/g
s/『G2803』/Claudia/g
s/『G2804』/Claudius/g
s/『G2805』/weeping/g
s/『G2806』/to break/g
s/『G2807』/key/g
s/『G2808』/to shut/g
s/『G2809』/theft/g
s/『G2810』/Cleopas/g
s/『G2811』/credit/g
s/『G2812』/thief/g
s/『G2813』/to steal/g
s/『G2814』/branch/g
s/『G2815』/Clement/g
s/『G2816』/to inherit/g
s/『G2817』/inheritance/g
s/『G2818』/heir/g
s/『G2819』/lot/g
s/『G2820』/to obtain/g
s/『G2821』/calling/g
s/『G2822』/called/g
s/『G2823』/oven/g
s/『G2824』/region/g
s/『G2825』/bed/g
s/『G2826』/bed/g
s/『G2827』/to bow\/lay down/g
s/『G2828』/group/g
s/『G2829』/theft/g
s/『G2830』/waves/g
s/『G2831』/to toss/g
s/『G2832』/Clopas/g
s/『G2833』/to itch/g
s/『G2834』/Cnidus/g
s/『G2835』/penny/g
s/『G2836』/belly\/womb\/stomach/g
s/『G2837』/to sleep/g
s/『G2838』/sleep/g
s/『G2839』/common/g
s/『G2840』/to profane/g
s/『G2841』/to participate/g
s/『G2842』/participation/g
s/『G2843』/generous/g
s/『G2844』/participant/g
s/『G2845』/bed/g
s/『G2846』/bedroom\/chamberlain/g
s/『G2847』/scarlet/g
s/『G2848』/seed/g
s/『G2849』/to punish/g
s/『G2850』/flattery/g
s/『G2851』/punishment/g
s/『G2852』/to beat/g
s/『G2853』/to join/g
s/『G2854』/eye salve/g
s/『G2855』/moneychanger/g
s/『G2856』/to shorten/g
s/『G2857』/Colosse/g
s/『G2858』/Colossian/g
s/『G2859』/bosom/g
s/『G2860』/to swim/g
s/『G2861』/pool/g
s/『G2862』/colony/g
s/『G2863』/be long-haired/g
s/『G2864』/hair/g
s/『G2865』/to bring\/be repaid/g
s/『G2866』/better/g
s/『G2867』/to whitewash/g
s/『G2868』/dust/g
s/『G2869』/to abate/g
s/『G2870』/lamentation/g
s/『G2871』/slaughter/g
s/『G2872』/to labor/g
s/『G2873』/labor/g
s/『G2874』/manure/g
s/『G2875』/to cut\/mourn/g
s/『G2876』/raven/g
s/『G2877』/girl/g
s/『G2878』/Corban/g
s/『G2879』/Korah/g
s/『G2880』/to satisfy/g
s/『G2881』/Corinthian/g
s/『G2882』/Corinth/g
s/『G2883』/Cornelius/g
s/『G2884』/cor/g
s/『G2885』/to arrange/g
s/『G2886』/earthly/g
s/『G2887』/respectable/g
s/『G2888』/world power/g
s/『G2889』/world/g
s/『G2890』/Quartus/g
s/『G2891』/stand up!/g
s/『G2892』/guard/g
s/『G2893』/to lighten/g
s/『G2894』/basket/g
s/『G2895』/bed/g
s/『G2896』/to cry/g
s/『G2897』/dissipation/g
s/『G2898』/skull/g
s/『G2899』/edge/g
s/『G2900』/mighty/g
s/『G2901』/to strengthen/g
s/『G2902』/to grasp\/seize/g
s/『G2903』/excellent/g
s/『G2904』/power/g
s/『G2905』/to shout/g
s/『G2906』/shouting/g
s/『G2907』/meat/g
s/『G2908』/greater/g
s/『G2909』/stronger/g
s/『G2910』/to hang/g
s/『G2911』/cliff/g
s/『G2912』/Cretan/g
s/『G2913』/Crescens/g
s/『G2914』/Crete/g
s/『G2915』/barley/g
s/『G2916』/barley/g
s/『G2917』/judgment/g
s/『G2918』/lily/g
s/『G2919』/to judge/g
s/『G2920』/judgment/g
s/『G2921』/Crispus/g
s/『G2922』/court\/lawsuit/g
s/『G2923』/judge/g
s/『G2924』/discerning/g
s/『G2925』/to knock/g
s/『G2926』/cellar/g
s/『G2927』/hidden/g
s/『G2928』/to hide/g
s/『G2929』/be clear/g
s/『G2930』/crystal/g
s/『G2931』/in secret/g
s/『G2932』/to posses/g
s/『G2933』/possession/g
s/『G2934』/animal/g
s/『G2935』/owner/g
s/『G2936』/to create/g
s/『G2937』/creation/g
s/『G2938』/creature/g
s/『G2939』/creator/g
s/『G2940』/cunning/g
s/『G2941』/administration/g
s/『G2942』/captain/g
s/『G2943』/around/g
s/『G2944』/to surround/g
s/『G2945』/surrounding/g
s/『G2946』/wallowing/g
s/『G2947』/to wallow/g
s/『G2948』/crippled/g
s/『G2949』/a wave/g
s/『G2950』/cymbal/g
s/『G2951』/cumin/g
s/『G2952』/little dog/g
s/『G2953』/Cyprian/g
s/『G2954』/Cyprus/g
s/『G2955』/to stoop\/bend down/g
s/『G2956』/from Cyrene/g
s/『G2957』/Cyrene/g
s/『G2958』/Quirinius/g
s/『G2959』/lady/g
s/『G2960』/the Lord’s/g
s/『G2961』/to lord over/g
s/『G2962』/lord/g
s/『G2963』/lordship/g
s/『G2964』/to affirm/g
s/『G2965』/dog/g
s/『G2966』/corpse/g
s/『G2967』/to prevent/g
s/『G2968』/village/g
s/『G2969』/village/g
s/『G2970』/orgy/g
s/『G2971』/gnat/g
s/『G2972』/Cos/g
s/『G2973』/Cosam/g
s/『G2974』/deaf\/mute/g
s/『G2975』/to choose by lot/g
s/『G2976』/Lazarus/g
s/『G2977』/quietly/g
s/『G2978』/storm/g
s/『G2979』/to kick/g
s/『G2980』/to speak/g
s/『G2981』/speech/g
s/『G2982』/why?/g
s/『G2983』/to take/g
s/『G2984』/Lamech/g
s/『G2985』/window/g
s/『G2986』/shining/g
s/『G2987』/brightness/g
s/『G2988』/magnificently/g
s/『G2989』/to shine/g
s/『G2990』/be hidden/g
s/『G2991』/engraved/g
s/『G2992』/a people/g
s/『G2993』/Laodicea/g
s/『G2994』/Laodicean/g
s/『G2995』/throat/g
s/『G2996』/Lasea/g
s/『G2997』/to burst/g
s/『G2998』/to hew/g
s/『G2999』/ministry/g
s/『G3000』/to minister/g
s/『G3001』/plant/g
s/『G3002』/Lebbaeus/g
s/『G3003』/legion/g
s/『G3004』/to speak/g
s/『G3005』/remnant/g
s/『G3006』/smooth/g
s/『G3007』/to lack/g
s/『G3008』/to minister/g
s/『G3009』/ministry/g
s/『G3010』/ministering/g
s/『G3011』/minister/g
s/『G3012』/towel/g
s/『G3013』/scale/g
s/『G3014』/leprosy/g
s/『G3015』/leprous/g
s/『G3016』/coin/g
s/『G3017』/Levi/g
s/『G3018』/Levi/g
s/『G3019』/Levite/g
s/『G3020』/Levitical/g
s/『G3021』/to bleach/g
s/『G3022』/white/g
s/『G3023』/lion/g
s/『G3024』/forgetfulness/g
s/『G3025』/winepress/g
s/『G3026』/nonsense/g
s/『G3027』/robber\/rebel/g
s/『G3028』/receiving/g
s/『G3029』/greatly/g
s/『G3030』/frankincense/g
s/『G3031』/censer/g
s/『G3032』/Freedman/g
s/『G3033』/Libya/g
s/『G3034』/to stone/g
s/『G3035』/stone/g
s/『G3036』/to stone/g
s/『G3037』/stone/g
s/『G3038』/pavement/g
s/『G3039』/to crush/g
s/『G3040』/harbor/g
s/『G3041』/lake/g
s/『G3042』/hunger/g
s/『G3043』/linen\/wick/g
s/『G3044』/Linus/g
s/『G3045』/rich/g
s/『G3046』/pound/g
s/『G3047』/southwest/g
s/『G3048』/collection/g
s/『G3049』/to count/g
s/『G3050』/spiritual/g
s/『G3051』/oracles/g
s/『G3052』/learned/g
s/『G3053』/thought/g
s/『G3054』/to quarrel/g
s/『G3055』/quarrel/g
s/『G3056』/word/g
s/『G3057』/spear/g
s/『G3058』/to revile/g
s/『G3059』/reviling/g
s/『G3060』/reviler/g
s/『G3061』/pestilence/g
s/『G3062』/remaining/g
s/『G3063』/henceforth/g
s/『G3064』/henceforth/g
s/『G3065』/Luke/g
s/『G3066』/Lucius/g
s/『G3067』/washing/g
s/『G3068』/to wash/g
s/『G3069』/Lydda/g
s/『G3070』/Lydia/g
s/『G3071』/Lycaonia/g
s/『G3072』/in Lycaonian/g
s/『G3073』/Lycia/g
s/『G3074』/wolf/g
s/『G3075』/to ravage/g
s/『G3076』/to grieve/g
s/『G3077』/grief/g
s/『G3078』/Lysanias/g
s/『G3079』/Lysias/g
s/『G3080』/divorce/g
s/『G3081』/to profit/g
s/『G3082』/Lystra/g
s/『G3083』/ransom/g
s/『G3084』/to ransom/g
s/『G3085』/redemption/g
s/『G3086』/redeemer/g
s/『G3087』/lampstand/g
s/『G3088』/lamp/g
s/『G3089』/to loose/g
s/『G3090』/Lois/g
s/『G3091』/Lot/g
s/『G3092』/Maath/g
s/『G3093』/Magadan/g
s/『G3094』/Magdalene/g
s/『G3095』/magic/g
s/『G3096』/to practice magic/g
s/『G3097』/sage/g
s/『G3098』/Magog/g
s/『G3099』/Midian/g
s/『G3100』/to disciple/g
s/『G3101』/disciple/g
s/『G3102』/disciple/g
s/『G3103』/Methuselah/g
s/『G3104』/Menna/g
s/『G3105』/to rave/g
s/『G3106』/to bless/g
s/『G3107』/blessed/g
s/『G3108』/blessedness/g
s/『G3109』/Macedonia/g
s/『G3110』/Macedonian/g
s/『G3111』/meat market/g
s/『G3112』/far/g
s/『G3113』/from afar/g
s/『G3114』/to have patience/g
s/『G3115』/patience/g
s/『G3116』/patiently/g
s/『G3117』/long\/distant/g
s/『G3118』/long-lived/g
s/『G3119』/sickness/g
s/『G3120』/soft\/effeminate/g
s/『G3121』/Mahalalel/g
s/『G3122』/especially/g
s/『G3123』/more/g
s/『G3124』/Malchus/g
s/『G3125』/grandmother/g
s/『G3126』/wealth/g
s/『G3127』/Manaen/g
s/『G3128』/Manasseh/g
s/『G3129』/to learn/g
s/『G3130』/insanity/g
s/『G3131』/manna/g
s/『G3132』/to divine/g
s/『G3133』/to fade/g
s/『G3134』/Come, Lord!/g
s/『G3135』/pearl/g
s/『G3136』/Martha/g
s/『G3137』/Mary/g
s/『G3138』/Mark/g
s/『G3139』/marble/g
s/『G3140』/to testify/g
s/『G3141』/testimony/g
s/『G3142』/testimony/g
s/『G3143』/to testify/g
s/『G3144』/witness/g
s/『G3145』/to gnaw/g
s/『G3146』/to whip/g
s/『G3147』/to whip/g
s/『G3148』/whip/g
s/『G3149』/breast/g
s/『G3150』/babble/g
s/『G3151』/babbler/g
s/『G3152』/futile/g
s/『G3153』/futility/g
s/『G3154』/to make futile/g
s/『G3155』/in vain/g
s/『G3156』/Matthew/g
s/『G3157』/Matthan/g
s/『G3158』/Matthat/g
s/『G3159』/Matthias/g
s/『G3160』/Mattatha/g
s/『G3161』/Mattathias/g
s/『G3162』/sword/g
s/『G3163』/quarrel/g
s/『G3164』/to quarrel/g
s/『G3165』/me/g
s/『G3166』/to boast/g
s/『G3167』/great thing/g
s/『G3168』/majesty/g
s/『G3169』/majestic/g
s/『G3170』/to magnify/g
s/『G3171』/greatly/g
s/『G3172』/majesty/g
s/『G3173』/great/g
s/『G3174』/greatness/g
s/『G3175』/great man/g
s/『G3176』/greatest/g
s/『G3177』/to mean/g
s/『G3178』/drunkenness/g
s/『G3179』/to move/g
s/『G3180』/scheme/g
s/『G3181』/boundary/g
s/『G3182』/to get drunk/g
s/『G3183』/drunkard/g
s/『G3184』/to get drunk/g
s/『G3185』/greater/g
s/『G3186』/greatest/g
s/『G3187』/greater/g
s/『G3188』/ink/g
s/『G3189』/black/g
s/『G3190』/Melea/g
s/『G3191』/to meditate\/plot/g
s/『G3192』/honey/g
s/『G3193』/honeycomb/g
s/『G3194』/Malta/g
s/『G3195』/be about to/g
s/『G3196』/member/g
s/『G3197』/Melki/g
s/『G3198』/Melchizedek/g
s/『G3199』/to care/g
s/『G3200』/parchment/g
s/『G3201』/to blame/g
s/『G3202』/malcontent/g
s/『G3303』/on the other hand/g
s/『G3304』/rather/g
s/『G3305』/yet/g
s/『G3306』/to stay/g
s/『G3307』/to divide/g
s/『G3308』/concern/g
s/『G3309』/to worry/g
s/『G3310』/part/g
s/『G3311』/division/g
s/『G3312』/arbiter/g
s/『G3313』/part/g
s/『G3314』/noon\/south/g
s/『G3315』/to guarantee/g
s/『G3316』/mediator/g
s/『G3317』/midnight/g
s/『G3318』/Mesopotamia/g
s/『G3319』/midst/g
s/『G3320』/wall/g
s/『G3321』/midair/g
s/『G3322』/be in the middle/g
s/『G3323』/Messiah/g
s/『G3324』/full/g
s/『G3325』/to fill/g
s/『G3326』/with\/after/g
s/『G3327』/to depart/g
s/『G3328』/to change mind/g
s/『G3329』/to turn/g
s/『G3330』/to share/g
s/『G3331』/removal\/change/g
s/『G3332』/to leave/g
s/『G3333』/to summon/g
s/『G3334』/to shift/g
s/『G3335』/to partake/g
s/『G3336』/partaking of/g
s/『G3337』/to exchange/g
s/『G3338』/to repent/g
s/『G3339』/to transform/g
s/『G3340』/to repent/g
s/『G3341』/repentance/g
s/『G3342』/between\/meanwhile/g
s/『G3343』/to summon/g
s/『G3344』/to change/g
s/『G3345』/to transform/g
s/『G3346』/to transport/g
s/『G3347』/afterward/g
s/『G3348』/to share/g
s/『G3349』/to worry/g
s/『G3350』/deportation/g
s/『G3351』/to deport/g
s/『G3352』/participation/g
s/『G3353』/partaker/g
s/『G3354』/to measure/g
s/『G3355』/measure/g
s/『G3356』/be gentle/g
s/『G3357』/moderately/g
s/『G3358』/measure/g
s/『G3359』/forehead/g
s/『G3360』/until/g
s/『G3361』/not/g
s/『G3362』/unless/g
s/『G3363』/lest\/so that... not/g
s/『G3364』/never/g
s/『G3365』/surely not/g
s/『G3366』/not/g
s/『G3367』/nothing/g
s/『G3368』/never/g
s/『G3369』/not yet/g
s/『G3370』/Mede/g
s/『G3371』/never again/g
s/『G3372』/length/g
s/『G3373』/to grow/g
s/『G3374』/sheepskin/g
s/『G3375』/certainly/g
s/『G3376』/month/g
s/『G3377』/to disclose/g
s/『G3378』/isn't it?/g
s/『G3379』/lest/g
s/『G3380』/not yet/g
s/『G3381』/so that/g
s/『G3382』/thigh/g
s/『G3383』/neither/g
s/『G3384』/mother/g
s/『G3385』/no?/g
s/『G3386』/how much more/g
s/『G3387』/unless\/any/g
s/『G3388』/womb/g
s/『G3389』/matricide/g
s/『G3390』/capital/g
s/『G3391』/first/g
s/『G3392』/to stain/g
s/『G3393』/defilement/g
s/『G3394』/defilement/g
s/『G3395』/mixture/g
s/『G3396』/to mix/g
s/『G3397』/little/g
s/『G3398』/small/g
s/『G3399』/Miletus/g
s/『G3400』/mile/g
s/『G3401』/to imitate/g
s/『G3402』/imitator/g
s/『G3403』/to remember/g
s/『G3404』/to hate/g
s/『G3405』/recompense/g
s/『G3406』/rewarder/g
s/『G3407』/hired worker/g
s/『G3408』/wage/g
s/『G3409』/to hire/g
s/『G3410』/rented home/g
s/『G3411』/hired worker/g
s/『G3412』/Mitylene/g
s/『G3413』/Michael/g
s/『G3414』/mina/g
s/『G3415』/to remember/g
s/『G3416』/Mnason/g
s/『G3417』/remembrance/g
s/『G3418』/tomb/g
s/『G3419』/grave/g
s/『G3420』/remembrance/g
s/『G3421』/to remember/g
s/『G3422』/memorial/g
s/『G3423』/to betroth/g
s/『G3424』/hardly talking/g
s/『G3425』/hardly/g
s/『G3426』/bucket/g
s/『G3427』/to me/g
s/『G3428』/adulterous/g
s/『G3429』/to commit adultery/g
s/『G3430』/adultery/g
s/『G3431』/to commit adultery/g
s/『G3432』/adulterer/g
s/『G3433』/hardly/g
s/『G3434』/Molech/g
s/『G3435』/to defile/g
s/『G3436』/defilement/g
s/『G3437』/complaint/g
s/『G3438』/abode/g
s/『G3439』/unique/g
s/『G3440』/only/g
s/『G3441』/alone/g
s/『G3442』/one-eyed/g
s/『G3443』/to leave alone/g
s/『G3444』/form/g
s/『G3445』/to form/g
s/『G3446』/form/g
s/『G3447』/to make a calf/g
s/『G3448』/calf/g
s/『G3449』/toil/g
s/『G3450』/of me/g
s/『G3451』/musician/g
s/『G3452』/marrow/g
s/『G3453』/to initiate/g
s/『G3454』/myth/g
s/『G3455』/to roar/g
s/『G3456』/to mock/g
s/『G3457』/millstone/g
s/『G3458』/millstone/g
s/『G3459』/millhouse/g
s/『G3460』/Myra/g
s/『G3461』/myriad/g
s/『G3462』/to anoint/g
s/『G3463』/myriad/g
s/『G3464』/ointment/g
s/『G3465』/Mysia/g
s/『G3466』/mystery/g
s/『G3467』/be nearsighted/g
s/『G3468』/wound/g
s/『G3469』/to blame/g
s/『G3470』/blemish/g
s/『G3471』/to make insipid/g
s/『G3472』/foolishness/g
s/『G3473』/foolish talk/g
s/『G3474』/foolish/g
s/『G3475』/Moses/g
s/『G3476』/Nahshon/g
s/『G3477』/Naggai/g
s/『G3478』/Nazareth/g
s/『G3479』/Nazarene/g
s/『G3480』/Nazarene/g
s/『G3481』/Nathan/g
s/『G3482』/Nathanael/g
s/『G3483』/yes/g
s/『G3484』/Nain/g
s/『G3485』/temple/g
s/『G3486』/Nahum/g
s/『G3487』/nard/g
s/『G3488』/Narcissus/g
s/『G3489』/be shipwrecked/g
s/『G3490』/captain/g
s/『G3491』/ship/g
s/『G3492』/sailor/g
s/『G3493』/Nahor/g
s/『G3494』/young man/g
s/『G3495』/young man/g
s/『G3496』/Neapolis/g
s/『G3497』/Naaman/g
s/『G3498』/dead/g
s/『G3499』/to put to death/g
s/『G3500』/death/g
s/『G3501』/new/g
s/『G3502』/nestling/g
s/『G3503』/youth/g
s/『G3504』/new convert/g
s/『G3505』/Nero/g
s/『G3506』/to motion/g
s/『G3507』/cloud/g
s/『G3508』/Naphtali/g
s/『G3509』/cloud/g
s/『G3510』/mind/g
s/『G3511』/temple guard/g
s/『G3512』/youthful/g
s/『G3513』/as surely as/g
s/『G3514』/to spin/g
s/『G3515』/be childlike/g
s/『G3516』/child/g
s/『G3517』/Nereus/g
s/『G3518』/Neri/g
s/『G3519』/small island/g
s/『G3520』/island/g
s/『G3521』/fasting/g
s/『G3522』/to fast/g
s/『G3523』/fasting/g
s/『G3524』/sober/g
s/『G3525』/be sober/g
s/『G3526』/Niger/g
s/『G3527』/Nicanor/g
s/『G3528』/to conquer/g
s/『G3529』/victory/g
s/『G3530』/Nicodemus/g
s/『G3531』/Nicolaitan/g
s/『G3532』/Nicolas/g
s/『G3533』/Nicopolis/g
s/『G3534』/victory/g
s/『G3535』/Nineveh/g
s/『G3536』/Ninevite/g
s/『G3537』/wash basin/g
s/『G3538』/to wash/g
s/『G3539』/to understand/g
s/『G3540』/mind\/thought/g
s/『G3541』/illegitimate/g
s/『G3542』/pasture/g
s/『G3543』/to think/g
s/『G3544』/lawyer/g
s/『G3545』/lawfully/g
s/『G3546』/coin/g
s/『G3547』/teacher of the law/g
s/『G3548』/law/g
s/『G3549』/to give laws/g
s/『G3550』/lawgiver/g
s/『G3551』/law/g
s/『G3552』/be sick/g
s/『G3553』/disease/g
s/『G3554』/illness/g
s/『G3555』/chick/g
s/『G3556』/chick/g
s/『G3557』/to embezzle/g
s/『G3558』/south/g
s/『G3559』/admonition/g
s/『G3560』/to admonish/g
s/『G3561』/New Moon/g
s/『G3562』/wisely/g
s/『G3563』/mind/g
s/『G3564』/Nympha/g
s/『G3565』/bride/g
s/『G3566』/bridegroom/g
s/『G3567』/bridegroom/g
s/『G3568』/now/g
s/『G3569』/now/g
s/『G3570』/now/g
s/『G3571』/night/g
s/『G3572』/to pierce/g
s/『G3573』/to doze/g
s/『G3574』/and night and a day/g
s/『G3575』/Noah/g
s/『G3576』/dull/g
s/『G3577』/back/g
s/『G3578』/lodging/g
s/『G3579』/to host/g
s/『G3580』/to show hospitality/g
s/『G3581』/foreign/g
s/『G3582』/pitcher/g
s/『G3583』/to dry/g
s/『G3584』/dried up\/withered/g
s/『G3585』/wooden/g
s/『G3586』/wood/g
s/『G3587』/to shave/g
s/『G3588』/the\/this\/who/g
s/『G3589』/eighty/g
s/『G3590』/eighth/g
s/『G3591』/impediment/g
s/『G3592』/this/g
s/『G3593』/to journey/g
s/『G3594』/to guide/g
s/『G3595』/guide\/leader/g
s/『G3596』/to journey/g
s/『G3597』/journey/g
s/『G3598』/road/g
s/『G3599』/tooth/g
s/『G3600』/be anguished/g
s/『G3601』/anguish/g
s/『G3602』/mourning/g
s/『G3603』/which is/g
s/『G3604』/Uzziah/g
s/『G3605』/to stink/g
s/『G3606』/whence/g
s/『G3607』/sheet/g
s/『G3608』/bandages/g
s/『G3609』/of one’s household/g
s/『G3610』/slave/g
s/『G3611』/to dwell/g
s/『G3612』/cell/g
s/『G3613』/dwelling/g
s/『G3614』/house/g
s/『G3615』/member of a house/g
s/『G3616』/to manage a house/g
s/『G3617』/householder/g
s/『G3618』/to build/g
s/『G3619』/building/g
s/『G3620』/edification/g
s/『G3621』/to manage/g
s/『G3622』/management/g
s/『G3623』/manager/g
s/『G3624』/house/g
s/『G3625』/world/g
s/『G3626』/busy at home/g
s/『G3627』/to have compassion/g
s/『G3628』/compassion/g
s/『G3629』/compassionate/g
s/『G3630』/drunkard/g
s/『G3631』/wine/g
s/『G3632』/drunkenness/g
s/『G3633』/to suppose/g
s/『G3634』/such as/g
s/『G3635』/to delay/g
s/『G3636』/lazy/g
s/『G3637』/eighth day/g
s/『G3638』/eight/g
s/『G3639』/destructive/g
s/『G3640』/of little faith/g
s/『G3641』/little\/few/g
s/『G3642』/fainthearted/g
s/『G3643』/to despise/g
s/『G3644』/destroyer/g
s/『G3645』/to destroy/g
s/『G3646』/burnt offering/g
s/『G3647』/wholeness/g
s/『G3648』/whole/g
s/『G3649』/to wail/g
s/『G3650』/all/g
s/『G3651』/wholly/g
s/『G3652』/Olympas/g
s/『G3653』/late fig/g
s/『G3654』/at all/g
s/『G3655』/rainstorm/g
s/『G3656』/to talk/g
s/『G3657』/association/g
s/『G3658』/crowd/g
s/『G3659』/eye/g
s/『G3660』/to swear/g
s/『G3661』/united/g
s/『G3662』/to resemble/g
s/『G3663』/like/g
s/『G3664』/like/g
s/『G3665』/likeness/g
s/『G3666』/to liken/g
s/『G3667』/likeness/g
s/『G3668』/likewise/g
s/『G3669』/likeness/g
s/『G3670』/to confess\/profess/g
s/『G3671』/confession/g
s/『G3672』/undeniably/g
s/『G3673』/of the same trade/g
s/『G3674』/together/g
s/『G3675』/like-minded/g
s/『G3676』/just as/g
s/『G3677』/dream/g
s/『G3678』/young donkey/g
s/『G3679』/to revile/g
s/『G3680』/reproach/g
s/『G3681』/disgrace/g
s/『G3682』/Onesimus/g
s/『G3683』/Onesiphorus/g
s/『G3684』/huge millstone/g
s/『G3685』/to have joy/g
s/『G3686』/name/g
s/『G3687』/to name/g
s/『G3688』/donkey/g
s/『G3689』/really/g
s/『G3690』/vinegar/g
s/『G3691』/sharp\/swift/g
s/『G3692』/hole/g
s/『G3693』/after/g
s/『G3694』/after/g
s/『G3695』/to arm/g
s/『G3696』/weapon/g
s/『G3697』/what sort/g
s/『G3698』/when\(-ever\)/g
s/『G3699』/where\(-ever\)/g
s/『G3700』/to appear/g
s/『G3701』/vision/g
s/『G3702』/broiled/g
s/『G3703』/fruit/g
s/『G3704』/that/g
s/『G3705』/vision/g
s/『G3706』/appearance\/vision/g
s/『G3707』/visible/g
s/『G3708』/to see/g
s/『G3709』/wrath/g
s/『G3710』/to anger/g
s/『G3711』/quick-tempered/g
s/『G3712』/a fathom/g
s/『G3713』/to aspire/g
s/『G3714』/hilly/g
s/『G3715』/lust/g
s/『G3716』/be upright/g
s/『G3717』/upright/g
s/『G3718』/to cut straight/g
s/『G3719』/to rise at dawn/g
s/『G3720』/dawn/g
s/『G3721』/morning/g
s/『G3722』/dawn/g
s/『G3723』/correctly/g
s/『G3724』/to determine/g
s/『G3725』/region/g
s/『G3726』/to adjure/g
s/『G3727』/oath/g
s/『G3728』/oath/g
s/『G3729』/to stampede/g
s/『G3730』/impulse/g
s/『G3731』/sudden violence/g
s/『G3732』/bird/g
s/『G3733』/hen/g
s/『G3734』/fixed boundary/g
s/『G3735』/mountain/g
s/『G3736』/to dig/g
s/『G3737』/orphan/g
s/『G3738』/to dance/g
s/『G3739』/which/g
s/『G3740』/whenever/g
s/『G3741』/holy/g
s/『G3742』/holiness/g
s/『G3743』/devoutly/g
s/『G3744』/aroma/g
s/『G3745』/just as\/how much/g
s/『G3746』/who/g
s/『G3747』/bone/g
s/『G3748』/who\/which/g
s/『G3749』/clay/g
s/『G3750』/sense of smell/g
s/『G3751』/loins/g
s/『G3752』/when\(-ever\)/g
s/『G3753』/when/g
s/『G3754』/that\/since/g
s/『G3755』/until/g
s/『G3756』/no/g
s/『G3757』/where/g
s/『G3758』/aha!/g
s/『G3759』/woe!/g
s/『G3760』/by no means/g
s/『G3761』/and not/g
s/『G3762』/no one/g
s/『G3763』/never/g
s/『G3764』/never/g
s/『G3765』/not any more/g
s/『G3766』/so/g
s/『G3767』/therefore\/then/g
s/『G3768』/not yet/g
s/『G3769』/tail/g
s/『G3770』/heavenly/g
s/『G3771』/from heaven/g
s/『G3772』/heaven/g
s/『G3773』/Urbanus/g
s/『G3774』/Uriah/g
s/『G3775』/ear/g
s/『G3776』/estate/g
s/『G3777』/neither/g
s/『G3778』/this\/he\/she\/it/g
s/『G3779』/thus\(-ly\)/g
s/『G3780』/not/g
s/『G3781』/debtor/g
s/『G3782』/debt/g
s/『G3783』/debt/g
s/『G3784』/to owe/g
s/『G3785』/I wish!/g
s/『G3786』/gain/g
s/『G3787』/eye-service/g
s/『G3788』/eye/g
s/『G3789』/snake/g
s/『G3790』/brow/g
s/『G3791』/to disturb/g
s/『G3792』/to riot/g
s/『G3793』/crowd/g
s/『G3794』/stronghold/g
s/『G3795』/fish/g
s/『G3796』/evening/g
s/『G3797』/late \(rain\)/g
s/『G3798』/evening/g
s/『G3799』/face/g
s/『G3800』/compensation/g
s/『G3801』/who was, is, and will be/g
s/『G3802』/to trap/g
s/『G3803』/trap/g
s/『G3804』/suffering/g
s/『G3805』/suffering/g
s/『G3806』/passion/g
s/『G3807』/guardian/g
s/『G3808』/boy/g
s/『G3809』/discipline/g
s/『G3810』/instructor/g
s/『G3811』/to instruct/g
s/『G3812』/from childhood/g
s/『G3813』/child/g
s/『G3814』/maidservant/g
s/『G3815』/to play/g
s/『G3816』/child/g
s/『G3817』/to strike/g
s/『G3818』/Pacatian/g
s/『G3819』/of old/g
s/『G3820』/old/g
s/『G3821』/oldness/g
s/『G3822』/to make old/g
s/『G3823』/struggle/g
s/『G3824』/regeneration/g
s/『G3825』/again/g
s/『G3826』/together/g
s/『G3827』/great/g
s/『G3828』/Pamphylia/g
s/『G3829』/inn/g
s/『G3830』/innkeeper/g
s/『G3831』/assembly/g
s/『G3832』/with all the house/g
s/『G3833』/complete armor/g
s/『G3834』/craftiness/g
s/『G3835』/crafty/g
s/『G3836』/from all sides/g
s/『G3837』/everywhere/g
s/『G3838』/completely/g
s/『G3839』/always/g
s/『G3840』/from all sides/g
s/『G3841』/almighty/g
s/『G3842』/always/g
s/『G3843』/surely/g
s/『G3844』/from\/with\/beside/g
s/『G3845』/to transgress/g
s/『G3846』/to arrive/g
s/『G3847』/transgression/g
s/『G3848』/transgresor/g
s/『G3849』/to urge/g
s/『G3850』/parable/g
s/『G3851』/to risk/g
s/『G3852』/order/g
s/『G3853』/to order/g
s/『G3854』/to come/g
s/『G3855』/to pass/g
s/『G3856』/to disgrace/g
s/『G3857』/paradise/g
s/『G3858』/to receive/g
s/『G3859』/contention/g
s/『G3860』/to deliver/g
s/『G3861』/remarkable/g
s/『G3862』/tradition/g
s/『G3863』/to make envious/g
s/『G3864』/seaside/g
s/『G3865』/to neglect/g
s/『G3866』/deposit/g
s/『G3867』/to urge/g
s/『G3868』/to refuse\/excuse/g
s/『G3869』/to sit by/g
s/『G3870』/to plead\/comfort/g
s/『G3871』/to hide/g
s/『G3872』/deposit/g
s/『G3873』/be present/g
s/『G3874』/encouragement/g
s/『G3875』/counsellor/g
s/『G3876』/disobedience/g
s/『G3877』/to follow/g
s/『G3878』/to ignore/g
s/『G3879』/to stoop/g
s/『G3880』/to take/g
s/『G3881』/to sail past/g
s/『G3882』/seaside/g
s/『G3883』/variation/g
s/『G3884』/to deceive/g
s/『G3885』/paralytic/g
s/『G3886』/to paralyze/g
s/『G3887』/to continue/g
s/『G3888』/to encourage/g
s/『G3889』/comfort/g
s/『G3890』/comfort/g
s/『G3891』/to break the law/g
s/『G3892』/lawlessness/g
s/『G3893』/to rebel/g
s/『G3894』/rebellion/g
s/『G3895』/to defect/g
s/『G3896』/to sail past/g
s/『G3897』/almost/g
s/『G3898』/similarly/g
s/『G3899』/to pass by\/through/g
s/『G3900』/trespass/g
s/『G3901』/to drift away/g
s/『G3902』/figurehead/g
s/『G3903』/to prepare/g
s/『G3904』/Preparation Day/g
s/『G3905』/to prolong/g
s/『G3906』/to observe/g
s/『G3907』/observation/g
s/『G3908』/to set before/g
s/『G3909』/be there/g
s/『G3910』/momentary/g
s/『G3911』/to take away/g
s/『G3912』/be insane/g
s/『G3913』/insanity/g
s/『G3914』/to winter/g
s/『G3915』/wintering/g
s/『G3916』/instantly/g
s/『G3917』/leopard/g
s/『G3918』/be present/g
s/『G3919』/to introduce/g
s/『G3920』/infiltrated/g
s/『G3921』/to infiltrate/g
s/『G3922』/to come in/g
s/『G3923』/to supplement/g
s/『G3924』/except/g
s/『G3925』/barracks/g
s/『G3926』/to trouble/g
s/『G3927』/stranger/g
s/『G3928』/to pass by/g
s/『G3929』/passing over/g
s/『G3930』/to furnish occasion/g
s/『G3931』/comfort/g
s/『G3932』/virginity/g
s/『G3933』/virgin/g
s/『G3934』/Parthian/g
s/『G3935』/to neglect/g
s/『G3936』/to stand by/g
s/『G3937』/Parmenas/g
s/『G3938』/passing by/g
s/『G3939』/be a stranger/g
s/『G3940』/sojourning/g
s/『G3941』/foreigner/g
s/『G3942』/proverb/g
s/『G3943』/drunken/g
s/『G3944』/to pass by/g
s/『G3945』/to resemble/g
s/『G3946』/like/g
s/『G3947』/to provoke/g
s/『G3948』/stirring up/g
s/『G3949』/to anger/g
s/『G3950』/anger/g
s/『G3951』/to incite/g
s/『G3952』/coming/g
s/『G3953』/dish/g
s/『G3954』/boldness/g
s/『G3955』/to preach boldly/g
s/『G3956』/all/g
s/『G3957』/Passover/g
s/『G3958』/to suffer/g
s/『G3959』/Patara/g
s/『G3960』/to strike/g
s/『G3961』/to trample/g
s/『G3962』/father/g
s/『G3963』/Patmos/g
s/『G3964』/patricide/g
s/『G3965』/family line/g
s/『G3966』/patriarch/g
s/『G3967』/paternal/g
s/『G3968』/fatherland/g
s/『G3969』/Patrobas/g
s/『G3970』/from forefathers/g
s/『G3971』/ancestral/g
s/『G3972』/Paul/g
s/『G3973』/to cease/g
s/『G3974』/Paphos/g
s/『G3975』/to thicken/g
s/『G3976』/fetter/g
s/『G3977』/level/g
s/『G3978』/to walk/g
s/『G3979』/on foot/g
s/『G3980』/to obey/g
s/『G3981』/persuasive/g
s/『G3982』/to persuade/g
s/『G3983』/to hunger/g
s/『G3984』/test/g
s/『G3985』/to test\/tempt/g
s/『G3986』/temptation\/testing/g
s/『G3987』/to try/g
s/『G3988』/persuasion/g
s/『G3989』/sea/g
s/『G3990』/to behead/g
s/『G3991』/fifth/g
s/『G3992』/to send/g
s/『G3993』/poor/g
s/『G3994』/mother-in-law/g
s/『G3995』/father-in-law/g
s/『G3996』/to mourn/g
s/『G3997』/grief/g
s/『G3998』/poor/g
s/『G3999』/five times/g
s/『G4000』/five thousand/g
s/『G4001』/five hundred/g
s/『G4002』/five/g
s/『G4003』/fifteenth/g
s/『G4004』/fifty/g
s/『G4005』/Pentecost/g
s/『G4006』/confidence/g
s/『G4007』/fully/g
s/『G4008』/other side/g
s/『G4009』/end/g
s/『G4010』/Pergamum/g
s/『G4011』/Perga/g
s/『G4012』/about/g
s/『G4013』/to take\/go around/g
s/『G4014』/to take away/g
s/『G4015』/to shine/g
s/『G4016』/to clothe/g
s/『G4017』/to look around/g
s/『G4018』/covering/g
s/『G4019』/to wrap around/g
s/『G4020』/be a busybody/g
s/『G4021』/meddlesome\/magic/g
s/『G4022』/to go around/g
s/『G4023』/to contain/g
s/『G4024』/to gird/g
s/『G4025』/wearing/g
s/『G4026』/to stand around/g
s/『G4027』/garbage/g
s/『G4028』/to cover/g
s/『G4029』/to surround/g
s/『G4030』/helmet/g
s/『G4031』/in control of/g
s/『G4032』/to hide/g
s/『G4033』/to surround/g
s/『G4034』/to shine around/g
s/『G4035』/to remain/g
s/『G4036』/sorrowful/g
s/『G4037』/to await/g
s/『G4038』/around/g
s/『G4039』/to dwell around/g
s/『G4040』/neighboring/g
s/『G4041』/special/g
s/『G4042』/passage/g
s/『G4043』/to walk/g
s/『G4044』/to pierce/g
s/『G4045』/to fall upon/g
s/『G4046』/to gain/g
s/『G4047』/acquiring/g
s/『G4048』/to strip off/g
s/『G4049』/to distract/g
s/『G4050』/abundance/g
s/『G4051』/overflow/g
s/『G4052』/to abound\/exceed/g
s/『G4053』/excessive\/abundant/g
s/『G4054』/more abundantly/g
s/『G4055』/superabundant/g
s/『G4056』/superabundantly/g
s/『G4057』/superabundantly/g
s/『G4058』/dove/g
s/『G4059』/to circumcise/g
s/『G4060』/to put on/g
s/『G4061』/circumcision/g
s/『G4062』/to drive insane/g
s/『G4063』/to run around/g
s/『G4064』/to carry \(around\)/g
s/『G4065』/to despise/g
s/『G4066』/surrounding region/g
s/『G4067』/scum/g
s/『G4068』/to boast/g
s/『G4069』/Persis/g
s/『G4070』/last year/g
s/『G4071』/bird/g
s/『G4072』/to fly/g
s/『G4073』/rock/g
s/『G4074』/Peter/g
s/『G4075』/rocky/g
s/『G4076』/rue/g
s/『G4077』/flow/g
s/『G4078』/to set up/g
s/『G4079』/rudder/g
s/『G4080』/how great/g
s/『G4081』/clay/g
s/『G4082』/bag/g
s/『G4083』/cubit\/hour/g
s/『G4084』/to arrest\/catch/g
s/『G4085』/to press down/g
s/『G4086』/persuasive speech/g
s/『G4087』/to embitter/g
s/『G4088』/bitterness/g
s/『G4089』/bitter/g
s/『G4090』/bitterly/g
s/『G4091』/Pilate/g
s/『G4092』/to swell up/g
s/『G4093』/little tablet/g
s/『G4094』/platter/g
s/『G4095』/to drink/g
s/『G4096』/richness/g
s/『G4097』/to sell/g
s/『G4098』/to collapse/g
s/『G4099』/Pisidia/g
s/『G4100』/to trust \(in\)/g
s/『G4101』/pure/g
s/『G4102』/faith\/trust/g
s/『G4103』/faithful/g
s/『G4104』/be convinced/g
s/『G4105』/to lead astray/g
s/『G4106』/error/g
s/『G4107』/wandering/g
s/『G4108』/deceiving/g
s/『G4109』/tablet/g
s/『G4110』/formed thing/g
s/『G4111』/to mold/g
s/『G4112』/made-up/g
s/『G4113』/wide street\/road/g
s/『G4114』/width/g
s/『G4115』/to widen/g
s/『G4116』/wide/g
s/『G4117』/braided/g
s/『G4118』/most/g
s/『G4119』/greater/g
s/『G4120』/to weave/g
s/『G4121』/to increase/g
s/『G4122』/to exploit/g
s/『G4123』/greedy/g
s/『G4124』/greediness/g
s/『G4125』/side/g
s/『G4126』/to sail/g
s/『G4127』/plague\/blow\/wound/g
s/『G4128』/multitude/g
s/『G4129』/to multiply/g
s/『G4130』/to fill/g
s/『G4131』/bully/g
s/『G4132』/flood/g
s/『G4133』/but\/however/g
s/『G4134』/full/g
s/『G4135』/to fulfill/g
s/『G4136』/assurance/g
s/『G4137』/to fulfill/g
s/『G4138』/fulfillment/g
s/『G4139』/near\/neighbor/g
s/『G4140』/gratification/g
s/『G4141』/to strike/g
s/『G4142』/small boat/g
s/『G4143』/boat/g
s/『G4144』/voyage/g
s/『G4145』/rich/g
s/『G4146』/richly/g
s/『G4147』/be rich/g
s/『G4148』/to enrich/g
s/『G4149』/riches/g
s/『G4150』/to wash/g
s/『G4151』/spirit\/breath/g
s/『G4152』/spiritual/g
s/『G4153』/spiritually/g
s/『G4154』/to blow/g
s/『G4155』/to choke/g
s/『G4156』/strangled/g
s/『G4157』/wind\/breath/g
s/『G4158』/floorlength/g
s/『G4159』/where/g
s/『G4160』/to do\/make/g
s/『G4161』/workmanship/g
s/『G4162』/doing/g
s/『G4163』/doer/g
s/『G4164』/various/g
s/『G4165』/to shepherd/g
s/『G4166』/shepherd/g
s/『G4167』/flock/g
s/『G4168』/flock/g
s/『G4169』/what?/g
s/『G4170』/to fight/g
s/『G4171』/war/g
s/『G4172』/city/g
s/『G4173』/city authority/g
s/『G4174』/citizenship/g
s/『G4175』/citizenship/g
s/『G4176』/be a citizen/g
s/『G4177』/citizen/g
s/『G4178』/often/g
s/『G4179』/many times more/g
s/『G4180』/wordiness/g
s/『G4181』/little by little/g
s/『G4182』/manifold/g
s/『G4183』/much/g
s/『G4184』/very compassionate/g
s/『G4185』/valuable/g
s/『G4186』/valuable/g
s/『G4187』/in many ways/g
s/『G4188』/drink/g
s/『G4189』/evil/g
s/『G4190』/evil\/bad/g
s/『G4191』/more evil/g
s/『G4192』/travail/g
s/『G4193』/from Pontus/g
s/『G4194』/Pontius/g
s/『G4195』/Pontus/g
s/『G4196』/Publius/g
s/『G4197』/journey/g
s/『G4198』/to go/g
s/『G4199』/to lay waste/g
s/『G4200』/gain/g
s/『G4201』/Porcius/g
s/『G4202』/sexual sin/g
s/『G4203』/to sin sexually/g
s/『G4204』/prostitute/g
s/『G4205』/sexual sinner/g
s/『G4206』/far \(away\)/g
s/『G4207』/afar off/g
s/『G4208』/farther/g
s/『G4209』/purple/g
s/『G4210』/purple/g
s/『G4211』/dealer in purple/g
s/『G4212』/how often!/g
s/『G4213』/drink/g
s/『G4214』/how much\/many/g
s/『G4215』/river/g
s/『G4216』/flooded/g
s/『G4217』/of what kind?/g
s/『G4218』/once\/when/g
s/『G4219』/when?/g
s/『G4220』/whether/g
s/『G4221』/cup/g
s/『G4222』/to water/g
s/『G4223』/Puteoli/g
s/『G4224』/carousing/g
s/『G4225』/somewhere/g
s/『G4226』/where?/g
s/『G4227』/Pudens/g
s/『G4228』/foot/g
s/『G4229』/thing/g
s/『G4230』/affairs/g
s/『G4231』/to trade/g
s/『G4232』/praetorium/g
s/『G4233』/bailiff/g
s/『G4234』/action/g
s/『G4235』/gentle/g
s/『G4236』/gentleness/g
s/『G4237』/group/g
s/『G4238』/to do\/require/g
s/『G4239』/gentle/g
s/『G4240』/gentleness/g
s/『G4241』/be proper/g
s/『G4242』/delegation/g
s/『G4243』/be ambassador/g
s/『G4244』/council of elders/g
s/『G4245』/elder/g
s/『G4246』/old man/g
s/『G4247』/old woman/g
s/『G4248』/headlong/g
s/『G4249』/to saw \(in two\)/g
s/『G4250』/before/g
s/『G4251』/Prisca/g
s/『G4252』/Priscilla/g
s/『G4253』/before/g
s/『G4254』/to go\/bring before/g
s/『G4255』/to predetermine/g
s/『G4256』/to accuse/g
s/『G4257』/to hear beforehand/g
s/『G4258』/to sin beforehand/g
s/『G4259』/entryway/g
s/『G4260』/to advance/g
s/『G4261』/to put forth/g
s/『G4262』/Sheep Gate/g
s/『G4263』/sheep/g
s/『G4264』/to prompt/g
s/『G4265』/to foresee\/plan/g
s/『G4266』/to do beforehand/g
s/『G4267』/to know\/choose/g
s/『G4268』/foreknowledge/g
s/『G4269』/parent\/ancestor/g
s/『G4270』/to write\/designate/g
s/『G4271』/obvious/g
s/『G4272』/to give in advance/g
s/『G4273』/traitor/g
s/『G4274』/forerunner/g
s/『G4275』/to foresee/g
s/『G4276』/to hope beforehand/g
s/『G4277』/to predict/g
s/『G4278』/to begin beforehand/g
s/『G4279』/to promise/g
s/『G4280』/to predict/g
s/『G4281』/to go before/g
s/『G4282』/to prepare/g
s/『G4283』/to speak good news/g
s/『G4284』/to excel/g
s/『G4285』/to prefer/g
s/『G4286』/purpose/g
s/『G4287』/set time/g
s/『G4288』/eagerness/g
s/『G4289』/eager/g
s/『G4290』/eagerly/g
s/『G4291』/to set before/g
s/『G4292』/to provoke/g
s/『G4293』/to foretell/g
s/『G4294』/to arrange/g
s/『G4295』/to set before/g
s/『G4296』/to announce/g
s/『G4297』/progress/g
s/『G4298』/to advance/g
s/『G4299』/prejudice/g
s/『G4300』/to establish/g
s/『G4301』/to take beforehand/g
s/『G4302』/to foretell/g
s/『G4303』/to predict/g
s/『G4304』/to premeditate/g
s/『G4305』/to worry beforehand/g
s/『G4306』/to care for/g
s/『G4307』/foresight/g
s/『G4308』/to foresee/g
s/『G4309』/to predestine/g
s/『G4310』/to suffer before/g
s/『G4311』/to help on the way/g
s/『G4312』/reckless/g
s/『G4313』/to go before/g
s/『G4314』/to\/with/g
s/『G4315』/Friday/g
s/『G4316』/to designate/g
s/『G4317』/to bring near/g
s/『G4318』/access/g
s/『G4319』/to beg/g
s/『G4320』/to go up/g
s/『G4321』/to expend/g
s/『G4322』/to supply/g
s/『G4323』/to confer/g
s/『G4324』/to threaten further/g
s/『G4325』/to spend extra/g
s/『G4326』/to need/g
s/『G4327』/to wait for\/welcome/g
s/『G4328』/to look for/g
s/『G4329』/expectation/g
s/『G4330』/to permit/g
s/『G4331』/to approach/g
s/『G4332』/to sit near\/serve/g
s/『G4333』/to earn more/g
s/『G4334』/to come near\/agree/g
s/『G4335』/prayer/g
s/『G4336』/to pray/g
s/『G4337』/to watch out/g
s/『G4338』/to nail/g
s/『G4339』/proselyte/g
s/『G4340』/temporary/g
s/『G4341』/to call to\/summon/g
s/『G4342』/to continue in\/with/g
s/『G4343』/perseverance/g
s/『G4344』/cushion/g
s/『G4345』/to join/g
s/『G4346』/partiality/g
s/『G4347』/to join/g
s/『G4348』/stumbling block/g
s/『G4349』/stumbling/g
s/『G4350』/to strike/g
s/『G4351』/to roll before/g
s/『G4352』/to worship/g
s/『G4353』/worshiper/g
s/『G4354』/to talk to\/with/g
s/『G4355』/to take/g
s/『G4356』/acceptance/g
s/『G4357』/to remain\/persist/g
s/『G4358』/to moor\/anchor/g
s/『G4359』/to owe besides/g
s/『G4360』/be angry/g
s/『G4361』/very hungry/g
s/『G4362』/to nail to/g
s/『G4363』/to fall\/beat/g
s/『G4364』/to pretend/g
s/『G4365』/to approach/g
s/『G4366』/to strike upon/g
s/『G4367』/to order/g
s/『G4368』/patroness/g
s/『G4369』/to add \(to\)/g
s/『G4370』/to hasten/g
s/『G4371』/fish/g
s/『G4372』/new/g
s/『G4373』/recently/g
s/『G4374』/to bring to/g
s/『G4375』/lovely/g
s/『G4376』/offering/g
s/『G4377』/to call to\/summon/g
s/『G4378』/sprinkling/g
s/『G4379』/to touch/g
s/『G4380』/to favor/g
s/『G4381』/prejudiced person/g
s/『G4382』/favoritism/g
s/『G4383』/face/g
s/『G4384』/to predetermine/g
s/『G4385』/to stretch out/g
s/『G4386』/before/g
s/『G4387』/before/g
s/『G4388』/to plan\/present/g
s/『G4389』/to encourage/g
s/『G4390』/to outrun/g
s/『G4391』/be formerly/g
s/『G4392』/pretense/g
s/『G4393』/to bring out/g
s/『G4394』/prophecy/g
s/『G4395』/to prophesy/g
s/『G4396』/prophet/g
s/『G4397』/prophetic/g
s/『G4398』/prophetess/g
s/『G4399』/to come before/g
s/『G4400』/to appoint/g
s/『G4401』/to choose/g
s/『G4402』/Procorus/g
s/『G4403』/stern/g
s/『G4404』/morning/g
s/『G4405』/early morning/g
s/『G4406』/early rain/g
s/『G4407』/morning/g
s/『G4408』/bow/g
s/『G4409』/be first/g
s/『G4410』/seat of honor/g
s/『G4411』/place of honor/g
s/『G4412』/first/g
s/『G4413』/first/g
s/『G4414』/ringleader/g
s/『G4415』/birthright/g
s/『G4416』/firstborn/g
s/『G4417』/to stumble/g
s/『G4418』/heel/g
s/『G4419』/pinnacle/g
s/『G4420』/wing/g
s/『G4421』/bird/g
s/『G4422』/to frighten/g
s/『G4423』/fear/g
s/『G4424』/Ptolemais/g
s/『G4425』/winnowing fork/g
s/『G4426』/to frighten/g
s/『G4427』/saliva/g
s/『G4428』/to roll up/g
s/『G4429』/to spit/g
s/『G4430』/corpse/g
s/『G4431』/fall/g
s/『G4432』/poverty/g
s/『G4433』/be poor/g
s/『G4434』/poor/g
s/『G4435』/fist/g
s/『G4436』/divining spirit/g
s/『G4437』/often/g
s/『G4438』/to box/g
s/『G4439』/gate/g
s/『G4440』/gate/g
s/『G4441』/to inquire/g
s/『G4442』/fire/g
s/『G4443』/fire/g
s/『G4444』/tower/g
s/『G4445』/be feverish/g
s/『G4446』/fever/g
s/『G4447』/fiery/g
s/『G4448』/to burn/g
s/『G4449』/be \(fiery\) red/g
s/『G4450』/fiery red/g
s/『G4451』/burning/g
s/『G4452』/somehow/g
s/『G4453』/to sell/g
s/『G4454』/colt/g
s/『G4455』/ever/g
s/『G4456』/to harden/g
s/『G4457』/hardening/g
s/『G4458』/how/g
s/『G4459』/how?/g
s/『G4460』/Rahab/g
s/『G4461』/Rabbi/g
s/『G4462』/Rabboni/g
s/『G4463』/to beat with a rod/g
s/『G4464』/rod/g
s/『G4465』/police/g
s/『G4466』/Reu/g
s/『G4467』/crime/g
s/『G4468』/trickery/g
s/『G4469』/Raca/g
s/『G4470』/a cloth/g
s/『G4471』/Ramah/g
s/『G4472』/to sprinkle/g
s/『G4473』/sprinkling/g
s/『G4474』/to slap/g
s/『G4475』/slap/g
s/『G4476』/needle/g
s/『G4477』/Rahab/g
s/『G4478』/Rachel/g
s/『G4479』/Rebekah/g
s/『G4480』/carriage/g
s/『G4481』/Rephan/g
s/『G4482』/to \(over\)flow/g
s/『G4483』/to utter/g
s/『G4484』/Rhegium/g
s/『G4485』/destruction/g
s/『G4486』/to throw violently/g
s/『G4487』/word/g
s/『G4488』/Rhesa/g
s/『G4489』/spokesman/g
s/『G4490』/expressly/g
s/『G4491』/root/g
s/『G4492』/to root/g
s/『G4493』/twinkling/g
s/『G4494』/to toss about/g
s/『G4495』/to throw off/g
s/『G4496』/to throw\/lay down/g
s/『G4497』/Rehoboam/g
s/『G4498』/Rhoda/g
s/『G4499』/Rhodes/g
s/『G4500』/with a roar/g
s/『G4501』/sword/g
s/『G4502』/Reuben/g
s/『G4503』/Ruth/g
s/『G4504』/Rufus/g
s/『G4505』/lane/g
s/『G4506』/to rescue/g
s/『G4507』/filth/g
s/『G4508』/filthy/g
s/『G4509』/filth/g
s/『G4510』/to defile/g
s/『G4511』/discharge/g
s/『G4512』/wrinkle/g
s/『G4513』/Latin/g
s/『G4514』/Roman/g
s/『G4515』/in Latin/g
s/『G4516』/Rome/g
s/『G4517』/farewell/g
s/『G4518』/sabachthani/g
s/『G4519』/of Hosts/g
s/『G4520』/Sabbath/g
s/『G4521』/Sabbath/g
s/『G4522』/dragnet/g
s/『G4523』/Sadducee/g
s/『G4524』/Zadok/g
s/『G4525』/to shake/g
s/『G4526』/sackcloth/g
s/『G4527』/Sala/g
s/『G4528』/Salathiel/g
s/『G4529』/Salamis/g
s/『G4530』/Salim/g
s/『G4531』/to shake/g
s/『G4532』/Salem/g
s/『G4533』/Salmon/g
s/『G4534』/Salmone/g
s/『G4535』/tossing/g
s/『G4536』/trumpet/g
s/『G4537』/to sound a trumpet/g
s/『G4538』/trumpeter/g
s/『G4539』/Salome/g
s/『G4540』/Samaria/g
s/『G4541』/Samaritan/g
s/『G4542』/Samaritan/g
s/『G4543』/Samothrace/g
s/『G4544』/Samos/g
s/『G4545』/Samuel/g
s/『G4546』/Samson/g
s/『G4547』/sandal/g
s/『G4548』/plank/g
s/『G4549』/Saul/g
s/『G4550』/rotten/g
s/『G4551』/Sapphira/g
s/『G4552』/sapphire/g
s/『G4553』/basket/g
s/『G4554』/Sardis/g
s/『G4555』/gem/g
s/『G4556』/gem/g
s/『G4557』/sardonyx/g
s/『G4558』/Zarephath/g
s/『G4559』/fleshly/g
s/『G4560』/fleshly/g
s/『G4561』/flesh/g
s/『G4562』/Serug/g
s/『G4563』/to sweep/g
s/『G4564』/Sarah/g
s/『G4565』/Sharon/g
s/『G4566』/Satan/g
s/『G4567』/Satan/g
s/『G4568』/seah/g
s/『G4569』/Saul/g
s/『G4570』/to extinguish/g
s/『G4571』/you/g
s/『G4572』/yourself/g
s/『G4573』/to worship/g
s/『G4574』/object of worship/g
s/『G4575』/august/g
s/『G4576』/be devout/g
s/『G4577』/chain/g
s/『G4578』/earthquake/g
s/『G4579』/to shake/g
s/『G4580』/Secundus/g
s/『G4581』/Seleucia/g
s/『G4582』/moon/g
s/『G4583』/be epileptic/g
s/『G4584』/Semein/g
s/『G4585』/fine flour/g
s/『G4586』/noble/g
s/『G4587』/dignity/g
s/『G4588』/Sergius/g
s/『G4589』/Seth/g
s/『G4590』/Shem/g
s/『G4591』/to signify/g
s/『G4592』/sign/g
s/『G4593』/to note/g
s/『G4594』/today/g
s/『G4595』/to rot/g
s/『G4596』/silk/g
s/『G4597』/moth/g
s/『G4598』/moth-eaten/g
s/『G4599』/to strengthen/g
s/『G4600』/cheek/g
s/『G4601』/be silent/g
s/『G4602』/silence/g
s/『G4603』/iron/g
s/『G4604』/iron/g
s/『G4605』/Sidon/g
s/『G4606』/Sidonian/g
s/『G4607』/assassin/g
s/『G4608』/alcoholic drink/g
s/『G4609』/Silas/g
s/『G4610』/Silas\/Silvanus/g
s/『G4611』/Siloam/g
s/『G4612』/apron/g
s/『G4613』/Simon/g
s/『G4614』/Sinai/g
s/『G4615』/mustard/g
s/『G4616』/linen/g
s/『G4617』/to sift/g
s/『G4618』/fattened/g
s/『G4619』/fattened/g
s/『G4620』/grain ration/g
s/『G4621』/grain/g
s/『G4622』/Zion/g
s/『G4623』/be quiet/g
s/『G4624』/to cause to stumble/g
s/『G4625』/stumbling block/g
s/『G4626』/to dig/g
s/『G4627』/lifeboat/g
s/『G4628』/leg/g
s/『G4629』/clothing/g
s/『G4630』/Sceva/g
s/『G4631』/gear/g
s/『G4632』/vessel/g
s/『G4633』/tent/g
s/『G4634』/Feast of Booths/g
s/『G4635』/tentmaker/g
s/『G4636』/tent/g
s/『G4637』/to dwell/g
s/『G4638』/tent/g
s/『G4639』/shadow/g
s/『G4640』/to leap/g
s/『G4641』/hardness of heart/g
s/『G4642』/hard/g
s/『G4643』/hardness/g
s/『G4644』/stiff-necked/g
s/『G4645』/to harden/g
s/『G4646』/crooked/g
s/『G4647』/thorn/g
s/『G4648』/to watch out/g
s/『G4649』/goal/g
s/『G4650』/to scatter/g
s/『G4651』/scorpion/g
s/『G4652』/dark/g
s/『G4653』/darkness/g
s/『G4654』/to darken/g
s/『G4655』/darkness/g
s/『G4656』/to darken/g
s/『G4657』/garbage/g
s/『G4658』/Scythian/g
s/『G4659』/be sad/g
s/『G4660』/to trouble/g
s/『G4661』/plunder/g
s/『G4662』/worm-eated/g
s/『G4663』/worm/g
s/『G4664』/emerald/g
s/『G4665』/emerald/g
s/『G4666』/myrrh/g
s/『G4667』/Smyrna/g
s/『G4668』/Smyrnaean/g
s/『G4669』/to mix with myrrh/g
s/『G4670』/Sodom/g
s/『G4671』/you/g
s/『G4672』/Solomon/g
s/『G4673』/bier/g
s/『G4674』/your/g
s/『G4675』/you/g
s/『G4676』/handkerchief/g
s/『G4677』/Susanna/g
s/『G4678』/wisdom/g
s/『G4679』/to make wise/g
s/『G4680』/wise/g
s/『G4681』/Spain/g
s/『G4682』/to convulse/g
s/『G4683』/to wrap/g
s/『G4684』/to indulge/g
s/『G4685』/to draw/g
s/『G4686』/band/g
s/『G4687』/to sow/g
s/『G4688』/executioner/g
s/『G4689』/to pour a libation/g
s/『G4690』/seed/g
s/『G4691』/babbler/g
s/『G4692』/to hasten/g
s/『G4693』/cave/g
s/『G4694』/reef/g
s/『G4695』/to stain/g
s/『G4696』/stain/g
s/『G4697』/to pity/g
s/『G4698』/affection\/entrails/g
s/『G4699』/sponge/g
s/『G4700』/ashes/g
s/『G4701』/seed/g
s/『G4702』/grainfield/g
s/『G4703』/seed/g
s/『G4704』/be eager/g
s/『G4705』/eager/g
s/『G4706』/more diligently/g
s/『G4707』/more diligent/g
s/『G4708』/more eagerly/g
s/『G4709』/diligently/g
s/『G4710』/diligence/g
s/『G4711』/basket/g
s/『G4712』/stadium/g
s/『G4713』/jar/g
s/『G4714』/uprising/g
s/『G4715』/coin/g
s/『G4716』/cross/g
s/『G4717』/to crucify/g
s/『G4718』/grapes/g
s/『G4719』/head of grain/g
s/『G4720』/Stachys/g
s/『G4721』/roof/g
s/『G4722』/to endure/g
s/『G4723』/infertility/g
s/『G4724』/to avoid/g
s/『G4725』/wreath/g
s/『G4726』/groan/g
s/『G4727』/to groan/g
s/『G4728』/narrow/g
s/『G4729』/to press upon/g
s/『G4730』/hardship/g
s/『G4731』/strong/g
s/『G4732』/to strengthen/g
s/『G4733』/firmness/g
s/『G4734』/Stephanas/g
s/『G4735』/crown/g
s/『G4736』/Stephen/g
s/『G4737』/to crown/g
s/『G4738』/chest/g
s/『G4739』/to stand/g
s/『G4740』/security/g
s/『G4741』/to establish/g
s/『G4742』/mark/g
s/『G4743』/instant/g
s/『G4744』/to dazzle/g
s/『G4745』/portico/g
s/『G4746』/leafy branch/g
s/『G4747』/principle/g
s/『G4748』/to follow/g
s/『G4749』/robe/g
s/『G4750』/mouth/g
s/『G4751』/stomach/g
s/『G4752』/warfare/g
s/『G4753』/troops/g
s/『G4754』/to battle/g
s/『G4755』/officer\/magistrate/g
s/『G4756』/army/g
s/『G4757』/soldier/g
s/『G4758』/to enlist/g
s/『G4759』/commander/g
s/『G4760』/army camp/g
s/『G4761』/to distort/g
s/『G4762』/to turn/g
s/『G4763』/to revel/g
s/『G4764』/luxury/g
s/『G4765』/sparrow/g
s/『G4766』/to spread/g
s/『G4767』/hated/g
s/『G4768』/be gloomy/g
s/『G4769』/pillar/g
s/『G4770』/Stoic/g
s/『G4771』/you/g
s/『G4772』/kindred/g
s/『G4773』/kindred/g
s/『G4774』/concession/g
s/『G4775』/to sit with/g
s/『G4776』/to sit down with/g
s/『G4777』/to suffer with/g
s/『G4778』/to suffer with/g
s/『G4779』/to call together/g
s/『G4780』/to conceal/g
s/『G4781』/to bend/g
s/『G4782』/to descend with/g
s/『G4783』/agreement/g
s/『G4784』/to consent/g
s/『G4785』/to numbered with/g
s/『G4786』/to unite/g
s/『G4787』/to stir up/g
s/『G4788』/to confine/g
s/『G4789』/co-heir/g
s/『G4790』/to share with/g
s/『G4791』/sharer/g
s/『G4792』/to entomb/g
s/『G4793』/to compare/g
s/『G4794』/to bend/g
s/『G4795』/coincidence/g
s/『G4796』/to rejoice with/g
s/『G4797』/to confound/g
s/『G4798』/to associate with/g
s/『G4799』/confusion/g
s/『G4800』/to live together/g
s/『G4801』/to join/g
s/『G4802』/to debate/g
s/『G4803』/discussion/g
s/『G4804』/debater/g
s/『G4805』/yokefellow/g
s/『G4806』/to make alive with/g
s/『G4807』/mulberry tree/g
s/『G4808』/fig tree/g
s/『G4809』/sycamore tree/g
s/『G4810』/fig/g
s/『G4811』/to extort/g
s/『G4812』/to capture/g
s/『G4813』/to rob/g
s/『G4814』/to talk with/g
s/『G4815』/to seize\/conceive\/help/g
s/『G4816』/to collect/g
s/『G4817』/to discuss/g
s/『G4818』/be grieved/g
s/『G4819』/to happen/g
s/『G4820』/to ponder\/confer/g
s/『G4821』/to reign with/g
s/『G4822』/to join with/g
s/『G4823』/to consult/g
s/『G4824』/counsel\/council/g
s/『G4825』/counselor/g
s/『G4826』/Simeon/g
s/『G4827』/fellow disciple/g
s/『G4828』/to testify with/g
s/『G4829』/to share/g
s/『G4830』/sharer/g
s/『G4831』/co-imitator/g
s/『G4832』/conformed/g
s/『G4833』/to make like/g
s/『G4834』/to sympathize/g
s/『G4835』/sympathetic/g
s/『G4836』/to assemble/g
s/『G4837』/to encourage/g
s/『G4838』/to take along with/g
s/『G4839』/to continue/g
s/『G4840』/be present with/g
s/『G4841』/to suffer with/g
s/『G4842』/to send with/g
s/『G4843』/to embrace/g
s/『G4844』/to drink with/g
s/『G4845』/to \(ful\)fill/g
s/『G4846』/to choke/g
s/『G4847』/fellow citizen/g
s/『G4848』/to go with/g
s/『G4849』/common meal/g
s/『G4850』/fellow elder/g
s/『G4851』/to be profitable/g
s/『G4852』/to agree/g
s/『G4853』/fellow countryman/g
s/『G4854』/united/g
s/『G4855』/to grow with/g
s/『G4856』/to agree with/g
s/『G4857』/harmony/g
s/『G4858』/music/g
s/『G4859』/mutual consent/g
s/『G4860』/to calculate/g
s/『G4861』/harmonious/g
s/『G4862』/with/g
s/『G4863』/to assemble/g
s/『G4864』/synagogue/g
s/『G4865』/to struggle/g
s/『G4866』/to contend/g
s/『G4867』/to assemble/g
s/『G4868』/to settle accounts/g
s/『G4869』/fellow prisoner/g
s/『G4870』/to accompany/g
s/『G4871』/to assemble/g
s/『G4872』/to ascend with/g
s/『G4873』/to dine with/g
s/『G4874』/to associate with/g
s/『G4875』/to rest with/g
s/『G4876』/to meet/g
s/『G4877』/meeting/g
s/『G4878』/to help/g
s/『G4879』/to lead away with/g
s/『G4880』/to die with/g
s/『G4881』/to die\/destroy with/g
s/『G4882』/to send with/g
s/『G4883』/to join/g
s/『G4884』/to seize/g
s/『G4885』/to grow together/g
s/『G4886』/bond\(age\)/g
s/『G4887』/to bind with/g
s/『G4888』/to glory with/g
s/『G4889』/fellow slave/g
s/『G4890』/swarming/g
s/『G4891』/to raise up with/g
s/『G4892』/council/g
s/『G4893』/conscience/g
s/『G4894』/be aware/g
s/『G4895』/be with/g
s/『G4896』/to gather/g
s/『G4897』/to enter with/g
s/『G4898』/companion/g
s/『G4899』/chosen with/g
s/『G4900』/to urge/g
s/『G4901』/to testify with/g
s/『G4902』/to accompany/g
s/『G4903』/to work with/g
s/『G4904』/co-worker/g
s/『G4905』/to assemble/g
s/『G4906』/to eat with/g
s/『G4907』/understanding/g
s/『G4908』/intelligent/g
s/『G4909』/to agree to/g
s/『G4910』/to feast with/g
s/『G4911』/to attack/g
s/『G4912』/to hold\/oppress/g
s/『G4913』/to delight/g
s/『G4914』/custom/g
s/『G4915』/contemporary/g
s/『G4916』/be buried with/g
s/『G4917』/to shatter/g
s/『G4918』/to push against/g
s/『G4919』/to break/g
s/『G4920』/to understand/g
s/『G4921』/to commend/g
s/『G4922』/to travel with/g
s/『G4923』/caravan/g
s/『G4924』/to live with/g
s/『G4925』/to built up with/g
s/『G4926』/to converse/g
s/『G4927』/be next to/g
s/『G4928』/anguish/g
s/『G4929』/to direct/g
s/『G4930』/consummation/g
s/『G4931』/to complete/g
s/『G4932』/to cut short/g
s/『G4933』/to preserve/g
s/『G4934』/to agree/g
s/『G4935』/concisely/g
s/『G4936』/to flock/g
s/『G4937』/to break/g
s/『G4938』/ruin/g
s/『G4939』/brought up with/g
s/『G4940』/to meet with/g
s/『G4941』/Syntyche/g
s/『G4942』/to join hypocrisy/g
s/『G4943』/to join in helping/g
s/『G4944』/to labor together/g
s/『G4945』/plot/g
s/『G4946』/Syracuse/g
s/『G4947』/Syria/g
s/『G4948』/Syrian/g
s/『G4949』/Syrophoenician/g
s/『G4950』/Syrtis/g
s/『G4951』/to drag/g
s/『G4952』/to convulse/g
s/『G4953』/an agreed signal/g
s/『G4954』/of the same body/g
s/『G4955』/insurrectionist/g
s/『G4956』/recommended/g
s/『G4957』/to crucify with/g
s/『G4958』/to wrap up/g
s/『G4959』/to groan with/g
s/『G4960』/to correspond to/g
s/『G4961』/fellow soldier/g
s/『G4962』/to gather/g
s/『G4963』/commotion\/plot/g
s/『G4964』/to conform to/g
s/『G4965』/Sychar/g
s/『G4966』/Shechem/g
s/『G4967』/slaughter/g
s/『G4968』/sacrificial victim/g
s/『G4969』/to slaughter/g
s/『G4970』/very/g
s/『G4971』/violently/g
s/『G4972』/to seal/g
s/『G4973』/seal/g
s/『G4974』/ankle/g
s/『G4975』/nearly/g
s/『G4976』/form/g
s/『G4977』/to split/g
s/『G4978』/split/g
s/『G4979』/rope/g
s/『G4980』/be devoted\/empty/g
s/『G4981』/lecture hall/g
s/『G4982』/to save/g
s/『G4983』/body/g
s/『G4984』/bodily/g
s/『G4985』/bodily/g
s/『G4986』/Sopater/g
s/『G4987』/to pile up/g
s/『G4988』/Sosthenes/g
s/『G4989』/Sosipater/g
s/『G4990』/savior/g
s/『G4991』/salvation/g
s/『G4992』/saving/g
s/『G4993』/be of sound mind/g
s/『G4994』/to train/g
s/『G4995』/self-discipline/g
s/『G4996』/in self-control/g
s/『G4997』/mental soundness/g
s/『G4998』/self-controlled/g
s/『G4999』/tavern/g
s/『G5000』/Tabitha/g
s/『G5001』/order/g
s/『G5002』/appointed/g
s/『G5003』/to grieve/g
s/『G5004』/misery/g
s/『G5005』/wretched/g
s/『G5006』/weighing a talent/g
s/『G5007』/talent/g
s/『G5008』/girl/g
s/『G5009』/inner room/g
s/『G5010』/order/g
s/『G5011』/lowly/g
s/『G5012』/humility/g
s/『G5013』/to humble/g
s/『G5014』/lowliness/g
s/『G5015』/to trouble/g
s/『G5016』/disturbance/g
s/『G5017』/disturbance/g
s/『G5018』/of Tarsus/g
s/『G5019』/Tarsus/g
s/『G5020』/to condemn/g
s/『G5021』/to appoint/g
s/『G5022』/bull/g
s/『G5023』/this/g
s/『G5024』/thus/g
s/『G5025』/hence/g
s/『G5026』/her/g
s/『G5027』/burial \(place\)/g
s/『G5028』/grave/g
s/『G5029』/perhaps/g
s/『G5030』/quickly/g
s/『G5031』/quick/g
s/『G5032』/more quickly/g
s/『G5033』/most quickly/g
s/『G5034』/quickness/g
s/『G5035』/quickly/g
s/『G5036』/quick/g
s/『G5037』/and\/both/g
s/『G5038』/wall/g
s/『G5039』/clear proof/g
s/『G5040』/children/g
s/『G5041』/to have children/g
s/『G5042』/childbearing/g
s/『G5043』/child/g
s/『G5044』/to raise children/g
s/『G5045』/craftsman/g
s/『G5046』/perfect/g
s/『G5047』/perfection/g
s/『G5048』/to perfect/g
s/『G5049』/completely/g
s/『G5050』/perfection/g
s/『G5051』/finisher/g
s/『G5052』/to mature/g
s/『G5053』/to die/g
s/『G5054』/death/g
s/『G5055』/to finish/g
s/『G5056』/goal\/tax/g
s/『G5057』/tax collector/g
s/『G5058』/tax booth/g
s/『G5059』/wonders/g
s/『G5060』/Tertius/g
s/『G5061』/Tertullus/g
s/『G5062』/forty/g
s/『G5063』/forty years/g
s/『G5064』/four/g
s/『G5065』/fourteenth/g
s/『G5066』/fourth/g
s/『G5067』/fourth/g
s/『G5068』/square/g
s/『G5069』/squad of four/g
s/『G5070』/four thousand/g
s/『G5071』/four hundred/g
s/『G5072』/four months/g
s/『G5073』/fourfold/g
s/『G5074』/four-footed/g
s/『G5075』/be a tetrarch/g
s/『G5076』/tetrarch/g
s/『G5077』/to turn to ashes/g
s/『G5078』/skill/g
s/『G5079』/craftsman/g
s/『G5080』/to melt/g
s/『G5081』/clearly/g
s/『G5082』/so great/g
s/『G5083』/to keep/g
s/『G5084』/jail\/keeping/g
s/『G5085』/Tiberias/g
s/『G5086』/Tiberius/g
s/『G5087』/to place/g
s/『G5088』/to give birth to/g
s/『G5089』/to pluck/g
s/『G5090』/Timaeus/g
s/『G5091』/to honor/g
s/『G5092』/honor/g
s/『G5093』/precious/g
s/『G5094』/wealth/g
s/『G5095』/Timothy/g
s/『G5096』/Timon/g
s/『G5097』/to punish/g
s/『G5098』/punishment/g
s/『G5099』/to pay/g
s/『G5100』/one/g
s/『G5101』/which?/g
s/『G5102』/title/g
s/『G5103』/Titus/g
s/『G5104』/certainly/g
s/『G5105』/therefore/g
s/『G5106』/then/g
s/『G5107』/such as this/g
s/『G5108』/such as this/g
s/『G5109』/wall/g
s/『G5110』/interest/g
s/『G5111』/be bold/g
s/『G5112』/more boldly/g
s/『G5113』/bold man/g
s/『G5114』/sharper/g
s/『G5115』/bow/g
s/『G5116』/topaz/g
s/『G5117』/place/g
s/『G5118』/so great/g
s/『G5119』/then/g
s/『G5120』/his/g
s/『G5121』/instead/g
s/『G5122』/by name/g
s/『G5123』/that is/g
s/『G5124』/that/g
s/『G5125』/to these/g
s/『G5126』/this/g
s/『G5127』/of this/g
s/『G5128』/these/g
s/『G5129』/to this/g
s/『G5130』/of these/g
s/『G5131』/he-goat/g
s/『G5132』/table/g
s/『G5133』/money lender/g
s/『G5134』/wound/g
s/『G5135』/to wound/g
s/『G5136』/to lay bare/g
s/『G5137』/neck/g
s/『G5138』/rough/g
s/『G5139』/Traconitis/g
s/『G5140』/three/g
s/『G5141』/to tremble/g
s/『G5142』/to feed/g
s/『G5143』/to run/g
s/『G5144』/thirty/g
s/『G5145』/three hundred/g
s/『G5146』/thistle/g
s/『G5147』/path/g
s/『G5148』/three years/g
s/『G5149』/to gnash/g
s/『G5150』/three months/g
s/『G5151』/three times/g
s/『G5152』/third story/g
s/『G5153』/three thousand/g
s/『G5154』/third/g
s/『G5155』/of hair/g
s/『G5156』/trembling/g
s/『G5157』/turning/g
s/『G5158』/way/g
s/『G5159』/to put up with/g
s/『G5160』/food/g
s/『G5161』/Trophimus/g
s/『G5162』/nursing mother/g
s/『G5163』/track/g
s/『G5164』/course\/wheel/g
s/『G5165』/bowl/g
s/『G5166』/to harvest/g
s/『G5167』/dove/g
s/『G5168』/hole/g
s/『G5169』/hole/g
s/『G5170』/Tryphena/g
s/『G5171』/to self-indulge/g
s/『G5172』/self-indulgence/g
s/『G5173』/Tryphosa/g
s/『G5174』/Troas/g
s/『G5175』/Trogyllium/g
s/『G5176』/to eat/g
s/『G5177』/to obtain\/happen/g
s/『G5178』/to torture/g
s/『G5179』/mark\/example/g
s/『G5180』/to strike/g
s/『G5181』/Tyrannus/g
s/『G5182』/to upset/g
s/『G5183』/Tyrian/g
s/『G5184』/Tyre/g
s/『G5185』/blind/g
s/『G5186』/to blind/g
s/『G5187』/be conceited/g
s/『G5188』/to smoulder/g
s/『G5189』/tempestuous/g
s/『G5190』/Tychicus/g
s/『G5191』/dark blue/g
s/『G5192』/hyacinth/g
s/『G5193』/glass/g
s/『G5194』/glass/g
s/『G5195』/to mistreat/g
s/『G5196』/mistreatment/g
s/『G5197』/insolent man/g
s/『G5198』/be healthy/g
s/『G5199』/healthy/g
s/『G5200』/moist\/green/g
s/『G5201』/jar/g
s/『G5202』/to drink water/g
s/『G5203』/with dropsy/g
s/『G5204』/water/g
s/『G5205』/rain/g
s/『G5206』/adoption \(as son\)/g
s/『G5207』/son/g
s/『G5208』/forest/g
s/『G5209』/you/g
s/『G5210』/you/g
s/『G5211』/Hymenaeus/g
s/『G5212』/your/g
s/『G5213』/to you/g
s/『G5214』/to praise/g
s/『G5215』/hymn/g
s/『G5216』/of you/g
s/『G5217』/to go/g
s/『G5218』/obedience/g
s/『G5219』/to obey/g
s/『G5220』/married/g
s/『G5221』/to go meet/g
s/『G5222』/meeting/g
s/『G5223』/property/g
s/『G5224』/possession/g
s/『G5225』/to be/g
s/『G5226』/to submit/g
s/『G5227』/opposed/g
s/『G5228』/above\/for/g
s/『G5229』/be haughty/g
s/『G5230』/past one’s prime/g
s/『G5231』/above/g
s/『G5232』/to increase/g
s/『G5233』/to wrong/g
s/『G5234』/severely/g
s/『G5235』/to surpass/g
s/『G5236』/surpassing/g
s/『G5237』/to overlook/g
s/『G5238』/beyond/g
s/『G5239』/to overextend/g
s/『G5240』/to overflow/g
s/『G5241』/to intercede/g
s/『G5242』/be higher/g
s/『G5243』/pride/g
s/『G5244』/arrogant/g
s/『G5245』/to conquer/g
s/『G5246』/boastful/g
s/『G5247』/authority/g
s/『G5248』/to abound/g
s/『G5249』/exceedingly/g
s/『G5250』/to abound/g
s/『G5251』/to exalt/g
s/『G5252』/be haughty/g
s/『G5253』/upper room/g
s/『G5254』/to undergo/g
s/『G5255』/obedient/g
s/『G5256』/to serve/g
s/『G5257』/servant/g
s/『G5258』/sleep/g
s/『G5259』/by\/under/g
s/『G5260』/to instigate/g
s/『G5261』/example/g
s/『G5262』/example/g
s/『G5263』/to show/g
s/『G5264』/to receive/g
s/『G5265』/to put on/g
s/『G5266』/sandal/g
s/『G5267』/accountable/g
s/『G5268』/donkey/g
s/『G5269』/to undergird/g
s/『G5270』/under/g
s/『G5271』/to pretend/g
s/『G5272』/hypocrisy/g
s/『G5273』/hypocrite/g
s/『G5274』/to take up\/suppose/g
s/『G5275』/to leave/g
s/『G5276』/trough/g
s/『G5277』/to leave behind/g
s/『G5278』/to remain\/endure/g
s/『G5279』/to remind/g
s/『G5280』/remembrance/g
s/『G5281』/perseverance/g
s/『G5282』/to suppose/g
s/『G5283』/suspicion/g
s/『G5284』/to sail the lee/g
s/『G5285』/to blow gently/g
s/『G5286』/footstool/g
s/『G5287』/confidence\/essence/g
s/『G5288』/to withdraw/g
s/『G5289』/shrinking/g
s/『G5290』/to return/g
s/『G5291』/to spread/g
s/『G5292』/submission/g
s/『G5293』/to subject/g
s/『G5294』/to risk\/teach/g
s/『G5295』/to sail under/g
s/『G5296』/example/g
s/『G5297』/to endure/g
s/『G5298』/to withdraw/g
s/『G5299』/to wear out/g
s/『G5300』/sow/g
s/『G5301』/hyssop/g
s/『G5302』/to lack/g
s/『G5303』/deficiency/g
s/『G5304』/poverty/g
s/『G5305』/later/g
s/『G5306』/later/g
s/『G5307』/woven/g
s/『G5308』/high/g
s/『G5309』/be arrogant/g
s/『G5310』/highest/g
s/『G5311』/height/g
s/『G5312』/to lift up/g
s/『G5313』/height/g
s/『G5314』/glutton/g
s/『G5315』/to eat/g
s/『G5316』/to shine\/appear/g
s/『G5317』/Peleg/g
s/『G5318』/manifest/g
s/『G5319』/to manifest/g
s/『G5320』/plainly/g
s/『G5321』/manifestation/g
s/『G5322』/torch/g
s/『G5323』/Phanuel/g
s/『G5324』/to make visible/g
s/『G5325』/pageantry/g
s/『G5326』/ghost/g
s/『G5327』/valley/g
s/『G5328』/Pharaoh/g
s/『G5329』/Perez/g
s/『G5330』/Pharisee/g
s/『G5331』/sorcery/g
s/『G5332』/sorcerer/g
s/『G5333』/sorcerer/g
s/『G5334』/news/g
s/『G5335』/to claim/g
s/『G5336』/manger/g
s/『G5337』/evil/g
s/『G5338』/light/g
s/『G5339』/to spare/g
s/『G5340』/sparingly/g
s/『G5341』/cloak/g
s/『G5342』/to bear\/lead/g
s/『G5343』/to flee/g
s/『G5344』/Felix/g
s/『G5345』/news/g
s/『G5346』/to say/g
s/『G5347』/Festus/g
s/『G5348』/to precede\/arrive/g
s/『G5349』/perishable/g
s/『G5350』/to speak/g
s/『G5351』/to destroy/g
s/『G5352』/autumnal/g
s/『G5353』/sound/g
s/『G5354』/to envy/g
s/『G5355』/envy/g
s/『G5356』/corruption/g
s/『G5357』/bowl/g
s/『G5358』/lover of good/g
s/『G5359』/Philadelphia/g
s/『G5360』/brotherly love/g
s/『G5361』/loving the brothers/g
s/『G5362』/husband-loving/g
s/『G5363』/benevolence/g
s/『G5364』/benevolently/g
s/『G5365』/love of money/g
s/『G5366』/money-loving/g
s/『G5367』/selfish/g
s/『G5368』/to love/g
s/『G5369』/pleasure-loving/g
s/『G5370』/kiss/g
s/『G5371』/Philemon/g
s/『G5372』/Philetus/g
s/『G5373』/friendship/g
s/『G5374』/Philippian/g
s/『G5375』/Philippi/g
s/『G5376』/Philip/g
s/『G5377』/God-loving/g
s/『G5378』/Philologus/g
s/『G5379』/love of dispute/g
s/『G5380』/dispute-loving/g
s/『G5381』/hospitality/g
s/『G5382』/hospitable/g
s/『G5383』/to love to be first/g
s/『G5384』/friendly\/friend/g
s/『G5385』/philosophy/g
s/『G5386』/philosopher/g
s/『G5387』/devoted/g
s/『G5388』/parental love/g
s/『G5389』/to aspire/g
s/『G5390』/hospitably/g
s/『G5391』/friendly/g
s/『G5392』/to muzzle/g
s/『G5393』/Phlegon/g
s/『G5394』/to kindle/g
s/『G5395』/flame/g
s/『G5396』/to talk nonsense/g
s/『G5397』/gossipy/g
s/『G5398』/fearful/g
s/『G5399』/to fear/g
s/『G5400』/fearful thing/g
s/『G5401』/fear/g
s/『G5402』/Phoebe/g
s/『G5403』/Phoenicia/g
s/『G5404』/palm/g
s/『G5405』/Phenice/g
s/『G5406』/murderer/g
s/『G5407』/to murder/g
s/『G5408』/murder/g
s/『G5409』/to wear/g
s/『G5410』/forum/g
s/『G5411』/tax/g
s/『G5412』/to burden/g
s/『G5413』/burden/g
s/『G5414』/cargo/g
s/『G5415』/Fortunatus/g
s/『G5416』/whip/g
s/『G5417』/to whip/g
s/『G5418』/fence/g
s/『G5419』/to explain/g
s/『G5420』/to stop/g
s/『G5421』/well\/abyss/g
s/『G5422』/to deceive/g
s/『G5423』/deceiver/g
s/『G5424』/thinking/g
s/『G5425』/to shudder/g
s/『G5426』/to think/g
s/『G5427』/mind/g
s/『G5428』/understanding/g
s/『G5429』/thoughtful/g
s/『G5430』/shrewdly/g
s/『G5431』/be careful/g
s/『G5432』/to guard/g
s/『G5433』/to rage/g
s/『G5434』/brushwood/g
s/『G5435』/Phrygia/g
s/『G5436』/Phygelus/g
s/『G5437』/flight/g
s/『G5438』/prison\/watch/g
s/『G5439』/to imprison/g
s/『G5440』/phylactery/g
s/『G5441』/guard/g
s/『G5442』/to keep\/guard/g
s/『G5443』/tribe/g
s/『G5444』/leaf/g
s/『G5445』/lump/g
s/『G5446』/natural/g
s/『G5447』/physically/g
s/『G5448』/to inflate/g
s/『G5449』/nature/g
s/『G5450』/arrogance/g
s/『G5451』/plant/g
s/『G5452』/to plant/g
s/『G5453』/to grow/g
s/『G5454』/den/g
s/『G5455』/to call/g
s/『G5456』/voice\/sound/g
s/『G5457』/light/g
s/『G5458』/light/g
s/『G5459』/light-bearing/g
s/『G5460』/bright/g
s/『G5461』/to illuminate/g
s/『G5462』/light/g
s/『G5463』/to rejoice/g
s/『G5464』/hail/g
s/『G5465』/to lower/g
s/『G5466』/Chaldean/g
s/『G5467』/harsh/g
s/『G5468』/to bridle/g
s/『G5469』/bridle/g
s/『G5470』/bronze/g
s/『G5471』/coppersmith/g
s/『G5472』/chalcedony/g
s/『G5473』/kettle/g
s/『G5474』/bronze/g
s/『G5475』/copper\/bronze\/coin/g
s/『G5476』/on the ground/g
s/『G5477』/Canaan/g
s/『G5478』/Canaanite/g
s/『G5479』/joy/g
s/『G5480』/image\/mark/g
s/『G5481』/reproduction/g
s/『G5482』/barricade/g
s/『G5483』/to give grace/g
s/『G5484』/therefore/g
s/『G5485』/grace/g
s/『G5486』/gift/g
s/『G5487』/to favor/g
s/『G5488』/Haran/g
s/『G5489』/paper/g
s/『G5490』/chasm/g
s/『G5491』/lip/g
s/『G5492』/be storm-tossed/g
s/『G5493』/brook/g
s/『G5494』/winter/g
s/『G5495』/hand/g
s/『G5496』/to lead by the hand/g
s/『G5497』/hand-leader/g
s/『G5498』/writen record/g
s/『G5499』/hand-made/g
s/『G5500』/to appoint/g
s/『G5501』/worse than/g
s/『G5502』/Cherub/g
s/『G5503』/widow/g
s/『G5504』/yesterday/g
s/『G5505』/thousand/g
s/『G5506』/military officer/g
s/『G5507』/thousand/g
s/『G5508』/Chios/g
s/『G5509』/tunic/g
s/『G5510』/snow/g
s/『G5511』/robe/g
s/『G5512』/to sneer/g
s/『G5513』/lukewarm/g
s/『G5514』/Chloe/g
s/『G5515』/green/g
s/『G5516』/666/g
s/『G5517』/made of dust/g
s/『G5518』/quart/g
s/『G5519』/pig/g
s/『G5520』/be angry/g
s/『G5521』/gall/g
s/『G5522』/dust/g
s/『G5523』/Chorazin/g
s/『G5524』/to provide/g
s/『G5525』/a dance/g
s/『G5526』/to feed/g
s/『G5527』/food/g
s/『G5528』/grass/g
s/『G5529』/Chuza/g
s/『G5530』/to use/g
s/『G5531』/to lend/g
s/『G5532』/need/g
s/『G5533』/debtor/g
s/『G5534』/it should be/g
s/『G5535』/to need/g
s/『G5536』/money/g
s/『G5537』/to announce/g
s/『G5538』/proclamation/g
s/『G5539』/profitable/g
s/『G5540』/relations/g
s/『G5541』/be kind/g
s/『G5542』/smooth talk/g
s/『G5543』/good\/kind/g
s/『G5544』/kindness/g
s/『G5545』/anointing/g
s/『G5546』/Christian/g
s/『G5547』/Christ/g
s/『G5548』/to anoint/g
s/『G5549』/to delay/g
s/『G5550』/time/g
s/『G5551』/to spend time/g
s/『G5552』/golden/g
s/『G5553』/gold/g
s/『G5554』/gold-ringed/g
s/『G5555』/chrysolite/g
s/『G5556』/chrysoprase/g
s/『G5557』/gold/g
s/『G5558』/to gild/g
s/『G5559』/skin/g
s/『G5560』/lame/g
s/『G5561』/country/g
s/『G5562』/to make room for/g
s/『G5563』/to separate\/leave/g
s/『G5564』/place/g
s/『G5565』/without/g
s/『G5566』/northwest/g
s/『G5567』/to sing praise/g
s/『G5568』/psalm/g
s/『G5569』/false brother/g
s/『G5570』/false apostle/g
s/『G5571』/false/g
s/『G5572』/false teacher/g
s/『G5573』/lying/g
s/『G5574』/to lie/g
s/『G5575』/false witness/g
s/『G5576』/to perjure/g
s/『G5577』/false testimony/g
s/『G5578』/false prophet/g
s/『G5579』/lie/g
s/『G5580』/false Christ/g
s/『G5581』/falsely called/g
s/『G5582』/falsehood/g
s/『G5583』/liar/g
s/『G5584』/to touch/g
s/『G5585』/to calculate/g
s/『G5586』/stone\/vote/g
s/『G5587』/gossip/g
s/『G5588』/gossip/g
s/『G5589』/crumb/g
s/『G5590』/soul/g
s/『G5591』/natural/g
s/『G5592』/cold/g
s/『G5593』/cold/g
s/『G5594』/to cool/g
s/『G5595』/to feed\/dole out/g
s/『G5596』/piece/g
s/『G5597』/to rub/g
s/『G5598』/Omega/g
s/『G5599』/oh!/g
s/『G5600』/may be/g
s/『G5601』/Obed/g
s/『G5602』/here/g
s/『G5603』/song/g
s/『G5604』/labor/g
s/『G5605』/be in labor/g
s/『G5606』/shoulder/g
s/『G5607』/being/g
s/『G5608』/to buy/g
s/『G5609』/an egg/g
s/『G5610』/hour/g
s/『G5611』/beautiful\/timely/g
s/『G5612』/to roar/g
s/『G5613』/which\/how/g
s/『G5614』/Hosanna!/g
s/『G5615』/likewise/g
s/『G5616』/like\/as\/about/g
s/『G5617』/Hosea/g
s/『G5618』/just as/g
s/『G5619』/just as if/g
s/『G5620』/so/g
s/『G5621』/ear/g
s/『G5622』/advantage/g
s/『G5623』/to help/g
s/『G5624』/valuable/g
s/『G6000』/to announce/g
s/『G6001』/vessel/g
s/『G6002』/Adminan/g
s/『G6003』/to assemble/g
s/『G6004』/elsewhere/g
s/『G6005』/to clothe/g
s/『G6006』/to cast/g
s/『G6007』/amomum/g
s/『G6008』/to jump up/g
s/『G6011』/needle/g
s/『G6013』/product/g
s/『G6014』/eighteen/g
s/『G6015』/fear/g
s/『G6016』/to scour/g
s/『G6017』/to deride/g
s/『G6018』/to ponder/g
s/『G6019』/two-myriad/g
s/『G6020』/examination/g
s/『G6022』/to slander/g
s/『G6023』/be discouraged/g
s/『G6025』/because/g
s/『G6027』/speculation/g
s/『G6028』/be amazed/g
s/『G6029』/exceedingly/g
s/『G6030』/to rush out/g
s/『G6031』/rebuke/g
s/『G6032』/derision/g
s/『G6033』/hence/g
s/『G6034』/to adjure/g
s/『G6035』/accursed/g
s/『G6036』/to enter/g
s/『G6037』/to sow above/g
s/『G6039』/cheerfully/g
s/『G6041』/to envy/g
s/『G6043』/Joda/g
s/『G6044』/Josech/g
s/『G6045』/as/g
s/『G6046』/to burden/g
s/『G6047』/to delineate/g
s/『G6048』/judgment/g
s/『G6049』/to stoop/g
s/『G6050』/to bless/g
s/『G6051』/an accuser/g
s/『G6052』/to settle/g
s/『G6053』/lower/g
s/『G6055』/a cot/g
s/『G6058』/hidden/g
s/『G6059』/encompass/g
s/『G6060』/to turn around/g
s/『G6061』/mill/g
s/『G6063』/to know/g
s/『G6064』/household/g
s/『G6065』/builder/g
s/『G6066』/little faith/g
s/『G6067』/scarcely/g
s/『G6068』/fog/g
s/『G6069』/everywhere/g
s/『G6070』/to encamp/g
s/『G6071』/further/g
s/『G6072』/to kindle/g
s/『G6073』/gentleness/g
s/『G6074』/ancestor/g
s/『G6075』/a beggar/g
s/『G6076』/to lean toward/g
s/『G6077』/Pyrrhus/g
s/『G6078』/originally/g
s/『G6079』/food/g
s/『G6080』/relative/g
s/『G6081』/be downcast/g
s/『G6083』/to be conscious of/g
s/『G6084』/Titius/g
s/『G6085』/hole/g
s/『G6087』/superabundantly/g
s/『G6088』/greatly/g
s/『G6090』/ear/g
s/『G6091』/sunset/g
s/『G6092』/to_step_out/g
s/『G6093』/pit/g
s/『G6094』/to_boast/g
s/『G6095』/Arni/g
s/『G6096』/satisfy/g
s/『G6097』/break/g
s/『G6098』/burnt/g
s/『G6099』/to comb/g
s/『G6100』/independent/g
s/『G6101』/impassable/g
s/『G6102』/to make impassable/g
s/『G6103』/incurable/g
s/『G6104』/thoughtlessness/g
s/『G6105』/handmaiden/g
s/『G6106』/drought/g
s/『G6107』/to do good/g
s/『G6108』/be better/g
s/『G6109』/fine/g
s/『G6110』/a leap for joy/g
s/『G6111』/a statue/g
s/『G6112』/cups/g
s/『G6113』/affection/g
s/『G6114』/sanctification/g
s/『G6115』/sanctuary/g
s/『G6116』/an arm/g
s/『G6117』/a loop/g
s/『G6118』/an angle/g
s/『G6119』/a joint/g
s/『G6120』/purification/g
s/『G6121』/a chaste tree/g
s/『G6122』/barren/g
s/『G6123』/a purchase/g
s/『G6124』/be wild/g
s/『G6125』/holm oak/g
s/『G6126』/tamarisk/g
s/『G6127』/rugged/g
s/『G6128』/wild grass/g
s/『G6129』/right of inheritance/g
s/『G6130』/a relative/g
s/『G6131』/to act as next of kin/g
s/『G6132』/to squeeze/g
s/『G6133』/adamantine/g
s/『G6134』/adamant/g
s/『G6135』/adar/g
s/『G6136』/supperless/g
s/『G6137』/a kinsman/g
s/『G6138』/reinforced/g
s/『G6139』/to meditate/g
s/『G6140』/meditation/g
s/『G6141』/be despised/g
s/『G6142』/stout/g
s/『G6143』/to mature/g
s/『G6144』/powerlessness/g
s/『G6145』/everlasting/g
s/『G6146』/idle/g
s/『G6147』/rancor/g
s/『G6148』/Athanim/g
s/『G6149』/rebellion/g
s/『G6150』/a disregarding/g
s/『G6152』/depression/g
s/『G6153』/unfit/g
s/『G6154』/to acquit/g
s/『G6155』/acclamation/g
s/『G6156』/to stand in awe/g
s/『G6157』/genitals/g
s/『G6158』/soot/g
s/『G6159』/open air/g
s/『G6160』/a portal/g
s/『G6161』/porch/g
s/『G6162』/pediment/g
s/『G6163』/to have tooth-chills/g
s/『G6164』/praiseworthy/g
s/『G6165』/praise/g
s/『G6166』/enigma speaker/g
s/『G6167』/a goat/g
s/『G6168』/a flock of goats/g
s/『G6169』/a herder/g
s/『G6170』/preferred/g
s/『G6171』/sensitive/g
s/『G6172』/disgracefully/g
s/『G6173』/requesting/g
s/『G6174』/to blame/g
s/『G6175』/accusation/g
s/『G6176』/a captive/g
s/『G6177』/innocence/g
s/『G6178』/a thorn/g
s/『G6179』/heartless/g
s/『G6180』/impotable/g
s/『G6181』/unready/g
s/『G6182』/unfinished/g
s/『G6183』/inextinguishable/g
s/『G6184』/indifference/g
s/『G6185』/be discouraged/g
s/『G6186』/pointed/g
s/『G6187』/fixed/g
s/『G6188』/a point/g
s/『G6189』/uncalled/g
s/『G6190』/at this moment/g
s/『G6191』/anvil/g
s/『G6192』/unrestrained/g
s/『G6193』/to sharpen/g
s/『G6194』/to shoot/g
s/『G6195』/a shooter/g
s/『G6196』/unbecoming/g
s/『G6197』/to act unintentionally/g
s/『G6198』/unintentional/g
s/『G6199』/unintentionally/g
s/『G6200』/audible/g
s/『G6201』/to cause to hear/g
s/『G6202』/Akra/g
s/『G6203』/restriction/g
s/『G6204』/to hear/g
s/『G6205』/a hearing/g
s/『G6206』/uncircumcised/g
s/『G6207』/a fruit tree/g
s/『G6208』/a toe\/thumb\/tip/g
s/『G6209』/chiseled/g
s/『G6210』/an extremity/g
s/『G6211』/void/g
s/『G6212』/to act ostentatiously/g
s/『G6213』/a price/g
s/『G6214』/a shout/g
s/『G6215』/be a runaway/g
s/『G6216』/to ache/g
s/『G6217』/suffering/g
s/『G6218』/pain/g
s/『G6219』/painful/g
s/『G6220』/pain/g
s/『G6221』/an anointing/g
s/『G6222』/to grind flour/g
s/『G6223』/an osprey/g
s/『G6224』/a salty land/g
s/『G6225』/to pollute/g
s/『G6226』/to capture/g
s/『G6227』/but only/g
s/『G6228』/a price/g
s/『G6229』/foreign tongue/g
s/『G6230』/to change/g
s/『G6231』/change/g
s/『G6232』/to alienate/g
s/『G6233』/strangely/g
s/『G6234』/alienation/g
s/『G6235』/foreign language/g
s/『G6236』/a leap/g
s/『G6237』/brine/g
s/『G6238』/salt-flats/g
s/『G6239』/brackish/g
s/『G6240』/threshing/g
s/『G6241』/ointment/g
s/『G6242』/a sacred grove/g
s/『G6243』/a woods/g
s/『G6244』/a chain-work/g
s/『G6245』/toasted grain/g
s/『G6246』/psoriasis/g
s/『G6247』/aloe/g
s/『G6248』/a wagon/g
s/『G6249』/octaves/g
s/『G6250』/unchewable/g
s/『G6251』/a mark/g
s/『G6252』/faint/g
s/『G6253』/to darken/g
s/『G6254』/to blunt/g
s/『G6255』/to extract/g
s/『G6256』/a milking/g
s/『G6257』/indifferently/g
s/『G6258』/unmeasured/g
s/『G6259』/a harvest/g
s/『G6260』/without pay/g
s/『G6261』/a ewe-lamb/g
s/『G6262』/not betrothed/g
s/『G6263』/honey-bread/g
s/『G6264』/an error/g
s/『G6265』/an almond/g
s/『G6266』/untold/g
s/『G6267』/clothing/g
s/『G6268』/a fisherman/g
s/『G6269』/a spread/g
s/『G6270』/ambidextrous/g
s/『G6271』/in between/g
s/『G6272』/stairs/g
s/『G6273』/ascending/g
s/『G6274』/to carry/g
s/『G6275』/a rider/g
s/『G6276』/to sprout up/g
s/『G6277』/to stir up/g
s/『G6278』/tendril/g
s/『G6279』/to break camp/g
s/『G6280』/to break out/g
s/『G6281』/marching/g
s/『G6282』/impudent/g
s/『G6283』/impudently/g
s/『G6284』/to kindle/g
s/『G6285』/to call by name/g
s/『G6286』/laying down/g
s/『G6287』/a couch/g
s/『G6288』/to play music/g
s/『G6289』/to blaze up/g
s/『G6290』/unfeeling/g
s/『G6291』/to gather up/g
s/『G6292』/an elevation/g
s/『G6293』/consumption/g
s/『G6294』/to intermingle/g
s/『G6295』/a sign of reluctance/g
s/『G6296』/to disagree/g
s/『G6297』/be fatigued/g
s/『G6298』/to dry up/g
s/『G6299』/rest/g
s/『G6300』/be effronted/g
s/『G6301』/satisfying/g
s/『G6302』/to breathe/g
s/『G6303』/breathing/g
s/『G6304』/to die in/g
s/『G6305』/to prepare/g
s/『G6306』/not be turned away/g
s/『G6307』/to incite/g
s/『G6308』/to kidnap/g
s/『G6309』/to tear asunder/g
s/『G6310』/to dig up/g
s/『G6311』/to rise upwards/g
s/『G6312』/a height/g
s/『G6313』/to rip open/g
s/『G6314』/to escape/g
s/『G6315』/violent shaking/g
s/『G6316』/a diet/g
s/『G6317』/forehead bald/g
s/『G6318』/forehead bald/g
s/『G6319』/an offering/g
s/『G6320』/a bearing pole/g
s/『G6321』/to block up/g
s/『G6322』/to mix up/g
s/『G6323』/to grow up/g
s/『G6324』/respite/g
s/『G6325』/valor/g
s/『G6326』/courage/g
s/『G6327』/vigorous/g
s/『G6328』/effeminate/g
s/『G6329』/become a man/g
s/『G6330』/to unroll/g
s/『G6331』/mercilessly/g
s/『G6332』/unhoped for/g
s/『G6333』/wind-blown/g
s/『G6334』/destroyed by wind/g
s/『G6335』/unascertained/g
s/『G6336』/unhearing/g
s/『G6337』/not malleable/g
s/『G6338』/because of/g
s/『G6339』/because of/g
s/『G6340』/a flower ornament/g
s/『G6341』/to bloom/g
s/『G6342』/a flowered work/g
s/『G6343』/confession/g
s/『G6344』/to deduct/g
s/『G6345』/incurable/g
s/『G6346』/to fly about/g
s/『G6347』/without strength/g
s/『G6348』/a passage/g
s/『G6349』/to act lawlessly/g
s/『G6350』/a violation of law/g
s/『G6351』/to root up/g
s/『G6352』/mindless/g
s/『G6353』/to rise against/g
s/『G6354』/to listen in turn/g
s/『G6355』/to bargain/g
s/『G6356』/remuneration/g
s/『G6357』/to take away in return/g
s/『G6358』/to die for/g
s/『G6359』/an answer/g
s/『G6360』/a copy/g
s/『G6361』/to repay/g
s/『G6362』/to plead/g
s/『G6363』/a rival/g
s/『G6364』/contrary/g
s/『G6365』/to relocate/g
s/『G6366』/to adjudicate/g
s/『G6367』/a shielder/g
s/『G6368』/a beam of a loom/g
s/『G6369』/to act against/g
s/『G6370』/to battle/g
s/『G6371』/facing/g
s/『G6372』/a contradiction/g
s/『G6373』/a support/g
s/『G6374』/to support/g
s/『G6375』/to substitute/g
s/『G6376』/an inner room/g
s/『G6377』/barefoot/g
s/『G6378』/unsufferable/g
s/『G6379』/unsubdued/g
s/『G6380』/to elevate/g
s/『G6381』/worthy of trust/g
s/『G6382』/a petition/g
s/『G6383』/an axle/g
s/『G6384』/uninhabited/g
s/『G6385』/inability to see/g
s/『G6386』/a report/g
s/『G6387』/enslavement/g
s/『G6388』/stupidity/g
s/『G6389』/exaction/g
s/『G6390』/to wipe away/g
s/『G6391』/alienation/g
s/『G6392』/tenderness/g
s/『G6393』/to make tender/g
s/『G6394』/to blur/g
s/『G6395』/to refuse/g
s/『G6396』/to cast shame/g
s/『G6397』/to consume/g
s/『G6398』/meet/g
s/『G6399』/a meeting/g
s/『G6400』/from on top/g
s/『G6401』/unalterable/g
s/『G6402』/a departure/g
s/『G6403』/chattel/g
s/『G6404』/to dedicate/g
s/『G6405』/spreading out/g
s/『G6406』/unhewn/g
s/『G6407』/to set free/g
s/『G6408』/to silence/g
s/『G6409』/to fasten/g
s/『G6410』/impure/g
s/『G6411』/east wind/g
s/『G6412』/pear tree/g
s/『G6413』/simple/g
s/『G6414』/insatiable/g
s/『G6415』/singleness/g
s/『G6416』/to simplify/g
s/『G6417』/to repel/g
s/『G6418』/to wean/g
s/『G6419』/a descendant/g
s/『G6420』/to bind up/g
s/『G6421』/a bundle/g
s/『G6422』/to tie up/g
s/『G6423』/to divide up/g
s/『G6424』/to run away/g
s/『G6425』/to banish/g
s/『G6426』/a gift/g
s/『G6427』/restitution/g
s/『G6428』/to mow/g
s/『G6429』/resettlement/g
s/『G6430』/resettlement/g
s/『G6432』/a settlement/g
s/『G6433』/to move/g
s/『G6434』/to clear away/g
s/『G6435』/to cleanse/g
s/『G6436』/to sit apart/g
s/『G6437』/to suffer/g
s/『G6438』/to invoke/g
s/『G6439』/to pierce/g
s/『G6440』/a piercing/g
s/『G6441』/be without a turban/g
s/『G6442』/to exile/g
s/『G6443』/to weep/g
s/『G6444』/a prison/g
s/『G6445』/to turn off/g
s/『G6446』/to rinse off/g
s/『G6447』/to pluck off/g
s/『G6448』/to transmit/g
s/『G6449』/concealment/g
s/『G6450』/concealment/g
s/『G6451』/to detain/g
s/『G6452』/be mute/g
s/『G6453』/to kick up/g
s/『G6454』/to enjoy/g
s/『G6455』/to resign/g
s/『G6456』/to petrify/g
s/『G6457』/a plea/g
s/『G6458』/left over/g
s/『G6459』/release on payment of ransom, to/g
s/『G6460』/to blame/g
s/『G6461』/to be estranged/g
s/『G6462』/to cause to dry up/g
s/『G6463』/to scrape off/g
s/『G6464』/to put to the test/g
s/『G6465』/to take a fifth part/g
s/『G6466』/to leap back/g
s/『G6467』/to squeeze out/g
s/『G6468』/digression/g
s/『G6469』/to undo/g
s/『G6470』/a scapegoat/g
s/『G6471』/acting as scapegoat/g
s/『G6472』/to drop down/g
s/『G6473』/to rip off/g
s/『G6474』/to unharness/g
s/『G6475』/to consume/g
s/『G6476』/to shake off/g
s/『G6477』/to keep silent/g
s/『G6478』/accoutrements/g
s/『G6479』/to move a tent/g
s/『G6480』/to harden against/g
s/『G6481』/to watch over/g
s/『G6482』/to curse one to be far away/g
s/『G6483』/dismissal/g
s/『G6484』/to frighten away/g
s/『G6485』/a broken branch/g
s/『G6486』/to drop from/g
s/『G6487』/to trickle down/g
s/『G6488』/defection/g
s/『G6489』/to defect/g
s/『G6490』/a defector/g
s/『G6491』/a defecting/g
s/『G6492』/to disregard/g
s/『G6493』/rejection/g
s/『G6494』/to cure/g
s/『G6495』/to whistle/g
s/『G6496』/to seal up/g
s/『G6497』/a seal/g
s/『G6498』/to sever/g
s/『G6499』/to extend/g
s/『G6500』/to shred/g
s/『G6501』/to fry/g
s/『G6502』/to pay for/g
s/『G6503』/to run from/g
s/『G6504』/to pacify/g
s/『G6505』/to harvest/g
s/『G6506』/to miss/g
s/『G6507』/blindness/g
s/『G6508』/to sentence/g
s/『G6509』/a maxim/g
s/『G6510』/impost/g
s/『G6511』/to shut out/g
s/『G6512』/to blow away/g
s/『G6513』/to pour out/g
s/『G6514』/voidance/g
s/『G6515』/unfired/g
s/『G6516』/for the sick/g
s/『G6517』/silver things/g
s/『G6518』/a layer of vine/g
s/『G6519』/repulsion/g
s/『G6521』/wilderness/g
s/『G6522』/to curse/g
s/『G6523』/of a spider/g
s/『G6524』/idleness/g
s/『G6525』/to work silver/g
s/『G6526』/bought with silver/g
s/『G6527』/entirely/g
s/『G6528』/articulation/g
s/『G6529』/altar hearth/g
s/『G6530』/a lion-like person/g
s/『G6531』/counted/g
s/『G6532』/herbs/g
s/『G6533』/of juniper/g
s/『G6534』/juniper/g
s/『G6535』/a joint/g
s/『G6536』/a plowman/g
s/『G6537』/plowing/g
s/『G6538』/a plowshare/g
s/『G6539』/plowed fields/g
s/『G6540』/a prey/g
s/『G6541』/rootless/g
s/『G6542』/be ill/g
s/『G6543』/illness/g
s/『G6544』/a male/g
s/『G6545』/a load/g
s/『G6546』/a measure/g
s/『G6547』/a shoulder/g
s/『G6548』/just now/g
s/『G6549』/of a baker/g
s/『G6550』/chief jailer/g
s/『G6551』/chief jailer/g
s/『G6552』/chief friend/g
s/『G6553』/chief eunuch/g
s/『G6554』/chief guard/g
s/『G6555』/office of chief wine taster/g
s/『G6556』/chief wine taster/g
s/『G6557』/chief patriarch/g
s/『G6558』/chief baker/g
s/『G6559』/commander-in-chief/g
s/『G6560』/chief guard/g
s/『G6561』/be chief of construction/g
s/『G6562』/construction/g
s/『G6563』/chief of a tribe/g
s/『G6564』/chief/g
s/『G6565』/collection/g
s/『G6566』/lamp black/g
s/『G6567』/an act of impiety/g
s/『G6568』/incorruptible/g
s/『G6569』/a stork/g
s/『G6570』/without food/g
s/『G6571』/a song/g
s/『G6572』/a mole/g
s/『G6573』/a bezel/g
s/『G6574』/homeless/g
s/『G6575』/a vertebrae/g
s/『G6576』/astrologer/g
s/『G6577』/against reprisal/g
s/『G6578』/hurtful/g
s/『G6579』/to lack sense/g
s/『G6580』/breach-of-contract/g
s/『G6581』/to break a contract/g
s/『G6582』/tar/g
s/『G6583』/tar/g
s/『G6584』/to apply tar/g
s/『G6585』/carnal/g
s/『G6586』/nevertheless/g
s/『G6587』/unwalled/g
s/『G6588』/childlessness/g
s/『G6589』/be barren/g
s/『G6590』/unpunished/g
s/『G6591』/a spindle/g
s/『G6592』/a short cut/g
s/『G6593』/free from impurities/g
s/『G6594』/a hopping locust/g
s/『G6595』/a small locust/g
s/『G6596』/be in adversity/g
s/『G6597』/a shining/g
s/『G6598』/to shine/g
s/『G6599』/self-sufficiency/g
s/『G6600』/daily/g
s/『G6601』/daily/g
s/『G6602』/a curtain/g
s/『G6603』/a furrow/g
s/『G6604』/chief of the palace/g
s/『G6605』/a canyon/g
s/『G6606』/a breeze/g
s/『G6607』/to suffice/g
s/『G6608』/at that time/g
s/『G6609』/to desert/g
s/『G6611』/native-born/g
s/『G6612』/nape/g
s/『G6613』/squalid/g
s/『G6614』/austere/g
s/『G6615』/to purify/g
s/『G6616』/choice portion/g
s/『G6617』/to hop/g
s/『G6618』/to affix/g
s/『G6619』/menstruation/g
s/『G6620』/unsparingly/g
s/『G6621』/merely/g
s/『G6622』/to guide/g
s/『G6623』/uncorrupted/g
s/『G6624』/fearlessness/g
s/『G6625』/without fear/g
s/『G6626』/non-productivity/g
s/『G6627』/separation/g
s/『G6628』/an offering/g
s/『G6629』/be unwise/g
s/『G6630』/unwisely/g
s/『G6631』/unguardedly/g
s/『G6632』/to withhold/g
s/『G6633』/apart/g
s/『G6634』/now/g
s/『G6635』/agate/g
s/『G6636』/reed-grass/g
s/『G6637』/a thorn-bush/g
s/『G6638』/midnight/g
s/『G6639』/unseasonable/g
s/『G6640』/master/g
s/『G6641』/linen clothes/g
s/『G6642』/to proceed/g
s/『G6643』/deeply/g
s/『G6644』/deep voiced/g
s/『G6645』/having thick lips/g
s/『G6646』/bath \(measure\)/g
s/『G6647』/to go/g
s/『G6648』/a staff/g
s/『G6649』/first-fruit/g
s/『G6650』/a pin/g
s/『G6651』/a dye/g
s/『G6652』/linen/g
s/『G6653』/a pit/g
s/『G6654』/a palace/g
s/『G6655』/an unknown language/g
s/『G6656』/be weighed down/g
s/『G6657』/heavy-hearted/g
s/『G6658』/cobra/g
s/『G6659』/bewitching/g
s/『G6660』/a burden/g
s/『G6661』/leech/g
s/『G6662』/abomination/g
s/『G6663』/firmly/g
s/『G6664』/profaning/g
s/『G6665』/a breach/g
s/『G6666』/lightning/g
s/『G6667』/weaponry/g
s/『G6668』/a chest/g
s/『G6669』/beryl/g
s/『G6670』/forcibly/g
s/『G6671』/to breed/g
s/『G6672』/papyrus/g
s/『G6673』/a library/g
s/『G6674』/courier/g
s/『G6675』/a pitcher/g
s/『G6676』/sustenance/g
s/『G6677』/a palace/g
s/『G6678』/eyelid/g
s/『G6679』/a cesspool/g
s/『G6680』/bullock/g
s/『G6681』/dung/g
s/『G6682』/a casting/g
s/『G6683』/to resonate/g
s/『G6684』/carrion/g
s/『G6685』/pastured/g
s/『G6686』/a curl/g
s/『G6687』/a small cluster of grapes/g
s/『G6688』/roebuck/g
s/『G6689』/an oxgoad/g
s/『G6690』/a herd/g
s/『G6691』/of a counselor/g
s/『G6692』/to heap up/g
s/『G6693』/flowering rush/g
s/『G6694』/butter/g
s/『G6695』/to have a sore throat/g
s/『G6696』/slow of tongue/g
s/『G6697』/groaning/g
s/『G6698』/to thunder/g
s/『G6699』/human/g
s/『G6700』/grasshopper/g
s/『G6701』/a roaring/g
s/『G6702』/eatable/g
s/『G6703』/a hide/g
s/『G6704』/to plug/g
s/『G6705』/a clod/g
s/『G6706』/a droplet/g
s/『G6707』/crystal/g
s/『G6708』/astrologer/g
s/『G6709』/treasurer/g
s/『G6710』/land/g
s/『G6711』/a javelin/g
s/『G6712』/suckling/g
s/『G6713』/a wicker cage/g
s/『G6714』/weasel/g
s/『G6715』/marry/g
s/『G6716』/an in-law/g
s/『G6717』/frame/g
s/『G6718』/a treasurer/g
s/『G6719』/prancing/g
s/『G6720』/to prance/g
s/『G6721』/to prance/g
s/『G6722』/a troop/g
s/『G6723』/molding/g
s/『G6724』/a foreigner/g
s/『G6725』/to joke/g
s/『G6726』/a joke/g
s/『G6727』/a jokester/g
s/『G6728』/an honor/g
s/『G6729』/taste/g
s/『G6730』/tasting/g
s/『G6731』/a dam/g
s/『G6732』/a surveying/g
s/『G6733』/of a surveyor/g
s/『G6734』/earth-born/g
s/『G6735』/a grape-stone/g
s/『G6736』/a giant/g
s/『G6737』/owl/g
s/『G6738』/to sweeten/g
s/『G6739』/to sweeten/g
s/『G6740』/sweetness/g
s/『G6741』/sweetness/g
s/『G6742』/sweet/g
s/『G6743』/sweetness/g
s/『G6744』/a carving/g
s/『G6745』/a carving/g
s/『G6746』/a carving/g
s/『G6747』/to carve/g
s/『G6748』/with a tongue cut out/g
s/『G6749』/flatter/g
s/『G6750』/talkative/g
s/『G6751』/a cheek/g
s/『G6752』/dim/g
s/『G6753』/to darken/g
s/『G6754』/dim/g
s/『G6755』/acquaintance/g
s/『G6756』/knowingly/g
s/『G6757』/grumbling/g
s/『G6758』/a homer/g
s/『G6759』/to have a toothache/g
s/『G6760』/a toothache/g
s/『G6761』/a seminal emission/g
s/『G6762』/semen/g
s/『G6763』/writing/g
s/『G6764』/write/g
s/『G6765』/an academic/g
s/『G6766』/a judicial recorder/g
s/『G6767』/a stylus/g
s/『G6768』/a pen/g
s/『G6769』/vigilance/g
s/『G6770』/to growl/g
s/『G6771』/a griffin/g
s/『G6772』/be naked/g
s/『G6773』/nakedness/g
s/『G6774』/chamber of women/g
s/『G6775』/a helpless woman/g
s/『G6776』/a curve/g
s/『G6777』/to make a curvature/g
s/『G6778』/a vulture/g
s/『G6779』/angular/g
s/『G6780』/dabir/g
s/『G6781』/a firebrand/g
s/『G6782』/a thicket/g
s/『G6783』/a hare/g
s/『G6784』/bushy/g
s/『G6785』/to worry/g
s/『G6786』/be in awe/g
s/『G6787』/wretched/g
s/『G6788』/afternoon/g
s/『G6789』/to make timid/g
s/『G6790』/dusk/g
s/『G6791』/awful/g
s/『G6792』/a commander of ten/g
s/『G6793』/sixteen/g
s/『G6794』/seventeen/g
s/『G6795』/ten cubits/g
s/『G6796』/ten-times/g
s/『G6797』/a commander of ten/g
s/『G6798』/thirteen/g
s/『G6799』/ten-stringed/g
s/『G6800』/a trough/g
s/『G6801』/a hide covering/g
s/『G6802』/be master/g
s/『G6803』/mastery/g
s/『G6804』/be second/g
s/『G6805』/a second book of the law/g
s/『G6806』/repetition/g
s/『G6807』/second rank/g
s/『G6808』/a strike/g
s/『G6809』/manifestation/g
s/『G6810』/a ford/g
s/『G6811』/a footstep/g
s/『G6812』/to force through/g
s/『G6813』/to cause to pass over/g
s/『G6814』/to continue to live/g
s/『G6815』/to proclaim forth/g
s/『G6816』/distraction/g
s/『G6817』/to deliberate upon/g
s/『G6818』/deliberation/g
s/『G6819』/deliberation/g
s/『G6820』/declaration/g
s/『G6821』/to carve/g
s/『G6822』/a diagram/g
s/『G6823』/to circumscribe/g
s/『G6824』/apparent/g
s/『G6825』/to penetrate/g
s/『G6826』/to warm through/g
s/『G6827』/a disposition/g
s/『G6828』/to break through/g
s/『G6829』/habitation/g
s/『G6830』/to pass one's life/g
s/『G6831』/to sit separately/g
s/『G6832』/to bend/g
s/『G6833』/ineffectual/g
s/『G6834』/empty/g
s/『G6835』/to snap/g
s/『G6836』/to steal away/g
s/『G6837』/to carry across/g
s/『G6838』/a breach/g
s/『G6839』/to cut through/g
s/『G6840』/to look through/g
s/『G6841』/to escape notice/g
s/『G6842』/white-mixed/g
s/『G6843』/to leap across/g
s/『G6844』/versification/g
s/『G6845』/parting/g
s/『G6846』/to miss entirely/g
s/『G6847』/bearing witness/g
s/『G6848』/to measure out/g
s/『G6849』/a measurement/g
s/『G6850』/to give rest/g
s/『G6851』/to spin/g
s/『G6852』/to decorate/g
s/『G6853』/to arise/g
s/『G6854』/to consider/g
s/『G6855』/a device/g
s/『G6856』/useless disputation/g
s/『G6857』/to lose virginity/g
s/『G6858』/to discontinue/g
s/『G6859』/to threaten/g
s/『G6860』/to spread/g
s/『G6861』/to open and spread out/g
s/『G6862』/a small pillar/g
s/『G6863』/to fail/g
s/『G6864』/to flatten out/g
s/『G6865』/to skirmish/g
s/『G6866』/to refresh/g
s/『G6867』/a sale/g
s/『G6868』/a downfall/g
s/『G6869』/ravaging/g
s/『G6870』/to sprinkle/g
s/『G6871』/to scatter/g
s/『G6872』/to waver/g
s/『G6873』/to mold/g
s/『G6874』/to excite/g
s/『G6875』/an explanation/g
s/『G6876』/to disperse/g
s/『G6877』/to equip/g
s/『G6878』/equipment/g
s/『G6879』/dispersing/g
s/『G6880』/a warp/g
s/『G6881』/a tearing in pieces/g
s/『G6882』/perverseness/g
s/『G6883』/to spread with carpets/g
s/『G6884』/a gap/g
s/『G6885』/to cut asunder/g
s/『G6886』/a disposition/g
s/『G6887』/to extend/g
s/『G6888』/to melt/g
s/『G6889』/preservation/g
s/『G6890』/to pluck out/g
s/『G6891』/a clasp/g
s/『G6892』/carvings/g
s/『G6893』/be overawed/g
s/『G6894』/to maintain/g
s/『G6895』/to run across/g
s/『G6896』/pastime/g
s/『G6897』/transparent/g
s/『G6898』/to show light through/g
s/『G6899』/to burn up/g
s/『G6900』/to disperse/g
s/『G6901』/dispersion/g
s/『G6902』/to dissent/g
s/『G6903』/to illuminate/g
s/『G6904』/to diffuse/g
s/『G6905』/to smear all over/g
s/『G6906』/interwoven with gold/g
s/『G6907』/diffusion/g
s/『G6908』/a pause/g
s/『G6909』/to disappoint/g
s/『G6910』/double-tongued/g
s/『G6911』/to bear twins/g
s/『G6912』/to mortgage/g
s/『G6913』/to pass out through/g
s/『G6914』/a mountain pass/g
s/『G6915』/thrust through/g
s/『G6916』/to plead/g
s/『G6917』/to insert/g
s/『G6918』/to administer/g
s/『G6919』/to go through; go through completely/g
s/『G6920』/two whole years/g
s/『G6921』/to revere; be on one's guard/g
s/『G6922』/a tale/g
s/『G6923』/to refine/g
s/『G6924』/to nail/g
s/『G6925』/at variance/g
s/『G6926』/to thrust out/g
s/『G6927』/to act as judge/g
s/『G6928』/court of justice/g
s/『G6929』/to make of lattice work/g
s/『G6930』/latticed/g
s/『G6931』/a double measure/g
s/『G6932』/a corridor/g
s/『G6933』/an administrator/g
s/『G6934』/to build; throughout/g
s/『G6935』/wholly/g
s/『G6936』/to see clearly/g
s/『G6937』/to set right/g
s/『G6938』/to determine/g
s/『G6939』/a ditch/g
s/『G6940』/two cubits/g
s/『G6941』/to repeat/g
s/『G6942』/doubling/g
s/『G6943』/a doubled garment/g
s/『G6944』/double/g
s/『G6945』/to interweave/g
s/『G6946』/a leather covering/g
s/『G6947』/a chair/g
s/『G6948』/be cloven/g
s/『G6949』/a piece/g
s/『G6950』/thirst/g
s/『G6951』/to push away/g
s/『G6952』/second story/g
s/『G6953』/an aqueduct/g
s/『G6954』/a pole/g
s/『G6955』/an approver/g
s/『G6956』/a building/g
s/『G6957』/deceit/g
s/『G6958』/deceitfully/g
s/『G6959』/a layer/g
s/『G6960』/glory/g
s/『G6961』/glorious/g
s/『G6962』/skin/g
s/『G6963』/a young doe/g
s/『G6964』/a buck/g
s/『G6965』/a wooden spear/g
s/『G6966』/dedicated/g
s/『G6967』/a sheaf/g
s/『G6968』/a handful/g
s/『G6969』/a runner/g
s/『G6970』/dew/g
s/『G6971』/a grove/g
s/『G6972』/an oak/g
s/『G6973』/command/g
s/『G6974』/command; domination; might/g
s/『G6975』/be in power/g
s/『G6976』/mightily/g
s/『G6977』/two by two/g
s/『G6979』/discontent/g
s/『G6980』/hard of hearing/g
s/『G6981』/to suffer birth pangs/g
s/『G6982』/inconvenient/g
s/『G6983』/twelve months/g
s/『G6984』/one that takes bribes/g
s/『G6985』/one that receives bribes/g
s/『G6986』/if indeed/g
s/『G6987』/the spring season/g
s/『G6988』/a period of seven/g
s/『G6989』/seventy-two/g
s/『G6990』/seventy-seven/g
s/『G6991』/seventy-five/g
s/『G6992』/seventy-four/g
s/『G6993』/seventy-three/g
s/『G6994』/seventieth/g
s/『G6995』/one who delivers oracles/g
s/『G6996』/a heifer/g
s/『G6997』/to engrave upon/g
s/『G6998』/written/g
s/『G6999』/to guarantee a loan/g
s/『G7000』/surety/g
s/『G7001』/near to/g
s/『G7002』/to lie in wait/g
s/『G7003』/to sit in place/g
s/『G7004』/dedication/g
s/『G7005』/dedication/g
s/『G7006』/to cover up/g
s/『G7007』/containing fruit/g
s/『G7008』/insides/g
s/『G7009』/to hide in/g
s/『G7010』/leftover, surplus/g
s/『G7011』/to abandon/g
s/『G7012』/to mock/g
s/『G7013』/to boast of/g
s/『G7014』/to cling/g
s/『G7015』/to stimulate/g
s/『G7016』/to lock up/g
s/『G7017』/hereditary/g
s/『G7018』/to bind with a cord/g
s/『G7019』/the intestines/g
s/『G7020』/imbedded under/g
s/『G7021』/sculptured/g
s/『G7022』/to sculpt/g
s/『G7023』/to join/g
s/『G7024』/wearied/g
s/『G7025』/be angry/g
s/『G7026』/an object of anger/g
s/『G7027』/to have power over/g
s/『G7028』/a pastry/g
s/『G7029』/to hammer in/g
s/『G7030』/cakes baked in hot ashes/g
s/『G7031』/procured/g
s/『G7032』/to wrap up in/g
s/『G7033』/to laud/g
s/『G7034』/a commendation/g
s/『G7035』/a watchman/g
s/『G7036』/to take in hand/g
s/『G7037』/an enterprise/g
s/『G7038』/a knife/g
s/『G7039』/to commit to/g
s/『G7040』/to pour/g
s/『G7041』/to linger/g
s/『G7042』/native inhabitant/g
s/『G7043』/food/g
s/『G7044』/a dowry/g
s/『G7045』/buttock/g
s/『G7046』/to seat/g
s/『G7047』/a custom/g
s/『G7048』/but if even/g
s/『G7049』/is it not?/g
s/『G7050』/to imagine/g
s/『G7051』/the twentieth day/g
s/『G7052』/of twenty years/g
s/『G7053』/twenty-two/g
s/『G7054』/twenty-one/g
s/『G7055』/twenty-nine/g
s/『G7056』/twenty-six/g
s/『G7057』/twenty-seven/g
s/『G7058』/twenty-eight/g
s/『G7059』/twenty-five/g
s/『G7060』/twenty-four/g
s/『G7061』/twenty-three/g
s/『G7062』/to wrap/g
s/『G7063』/to come/g
s/『G7064』/a sentinel/g
s/『G7065』/at once/g
s/『G7066』/to look in/g
s/『G7067』/acceptable/g
s/『G7068』/to enter into/g
s/『G7069』/to come in as income/g
s/『G7070』/an entrance/g
s/『G7071』/to draw into/g
s/『G7072』/a contribution/g
s/『G7073』/to each other/g
s/『G7074』/a hundred foldly/g
s/『G7075』/a hundred/g
s/『G7076』/to bear a hundred/g
s/『G7078』/to expel/g
s/『G7079』/to sprout forth/g
s/『G7080』/to gush out/g
s/『G7081』/to throw out/g
s/『G7082』/an eruption/g
s/『G7083』/to laugh out loud/g
s/『G7084』/to write out/g
s/『G7085』/to lend with interest/g
s/『G7086』/to flay/g
s/『G7087』/to suspend/g
s/『G7088』/to strip/g
s/『G7089』/to avenge/g
s/『G7090』/avenger/g
s/『G7091』/to erupt/g
s/『G7092』/public notice/g
s/『G7093』/to reap up/g
s/『G7094』/to suck out/g
s/『G7095』/to squeeze out/g
s/『G7096』/to clear out/g
s/『G7097』/sixteen/g
s/『G7098』/sixteenth/g
s/『G7099』/to call forth/g
s/『G7100』/to empty out/g
s/『G7101』/banished; by public proclamation/g
s/『G7102』/to hold an assembly/g
s/『G7103』/assemblyman/g
s/『G7104』/to wash out/g
s/『G7105』/engravement/g
s/『G7106』/to knock back/g
s/『G7107』/to look out of/g
s/『G7108』/to take out of/g
s/『G7109』/to quarry/g
s/『G7110』/to lick up/g
s/『G7111』/end/g
s/『G7112』/to whiten/g
s/『G7113』/very white/g
s/『G7114』/craving/g
s/『G7115』/to call into account/g
s/『G7116』/to select/g
s/『G7117』/feebleness/g
s/『G7118』/ransoming/g
s/『G7119』/to drive mad/g
s/『G7120』/to measure out/g
s/『G7121』/to thoroughly defile/g
s/『G7122』/to extract marrow/g
s/『G7123』/soberness/g
s/『G7124』/be willing/g
s/『G7125』/a voluntary offering/g
s/『G7126』/to carry over/g
s/『G7127』/to march around/g
s/『G7128』/to pressure/g
s/『G7129』/to embitter greatly/g
s/『G7130』/to drink up/g
s/『G7131』/amazement/g
s/『G7132』/to thoroughly wash/g
s/『G7133』/to furnish/g
s/『G7134』/to wage war/g
s/『G7135』/to capture a city/g
s/『G7136』/to pillage/g
s/『G7137』/to buy off/g
s/『G7138』/to flow away/g
s/『G7139』/an inundation/g
s/『G7140』/be torn from/g
s/『G7141』/to cast forth/g
s/『G7142』/an outflow/g
s/『G7143』/to tear off flesh/g
s/『G7144』/to siphon off/g
s/『G7145』/to pull out/g
s/『G7146』/to produce offspring/g
s/『G7147』/to strain out/g
s/『G7148』/to march/g
s/『G7149』/stretching out/g
s/『G7150』/to array/g
s/『G7151』/to cut off/g
s/『G7152』/to waste away/g
s/『G7153』/to bring forth/g
s/『G7154』/to pluck out/g
s/『G7155』/a thrusting out/g
s/『G7156』/to lend with interest/g
s/『G7157』/emasculated/g
s/『G7158』/to run forth/g
s/『G7159』/obliteration/g
s/『G7160』/to obliterate/g
s/『G7161』/obliteration/g
s/『G7162』/to gather in grapes/g
s/『G7163』/to chew away/g
s/『G7164』/to shape/g
s/『G7165』/an impression/g
s/『G7166』/an impression/g
s/『G7167』/to make blind/g
s/『G7168』/a funeral/g
s/『G7169』/resource/g
s/『G7170』/to defile/g
s/『G7171』/to blow away/g
s/『G7172』/an outpouring/g
s/『G7173』/of olive/g
s/『G7174』/to pick olives/g
s/『G7175』/a hammered piece/g
s/『G7176』/to lack/g
s/『G7177』/fir tree/g
s/『G7178』/of fir/g
s/『G7179』/hammered out/g
s/『G7180』/hind/g
s/『G7181』/ivory/g
s/『G7182』/kneaded/g
s/『G7183』/a fetter/g
s/『G7184』/remains/g
s/『G7185』/a concealed place/g
s/『G7186』/a marsh/g
s/『G7187』/to deepen/g
s/『G7188』/threatening/g
s/『G7189』/vomit/g
s/『G7190』/to contaminate/g
s/『G7191』/permanent/g
s/『G7192』/such and such place/g
s/『G7193』/mockery/g
s/『G7194』/to come upon/g
s/『G7195』/to stick into/g
s/『G7196』/to set on fire/g
s/『G7197』/to entrust/g
s/『G7198』/to widen/g
s/『G7199』/a wreath/g
s/『G7200』/blasting/g
s/『G7201』/to impede/g
s/『G7202』/to impede/g
s/『G7203』/to cause/g
s/『G7204』/to do business/g
s/『G7205』/in front/g
s/『G7206』/spit/g
s/『G7207』/to burn/g
s/『G7208』/a combustion/g
s/『G7209』/on a fire/g
s/『G7210』/to appear/g
s/『G7211』/visibly/g
s/『G7212』/an obstruction/g
s/『G7213』/to obstruct/g
s/『G7214』/to listen to attentively/g
s/『G7215』/crosswise/g
s/『G7216』/to assail/g
s/『G7217』/to withstand/g
s/『G7218』/a lack/g
s/『G7219』/in perpetuity/g
s/『G7220』/continually/g
s/『G7221』/bonding, bundles/g
s/『G7222』/to bind in/g
s/『G7223』/to stand as adversary/g
s/『G7224』/to spend one's time/g
s/『G7225』/to give forth/g
s/『G7226』/natural/g
s/『G7227』/within/g
s/『G7228』/inside/g
s/『G7229』/gloriously/g
s/『G7230』/entrails/g
s/『G7231』/to see in/g
s/『G7232』/to entwine/g
s/『G7233』/ninety-eight/g
s/『G7234』/operative/g
s/『G7235』/be pleased with/g
s/『G7236』/to take for security/g
s/『G7237』/collateral/g
s/『G7238』/collateral; taken as a pledge/g
s/『G7239』/a security/g
s/『G7240』/here and there/g
s/『G7241』/a garland/g
s/『G7242』/enthrone/g
s/『G7243』/a thought/g
s/『G7244』/inner thought/g
s/『G7245』/of a year/g
s/『G7246』/nine hundred/g
s/『G7247』/nineteen/g
s/『G7248』/nineteenth/g
s/『G7249』/ninety/g
s/『G7250』/ninety-two/g
s/『G7251』/ninety-six/g
s/『G7252』/ninety-five/g
s/『G7253』/to reflect on/g
s/『G7254』/to nest/g
s/『G7255』/be related/g
s/『G7256』/to arm oneself/g
s/『G7257』/armed/g
s/『G7258』/a solemn affirmation/g
s/『G7259』/to bind by an oath/g
s/『G7260』/to feed upon/g
s/『G7261』/to catch in a snare/g
s/『G7262』/to arrange in/g
s/『G7263』/here/g
s/『G7264』/an embalmer/g
s/『G7265』/to stretch tight/g
s/『G7266』/innards/g
s/『G7267』/to melt away/g
s/『G7268』/to insert/g
s/『G7269』/to value/g
s/『G7270』/highly valued/g
s/『G7271』/a cut/g
s/『G7272』/three-stranded/g
s/『G7273』/amusement/g
s/『G7274』/a dreamer/g
s/『G7275』/large intestine/g
s/『G7276』/face to face/g
s/『G7277』/uniting/g
s/『G7278』/a ring/g
s/『G7279』/to confess/g
s/『G7280』/to rage furiously/g
s/『G7281』/chosen out of/g
s/『G7282』/extraordinary/g
s/『G7283』/six times/g
s/『G7284』/six thousand/g
s/『G7285』/to make very sharp/g
s/『G7286』/six hundredth/g
s/『G7287』/to determine exactly/g
s/『G7288』/an ointment jar/g
s/『G7289』/a wiping out/g
s/『G7290』/to change/g
s/『G7291』/special/g
s/『G7292』/to lead into sin/g
s/『G7293』/six months/g
s/『G7294』/to completely consume/g
s/『G7295』/right opposite/g
s/『G7296』/to blossom/g
s/『G7297』/to draw out/g
s/『G7298』/sudden/g
s/『G7299』/to light up/g
s/『G7300』/to count out/g
s/『G7301』/be enough/g
s/『G7302』/a departure/g
s/『G7303』/be attached to/g
s/『G7304』/to originate/g
s/『G7305』/to despise/g
s/『G7306』/an inner chamber/g
s/『G7307』/to completely form/g
s/『G7308』/to assemble/g
s/『G7309』/to launch an expedition/g
s/『G7310』/to expand/g
s/『G7311』/to vomit forth/g
s/『G7312』/to complete/g
s/『G7313』/to discharge forth/g
s/『G7314』/a search/g
s/『G7315』/to make desolate/g
s/『G7316』/to creep forth/g
s/『G7317』/an inquisition/g
s/『G7318』/a finding out/g
s/『G7319』/to protrude/g
s/『G7320』/description/g
s/『G7321』/an expositor/g
s/『G7322』/an utterance/g
s/『G7323』/sixty-two/g
s/『G7324』/sixty-six/g
s/『G7325』/sixty-seven/g
s/『G7326』/sixty years old/g
s/『G7327』/sixty-eight/g
s/『G7328』/sixty-five/g
s/『G7329』/to hang in the sun/g
s/『G7330』/atonement/g
s/『G7331』/to appease/g
s/『G7332』/an appeasement/g
s/『G7333』/a making an atonement/g
s/『G7334』/to ride forth/g
s/『G7335』/to flutter away/g
s/『G7336』/to make equal/g
s/『G7337』/to trace/g
s/『G7338』/a tracking out/g
s/『G7339』/a departure/g
s/『G7340』/to spend/g
s/『G7341』/a holiday recess/g
s/『G7342』/to build up/g
s/『G7343』/homeless/g
s/『G7344』/to lead aground/g
s/『G7345』/to totally ruin/g
s/『G7346』/devastation/g
s/『G7347』/acknowledgment/g
s/『G7348』/following/g
s/『G7349』/to completely arm/g
s/『G7350』/to sally out/g
s/『G7351』/contempt/g
s/『G7352』/contempt/g
s/『G7353』/a contemptible thing/g
s/『G7354』/to overflow/g
s/『G7355』/purgation/g
s/『G7356』/outer/g
s/『G7357』/an invasion/g
s/『G7358』/to charm/g
s/『G7359』/heeding/g
s/『G7360』/a parapet/g
s/『G7361』/to renew/g
s/『G7362』/to return/g
s/『G7363』/to glean the vintage/g
s/『G7364』/to come back again/g
s/『G7365』/to bloom again/g
s/『G7366』/about/g
s/『G7367』/enchantment/g
s/『G7368』/an enchanter/g
s/『G7369』/to send as successor/g
s/『G7370』/raised elevation/g
s/『G7371』/a raising/g
s/『G7372』/a funnel/g
s/『G7373』/an oil funnel/g
s/『G7374』/a chief ruler/g
s/『G7375』/to let loose on/g
s/『G7376』/be used/g
s/『G7377』/coming/g
s/『G7378』/to bring in addition/g
s/『G7379』/to raise hope/g
s/『G7380』/to lean upon/g
s/『G7381』/questioning/g
s/『G7382』/yearly/g
s/『G7383』/longed for/g
s/『G7384』/to invoke/g
s/『G7385』/attentive/g
s/『G7386』/a stranger/g
s/『G7387』/a step/g
s/『G7388』/a crewman/g
s/『G7389』/a covering/g
s/『G7390』/to plot against/g
s/『G7391』/a plotter/g
s/『G7392』/to rain upon/g
s/『G7393』/related by marriage/g
s/『G7394』/to laugh at/g
s/『G7395』/to load upon/g
s/『G7396』/knowledge/g
s/『G7397』/an arbitrator/g
s/『G7398』/well known/g
s/『G7399』/a breed/g
s/『G7400』/a tithe/g
s/『G7401』/fitting/g
s/『G7402』/to fasten/g
s/『G7403』/to double/g
s/『G7404』/to pursue after/g
s/『G7405』/be lenient/g
s/『G7406』/please/g
s/『G7407』/to outlive/g
s/『G7408』/a fine/g
s/『G7409』/a lid/g
s/『G7410』/desire/g
s/『G7411』/desirable/g
s/『G7412』/to sacrifice upon/g
s/『G7413』/to overtake/g
s/『G7414』/to accurse/g
s/『G7415』/selected/g
s/『G7416』/to incline/g
s/『G7417』/to inundate/g
s/『G7418』/to rest upon/g
s/『G7419』/to embellish/g
s/『G7420』/to prevail against/g
s/『G7421』/to prevail/g
s/『G7422』/to hang upon/g
s/『G7423』/to clap/g
s/『G7424』/to strike/g
s/『G7425』/to roll upon/g
s/『G7426』/to shine forth/g
s/『G7427』/chosen/g
s/『G7428』/be possessed/g
s/『G7429』/convulsed; overcome by convulsions/g
s/『G7430』/to intermix/g
s/『G7431』/intermixed/g
s/『G7432』/an upper millstone/g
s/『G7433』/to think about/g
s/『G7434』/to slumber/g
s/『G7435』/be welcomed as a guest/g
s/『G7436』/a fifth part/g
s/『G7437』/to bring in addition/g
s/『G7438』/to float/g
s/『G7439』/to sprinkle upon/g
s/『G7440』/to overflow/g
s/『G7441』/a saddle/g
s/『G7442』/to saddle/g
s/『G7443』/to stir up/g
s/『G7444』/to mark/g
s/『G7445』/to limp/g
s/『G7446』/to envelop/g
s/『G7447』/to repair/g
s/『G7448』/a review/g
s/『G7449』/a draw curtain/g
s/『G7450』/to hurry/g
s/『G7451』/to show compassion/g
s/『G7452』/to hasten/g
s/『G7453』/a taskmaster/g
s/『G7454』/higher knowledge/g
s/『G7455』/a stay/g
s/『G7456』/to pile up/g
s/『G7457』/to march against/g
s/『G7458』/to rise up together against/g
s/『G7459』/to gather together against/g
s/『G7460』/to put a seal upon/g
s/『G7461』/a practice/g
s/『G7462』/to apply/g
s/『G7463』/reproach/g
s/『G7464』/together/g
s/『G7465』/to run to/g
s/『G7466』/to crush/g
s/『G7467』/wearing away/g
s/『G7468』/to portend/g
s/『G7469』/to glean/g
s/『G7470』/a gleaning/g
s/『G7471』/to rejoice at/g
s/『G7472』/gratifying/g
s/『G7473』/derision/g
s/『G7474』/incurring ridicule/g
s/『G7475』/forearm/g
s/『G7476』/a vessel/g
s/『G7477』/grant/g
s/『G7478』/to stink/g
s/『G7479』/an estate/g
s/『G7480』/reviled/g
s/『G7481』/a hoopoe/g
s/『G7482』/of seven years/g
s/『G7483』/seventeen/g
s/『G7484』/seventeenth/g
s/『G7485』/seven hundred/g
s/『G7486』/of seven months/g
s/『G7487』/seven-fold/g
s/『G7488』/seven-fold/g
s/『G7489』/seven-fold/g
s/『G7490』/a shoulder-piece/g
s/『G7491』/to roar against/g
s/『G7492』/a lover/g
s/『G7493』/to love passionately/g
s/『G7494』/a chest/g
s/『G7495』/a work tool/g
s/『G7496』/a deed/g
s/『G7497』/to direct works/g
s/『G7498』/a foreman/g
s/『G7499』/aggravation/g
s/『G7500』/an irritant/g
s/『G7501』/a support/g
s/『G7502』/woolen/g
s/『G7503』/solitary/g
s/『G7504』/a recluse/g
s/『G7505』/wool worker; one working in wool/g
s/『G7506』/ground up/g
s/『G7507』/a translator/g
s/『G7508』/to crawl/g
s/『G7509』/red dye/g
s/『G7510』/to dye red/g
s/『G7511』/blight/g
s/『G7512』/a heron/g
s/『G7513』/passion/g
s/『G7514』/during evening/g
s/『G7515』/feasting/g
s/『G7516』/a grate/g
s/『G7517』/broiled/g
s/『G7518』/be late/g
s/『G7519』/innermost/g
s/『G7520』/inside/g
s/『G7521』/to chastise/g
s/『G7522』/a mistress/g
s/『G7523』/friendship/g
s/『G7524』/chastisement/g
s/『G7525』/chastisement/g
s/『G7526』/unequally yoked/g
s/『G7527』/good news/g
s/『G7528』/easily caught/g
s/『G7529』/well-tuned/g
s/『G7530』/well done/g
s/『G7531』/magnanimity/g
s/『G7532』/well-known/g
s/『G7533』/be approved/g
s/『G7534』/to enjoy good health/g
s/『G7535』/confident/g
s/『G7536』/well-equipped/g
s/『G7537』/heedful/g
s/『G7538』/distinct/g
s/『G7539』/to thrive/g
s/『G7540』/flourishing/g
s/『G7541』/to prosper/g
s/『G7542』/prosperity/g
s/『G7543』/right/g
s/『G7544』/to propitiate/g
s/『G7545』/propitious/g
s/『G7546』/despicable/g
s/『G7547』/renowned/g
s/『G7548』/to have good vine branches/g
s/『G7549』/well-tempered/g
s/『G7550』/well-spoken/g
s/『G7551』/huge/g
s/『G7552』/changeable/g
s/『G7553』/tall/g
s/『G7554』/prosperous/g
s/『G7555』/prosperously/g
s/『G7556』/to enjoy pleasure/g
s/『G7557』/elegantly/g
s/『G7558』/beautiful/g
s/『G7559』/good-looking/g
s/『G7560』/an inventor/g
s/『G7561』/unexpected gain/g
s/『G7562』/well-rooted/g
s/『G7563』/breadth/g
s/『G7564』/broad/g
s/『G7565』/be moldy/g
s/『G7566』/well-shaded/g
s/『G7567』/be stable/g
s/『G7568』/skillfully/g
s/『G7569』/versatility/g
s/『G7570』/conciliatory/g
s/『G7571』/orderly/g
s/『G7572』/easily managed/g
s/『G7573』/easily/g
s/『G7574』/confidently/g
s/『G7575』/sweet smelling/g
s/『G7576』/be fragrant/g
s/『G7577』/a royal pavilion/g
s/『G7578』/to tempt; seduce to sin/g
s/『G7579』/to attach to/g
s/『G7580』/to drag upon/g
s/『G7581』/peeling skin/g
s/『G7582』/cooked/g
s/『G7583』/to explore/g
s/『G7584』/to provide/g
s/『G7585』/supplies/g
s/『G7586』/to inspect/g
s/『G7587』/an ephod/g
s/『G7588』/to hate/g
s/『G7589』/be an enemy/g
s/『G7590』/hatred/g
s/『G7591』/hedgehog/g
s/『G7592』/a potentate/g
s/『G7593』/a stew/g
s/『G7594』/to bake/g
s/『G7595』/early morning/g
s/『G7596』/morning star/g
s/『G7597』/spelt/g
s/『G7598』/boiling/g
s/『G7599』/harness/g
s/『G7600』/jealousy/g
s/『G7601』/jealousy/g
s/『G7602』/zealous/g
s/『G7603』/a pike/g
s/『G7604』/Zif/g
s/『G7605』/to join together/g
s/『G7606』/beer/g
s/『G7607』/leavened/g
s/『G7608』/leavened/g
s/『G7609』/to portray/g
s/『G7610』/taking alive/g
s/『G7611』/broth/g
s/『G7612』/restoring to life/g
s/『G7613』/to enliven/g
s/『G7614』/to enliven/g
s/『G7615』/girding up/g
s/『G7616』/governing/g
s/『G7617』/a leading/g
s/『G7618』/be esteemed/g
s/『G7619』/be delicious/g
s/『G7620』/agreeable/g
s/『G7621』/luscious/g
s/『G7622』/luscious/g
s/『G7623』/sweet sounding/g
s/『G7624』/light; \(in weight\)/g
s/『G7625』/continuance/g
s/『G7626』/molten bronze/g
s/『G7627』/to expose to sun/g
s/『G7628』/half-boiled/g
s/『G7629』/the mule/g
s/『G7630』/the half/g
s/『G7631』/to halve/g
s/『G7632』/reins/g
s/『G7633』/a charioteer/g
s/『G7634』/the liver/g
s/『G7635』/be calm/g
s/『G7636』/a hero/g
s/『G7637』/tranquilly/g
s/『G7638』/an echo/g
s/『G7639』/to flourish/g
s/『G7640』/an armory/g
s/『G7641』/a furnace/g
s/『G7642』/tharsis/g
s/『G7643』/to cause wonder/g
s/『G7644』/wonderfully/g
s/『G7645』/a vestibule/g
s/『G7646』/rule/g
s/『G7647』/a porch/g
s/『G7648』/thekel/g
s/『G7649』/a soothsayer/g
s/『G7650』/wanted/g
s/『G7651』/in place/g
s/『G7652』/groundwork/g
s/『G7653』/a furnace/g
s/『G7654』/a female attendant/g
s/『G7655』/teraphim/g
s/『G7656』/a hunter/g
s/『G7657』/a harvest/g
s/『G7658』/a reaping hook; lightweight covering/g
s/『G7659』/heat/g
s/『G7660』/a tong/g
s/『G7661』/hot/g
s/『G7662』/designation/g
s/『G7663』/a rule/g
s/『G7664』/something visible/g
s/『G7665』/female/g
s/『G7666』/sex-crazed/g
s/『G7667』/a heap/g
s/『G7668』/a wild beast/g
s/『G7669』/a hunt/g
s/『G7670』/taken by wild beasts/g
s/『G7671』/eaten by wild beasts/g
s/『G7672』/a treasury/g
s/『G7673』/a treasurer/g
s/『G7674』/revelry/g
s/『G7675』/a wicker basket/g
s/『G7676』/a hill/g
s/『G7677』/crushed testicles/g
s/『G7678』/a fracture/g
s/『G7679』/to crush/g
s/『G7680』/affliction/g
s/『G7681』/decaying flesh/g
s/『G7682』/clouded/g
s/『G7683』/boldness/g
s/『G7684』/bold-hearted/g
s/『G7685』/over-confident/g
s/『G7686』/bold/g
s/『G7687』/a devastation/g
s/『G7688』/outbreak/g
s/『G7689』/a breaking/g
s/『G7690』/brought up/g
s/『G7691』/wailing/g
s/『G7692』/be a common topic/g
s/『G7693』/a common topic/g
s/『G7694』/a hand-mill/g
s/『G7695』/an incense pan/g
s/『G7696』/a purse/g
s/『G7697』/an offering; sacrifice/g
s/『G7698』/inclined to rage/g
s/『G7699』/a doorway/g
s/『G7700』/to sacrifice/g
s/『G7701』/a sacrifice/g
s/『G7702』/thanksgiving/g
s/『G7703』/mules/g
s/『G7704』/a healer/g
s/『G7705』/healing/g
s/『G7706』/a physician's fee/g
s/『G7707』/to treat; medically/g
s/『G7708』/an ibis/g
s/『G7709』/ham/g
s/『G7710』/to adopt/g
s/『G7711』/to secure/g
s/『G7712』/a hawk/g
s/『G7713』/fittingly/g
s/『G7714』/to entreat/g
s/『G7715』/a supplicant/g
s/『G7716』/jaundice/g
s/『G7717』/a kite/g
s/『G7718』/to make happy/g
s/『G7719』/happily/g
s/『G7720』/slime/g
s/『G7721』/keeper of cloaks/g
s/『G7722』/an effigy/g
s/『G7723』/a fowler/g
s/『G7724』/in hebrew; in Jewish language/g
s/『G7725』/to ride a horse/g
s/『G7726』/a commander of cavalry/g
s/『G7727』/riding/g
s/『G7728』/to ride horseback/g
s/『G7729』/course of horses/g
s/『G7730』/to make equal/g
s/『G7731』/to establish/g
s/『G7732』/a shroud/g
s/『G7733』/a mast/g
s/『G7734』/a hip/g
s/『G7735』/weak voiced/g
s/『G7736』/to strengthen/g
s/『G7737』/strongly/g
s/『G7738』/audacity/g
s/『G7739』/audacious/g
s/『G7740』/willow/g
s/『G7741』/of fish/g
s/『G7742』/fishing/g
s/『G7743』/to prowl/g
s/『G7744』/pus/g
s/『G7745』/a ram/g
s/『G7746』/a cab measure/g
s/『G7747』/stream of antiquity/g
s/『G7748』/male prostitutes/g
s/『G7749』/a canteen/g
s/『G7750』/a pail/g
s/『G7751』/to consecrate/g
s/『G7752』/be clean/g
s/『G7753』/cleanliness/g
s/『G7754』/a cleansing/g
s/『G7755』/a necklace/g
s/『G7756』/to nail up/g
s/『G7757』/sweating/g
s/『G7758』/to sit down/g
s/『G7759』/sitting/g
s/『G7760』/to direct/g
s/『G7761』/a return/g
s/『G7762』/to promise; solemnly promise/g
s/『G7763』/a hanging necklace/g
s/『G7764』/to insult/g
s/『G7765』/to sing praise/g
s/『G7766』/to sleep; be sound asleep/g
s/『G7767』/be late/g
s/『G7768』/to interweave/g
s/『G7769』/to revive/g
s/『G7770』/timely/g
s/『G7771』/an evil deed/g
s/『G7772』/evil actions/g
s/『G7773』/evil thinking/g
s/『G7774』/evil-minded/g
s/『G7775』/a newt/g
s/『G7776』/a reed basket/g
s/『G7777』/to glean/g
s/『G7778』/of reed/g
s/『G7779』/a branch/g
s/『G7780』/to beautify/g
s/『G7781』/beauty/g
s/『G7782』/beauty/g
s/『G7783』/a palm branch/g
s/『G7784』/to bedeck/g
s/『G7785』/rope/g
s/『G7786』/a lid/g
s/『G7787』/rope/g
s/『G7788』/a vault/g
s/『G7789』/giraffe/g
s/『G7790』/of a furnace/g
s/『G7791』/a curve/g
s/『G7792』/curved/g
s/『G7793』/beetle/g
s/『G7794』/a bin/g
s/『G7795』/a peddler/g
s/『G7796』/to smoke/g
s/『G7797』/caper/g
s/『G7798』/to take heart/g
s/『G7799』/to stupefy/g
s/『G7800』/of cotton/g
s/『G7801』/to gather fruit/g
s/『G7802』/fruitful/g
s/『G7803』/fruit-bearing/g
s/『G7804』/wrist/g
s/『G7805』/to yield/g
s/『G7806』/a yield/g
s/『G7807』/a yield/g
s/『G7808』/with long sleeves/g
s/『G7809』/a narrow bottomed basket/g
s/『G7810』/to strengthen/g
s/『G7811』/a walnut/g
s/『G7812』/of walnut/g
s/『G7813』/nut-like/g
s/『G7814』/a walnut/g
s/『G7815』/a walnut shaped knob/g
s/『G7816』/cassia/g
s/『G7817』/of tin/g
s/『G7818』/tin/g
s/『G7819』/by tracks/g
s/『G7820』/to constrain/g
s/『G7821』/to spend one's life/g
s/『G7822』/to look down/g
s/『G7823』/to yell out against/g
s/『G7824』/to graze upon/g
s/『G7825』/a thing devoured/g
s/『G7826』/a thing devoured/g
s/『G7827』/to devour/g
s/『G7828』/on the ground/g
s/『G7829』/laughter/g
s/『G7830』/become aged/g
s/『G7831』/to occupy/g
s/『G7832』/to introduce/g
s/『G7833』/to beseech earnestly/g
s/『G7834』/a bandage/g
s/『G7835』/to appreciate/g
s/『G7836』/to divide/g
s/『G7837』/to converse with/g
s/『G7838』/tyranny/g
s/『G7839』/a retreat/g
s/『G7840』/to descend into/g
s/『G7841』/to rely upon with confidence/g
s/『G7842』/to break in pieces/g
s/『G7843』/wishes/g
s/『G7844』/a blast/g
s/『G7845』/an overcovering/g
s/『G7846』/to bend down/g
s/『G7847』/fruitful/g
s/『G7848』/fruitfully/g
s/『G7849』/incinerated remains/g
s/『G7850』/a burning/g
s/『G7851』/to empty/g
s/『G7852』/to pierce through/g
s/『G7853』/to allot/g
s/『G7854』/to choose by lot/g
s/『G7855』/a divan/g
s/『G7856』/to strike with a fist/g
s/『G7857』/to run through/g
s/『G7858』/exhausted/g
s/『G7859』/to adorn/g
s/『G7860』/to hold firmly/g
s/『G7861』/to hide/g
s/『G7862』/to acquire/g
s/『G7863』/to encircle/g
s/『G7864』/to roll downward/g
s/『G7865』/a remnant/g
s/『G7866』/to grind down/g
s/『G7867』/a taking/g
s/『G7868』/to cast a stone at/g
s/『G7869』/inlaid with precious stone/g
s/『G7870』/to leave behind/g
s/『G7871』/to reckon/g
s/『G7872』/classification/g
s/『G7873』/distribution/g
s/『G7874』/a resting-place/g
s/『G7875』/to divide among/g
s/『G7876』/to measure out/g
s/『G7877』/to mix with/g
s/『G7878』/to deride/g
s/『G7879』/to feed on/g
s/『G7880』/to stand against/g
s/『G7881』/an arrival/g
s/『G7882』/to rend in shreds/g
s/『G7883』/to totally dry up/g
s/『G7884』/dried up/g
s/『G7885』/to mock/g
s/『G7886』/to deal treacherously/g
s/『G7887』/to strew/g
s/『G7888』/trampling/g
s/『G7889』/trampling/g
s/『G7890』/to mend/g
s/『G7891』/to mourn/g
s/『G7892』/to fly down/g
s/『G7893』/to fasten down/g
s/『G7894』/to leap down/g
s/『G7895』/very bitter/g
s/『G7896』/to confide in/g
s/『G7897』/to plaster/g
s/『G7898』/a terror/g
s/『G7899』/to strike with terror/g
s/『G7900』/to make war against/g
s/『G7901』/drowning/g
s/『G7902』/to soothe/g
s/『G7903』/to carry away captive/g
s/『G7904』/be struck with awe/g
s/『G7905』/a ruin/g
s/『G7906』/a curse/g
s/『G7907』/to break down/g
s/『G7908』/to silver plate/g
s/『G7909』/a dungeon/g
s/『G7910』/to stagger/g
s/『G7911』/to flow down/g
s/『G7912』/to break down/g
s/『G7913』/to hurl down/g
s/『G7914』/to rule/g
s/『G7915』/to extinguish/g
s/『G7916』/to observe silence/g
s/『G7917』/to observe silence/g
s/『G7918』/to scatter upon/g
s/『G7919』/to survey/g
s/『G7920』/apparatus/g
s/『G7921』/shady/g
s/『G7922』/to reduce/g
s/『G7923』/to live wastefully/g
s/『G7924』/to tear down/g
s/『G7925』/to scatter abroad/g
s/『G7926』/to hasten/g
s/『G7927』/to take seriously/g
s/『G7928』/to revolt/g
s/『G7929』/to groan/g
s/『G7930』/to firmly fix/g
s/『G7931』/to make drop/g
s/『G7932』/to bivouac/g
s/『G7933』/to delegate/g
s/『G7934』/to violently strain/g
s/『G7935』/to mutilate/g
s/『G7936』/to delight/g
s/『G7937』/to dissolve/g
s/『G7938』/to pull about/g
s/『G7939』/to wear away/g
s/『G7940』/to revel/g
s/『G7941』/to devour/g
s/『G7942』/to attain/g
s/『G7943』/to appear/g
s/『G7944』/inclined/g
s/『G7945』/to fall upon unawares/g
s/『G7946』/corruption/g
s/『G7947』/to burn up/g
s/『G7948』/to ignite/g
s/『G7949』/fear/g
s/『G7950』/a refuge/g
s/『G7951』/a planting/g
s/『G7952』/to plant/g
s/『G7953』/to rejoice against/g
s/『G7954』/to let down/g
s/『G7955』/to braze/g
s/『G7956』/to besmear/g
s/『G7957』/abounding in gold/g
s/『G7958』/to gild/g
s/『G7959』/a throwing down/g
s/『G7960』/to heap upon/g
s/『G7961』/to set down in writing/g
s/『G7962』/to look down/g
s/『G7963』/an accuser/g
s/『G7964』/to coerce/g
s/『G7965』/to denounce/g
s/『G7966』/working out/g
s/『G7967』/upkeep/g
s/『G7968』/straightway/g
s/『G7969』/to greatly prosper/g
s/『G7970』/habitation/g
s/『G7971』/to build/g
s/『G7972』/an inhabitant/g
s/『G7973』/be arrogant/g
s/『G7974』/after/g
s/『G7975』/a mirror/g
s/『G7976』/to keep straight/g
s/『G7977』/a success/g
s/『G7978』/to bury/g
s/『G7979』/to treat despitefully/g
s/『G7980』/to mate/g
s/『G7981』/possession/g
s/『G7982』/a hold/g
s/『G7983』/to afflict grievously/g
s/『G7984』/in severe pain/g
s/『G7985』/from below/g
s/『G7986』/a stem/g
s/『G7987』/a jar/g
s/『G7988』/millet/g
s/『G7989』/of cedar/g
s/『G7990』/secretly/g
s/『G7991』/to use empty words/g
s/『G7992』/a statue/g
s/『G7993』/to sting/g
s/『G7994』/being easily led on/g
s/『G7995』/a mixture/g
s/『G7996』/a horned serpent/g
s/『G7997』/to butt/g
s/『G7998』/a horn/g
s/『G7999』/goring/g
s/『G8000』/a thunderbolt/g
s/『G8001』/to strike with a thunderbolt/g
s/『G8002』/a tail/g
s/『G8003』/mischievous/g
s/『G8004』/a basin/g
s/『G8005』/a basin/g
s/『G8006』/to spot/g
s/『G8007』/a muzzle/g
s/『G8008』/beeswax/g
s/『G8009』/commingled/g
s/『G8010』/a turban/g
s/『G8011』/a lute/g
s/『G8012』/to dilute/g
s/『G8013』/to crave for strange food/g
s/『G8014』/to lend/g
s/『G8015』/a monumental pillar/g
s/『G8016』/a place of weeping/g
s/『G8017』/a bolt/g
s/『G8018』/to prognosticate/g
s/『G8019』/prognosticating/g
s/『G8020』/a small vine branch/g
s/『G8021』/an allotment/g
s/『G8022』/to allot/g
s/『G8023』/by casting lots/g
s/『G8024』/a step/g
s/『G8025』/a stairway/g
s/『G8026』/a corner/g
s/『G8027』/a neck yoke/g
s/『G8028』/to ransack/g
s/『G8029』/to twine/g
s/『G8030』/a branch/g
s/『G8031』/yarn/g
s/『G8032』/spun/g
s/『G8033』/shank/g
s/『G8034』/a leg covering/g
s/『G8035』/itching/g
s/『G8036』/nettle/g
s/『G8037』/to pick/g
s/『G8038』/a cavity/g
s/『G8039』/a ship's hold/g
s/『G8040』/hollow/g
s/『G8041』/to vault/g
s/『G8042』/vaulted/g
s/『G8043』/a hollow/g
s/『G8044』/to rest/g
s/『G8045』/to lay in bed/g
s/『G8046』/a laying with/g
s/『G8047』/to crush/g
s/『G8048』/to flatter/g
s/『G8049』/a gourd/g
s/『G8050』/to chisel/g
s/『G8051』/a sheath/g
s/『G8052』/glue/g
s/『G8053』/to bake biscuits/g
s/『G8054』/a biscuit/g
s/『G8055』/tailless/g
s/『G8056』/splitmouth/g
s/『G8057』/a gourd/g
s/『G8058』/recess/g
s/『G8059』/a drinking cup/g
s/『G8060』/to smite/g
s/『G8061』/ill-treatment/g
s/『G8062』/lime/g
s/『G8063』/whitewash/g
s/『G8064』/a shaft/g
s/『G8065』/a briar/g
s/『G8066』/to pound out/g
s/『G8067』/to trouble/g
s/『G8068』/dung/g
s/『G8069』/weariness/g
s/『G8070』/pupil/g
s/『G8071』/coriander/g
s/『G8072』/a truncheon/g
s/『G8073』/head/g
s/『G8074』/a crowbar/g
s/『G8075』/a fringe/g
s/『G8076』/fringed/g
s/『G8077』/a small cup/g
s/『G8078』/shearing/g
s/『G8079』/a barber/g
s/『G8080』/light \(in weight\)/g
s/『G8081』/nimbly/g
s/『G8082』/a pebble/g
s/『G8083』/be dizzy from wine/g
s/『G8084』/mixed wine/g
s/『G8085』/force/g
s/『G8086』/fortification/g
s/『G8087』/forcefully/g
s/『G8088』/fortification/g
s/『G8089』/a basin/g
s/『G8090』/a meat hook/g
s/『G8091』/to dress meat/g
s/『G8092』/hanging/g
s/『G8093』/a fountain/g
s/『G8094』/a bank/g
s/『G8095』/a hook/g
s/『G8096』/a ram/g
s/『G8097』/woof/g
s/『G8098』/crocodile/g
s/『G8099』/saffron/g
s/『G8100』/onion/g
s/『G8101』/a border/g
s/『G8102』/bordered fringes/g
s/『G8103』/temple/g
s/『G8104』/to clap/g
s/『G8105』/secretly/g
s/『G8106』/secretly/g
s/『G8107』/private/g
s/『G8108』/to slay/g
s/『G8109』/grazing cattle/g
s/『G8110』/brutish/g
s/『G8111』/a possession/g
s/『G8112』/a cup/g
s/『G8113』/a bean/g
s/『G8114』/to devise/g
s/『G8115』/a cube/g
s/『G8116』/an uproar/g
s/『G8117』/dignity/g
s/『G8118』/conception/g
s/『G8119』/a swirl/g
s/『G8120』/swan/g
s/『G8121』/to swell up/g
s/『G8122』/a waved border/g
s/『G8123』/play cymbals/g
s/『G8124』/to hunt with hounds/g
s/『G8125』/a hunter with hounds/g
s/『G8126』/churlish/g
s/『G8127』/the dog-fly/g
s/『G8128』/be with child/g
s/『G8129』/of cypress/g
s/『G8130』/cypress/g
s/『G8131』/to blossom/g
s/『G8132』/a blossom/g
s/『G8133』/humpback/g
s/『G8134』/extent/g
s/『G8135』/to have downcast eyes/g
s/『G8136』/a granary/g
s/『G8137』/to sire/g
s/『G8138』/a bell/g
s/『G8139』/toasting/g
s/『G8140』/to toast/g
s/『G8141』/a hind quarter/g
s/『G8142』/a restraint/g
s/『G8143』/a magistrate/g
s/『G8144』/an oar/g
s/『G8145』/an oarsman/g
s/『G8146』/be silent/g
s/『G8147』/be mute/g
s/『G8148』/a handle/g
s/『G8149』/a tong/g
s/『G8150』/fierce/g
s/『G8151』/a pancake/g
s/『G8152』/clandestinely/g
s/『G8153』/private/g
s/『G8154』/a pit/g
s/『G8155』/a discussion/g
s/『G8156』/power of speech/g
s/『G8157』/an oil lamp bowl/g
s/『G8158』/a covered royal chariot/g
s/『G8159』/like a covered chariot/g
s/『G8160』/a torch/g
s/『G8161』/a stone chisel/g
s/『G8162』/to dress stone/g
s/『G8163』/to lap/g
s/『G8164』/gull/g
s/『G8165』/quarried/g
s/『G8166』/a quarrier/g
s/『G8167』/servile/g
s/『G8168』/bounty/g
s/『G8169』/vegetables/g
s/『G8170』/lioness/g
s/『G8171』/to grind/g
s/『G8172』/a kettle/g
s/『G8173』/ministration/g
s/『G8174』/ministration/g
s/『G8175』/scabbed/g
s/『G8176』/to lick/g
s/『G8177』/a pan/g
s/『G8178』/form of speech/g
s/『G8179』/to peel/g
s/『G8180』/a peel/g
s/『G8181』/become leprous/g
s/『G8182』/become leprous/g
s/『G8183』/to make fine/g
s/『G8184』/rind/g
s/『G8185』/intrigue/g
s/『G8186』/be white/g
s/『G8187』/white poplar/g
s/『G8188』/a smooth rock/g
s/『G8189』/a concern/g
s/『G8190』/a band of robbers/g
s/『G8191』/amber/g
s/『G8192』/to cut stones/g
s/『G8193』/stonecutting/g
s/『G8194』/a winnower/g
s/『G8195』/a winnowing shovel/g
s/『G8196』/lima/g
s/『G8197』/to cause to hunger/g
s/『G8198』/to famish/g
s/『G8199』/be famished/g
s/『G8200』/of flaxen linen/g
s/『G8201』/a stalk of flax/g
s/『G8202』/to anoint/g
s/『G8203』/fatness/g
s/『G8204』/to implore/g
s/『G8205』/to implore/g
s/『G8206』/cheap/g
s/『G8207』/a lobe/g
s/『G8208』/reviling/g
s/『G8209』/to injure/g
s/『G8210』/a bathing tub/g
s/『G8211』/a bathhouse/g
s/『G8212』/a ridge/g
s/『G8213』/to give birth/g
s/『G8214』/distressing/g
s/『G8215』/a hem/g
s/『G8216』/by!/g
s/『G8217』/a number/g
s/『G8218』/a cooking place/g
s/『G8219』/to cut up meat/g
s/『G8220』/a female cook/g
s/『G8221』/a male cook/g
s/『G8222』/a loaf/g
s/『G8223』/loose of hair/g
s/『G8224』/to pluck hair/g
s/『G8225』/a harp/g
s/『G8226』/mazuroth/g
s/『G8227』/a lesson/g
s/『G8228』/a midwife/g
s/『G8229』/be irresistibly led/g
s/『G8230』/to act as midwife/g
s/『G8231』/most blessed/g
s/『G8232』/long-lived/g
s/『G8233』/to prolong one's days/g
s/『G8234』/many days/g
s/『G8235』/lenient/g
s/『G8236』/duration/g
s/『G8237』/to live a long time/g
s/『G8238』/abomination/g
s/『G8239』/prolong/g
s/『G8240』/by all means/g
s/『G8241』/a dressing/g
s/『G8242』/be infirm/g
s/『G8243』/to soften/g
s/『G8244』/softly/g
s/『G8245』/manna/g
s/『G8246』/a gift/g
s/『G8247』/haven/g
s/『G8248』/mandrake/g
s/『G8249』/a uniform/g
s/『G8250』/mane/g
s/『G8251』/a golden necklace/g
s/『G8252』/divination/g
s/『G8253』/an oracle/g
s/『G8254』/a clairvoyant/g
s/『G8255』/of marble/g
s/『G8256』/a money bag/g
s/『G8257』/a bag/g
s/『G8258』/second section/g
s/『G8259』/a snuffer/g
s/『G8260』/acting in folly/g
s/『G8261』/a rag/g
s/『G8262』/food/g
s/『G8263』/a warrior/g
s/『G8264』/combat/g
s/『G8265』/a fortress/g
s/『G8266』/majesty/g
s/『G8267』/having large wings/g
s/『G8268』/to speak great words/g
s/『G8269』/lofty language/g
s/『G8270』/lofty speaking/g
s/『G8271』/fleshy/g
s/『G8272』/high-minded/g
s/『G8273』/magnificence/g
s/『G8274』/to use craft/g
s/『G8275』/strong drink/g
s/『G8276』/a genealogical register/g
s/『G8277』/a ridge/g
s/『G8278』/to arch over/g
s/『G8279』/pepperwort/g
s/『G8280』/to blacken/g
s/『G8281』/meditation/g
s/『G8282』/to dismember/g
s/『G8283』/bee/g
s/『G8284』/an apiary/g
s/『G8285』/complaint/g
s/『G8286』/however/g
s/『G8287』/to partition/g
s/『G8288』/middle/g
s/『G8289』/a weaver's beam/g
s/『G8290』/midday/g
s/『G8291』/a wardrobe/g
s/『G8292』/purple ornamentation/g
s/『G8293』/a garrison/g
s/『G8294』/revolt/g
s/『G8295』/a trader/g
s/『G8296』/removal/g
s/『G8297』/to mine/g
s/『G8298』/repentance/g
s/『G8299』/regret/g
s/『G8300』/to migrate/g
s/『G8301』/to change residence/g
s/『G8302』/to degenerate/g
s/『G8303』/to fashion differently/g
s/『G8304』/converted/g
s/『G8305』/the upper back/g
s/『G8306』/to pass between the ranks/g
s/『G8307』/a crest/g
s/『G8308』/a meteorite/g
s/『G8309』/to displace/g
s/『G8310』/displacement/g
s/『G8311』/a refugee/g
s/『G8312』/a measuring/g
s/『G8313』/be content/g
s/『G8314』/a base/g
s/『G8315』/neither one/g
s/『G8316』/cheeks/g
s/『G8317』/of a month/g
s/『G8318』/vehement anger/g
s/『G8319』/a crescent/g
s/『G8320』/be infuriated/g
s/『G8321』/the thigh/g
s/『G8322』/to chew the cud/g
s/『G8323』/chewing the cud/g
s/『G8324』/to furl/g
s/『G8325』/to construct/g
s/『G8326』/a machine/g
s/『G8327』/defilement/g
s/『G8328』/thinness/g
s/『G8329』/vermilion/g
s/『G8330』/to mingle/g
s/『G8331』/detested/g
s/『G8332』/hatred/g
s/『G8333』/a mitre/g
s/『G8334』/a memorandum/g
s/『G8335』/to resent/g
s/『G8336』/resentful/g
s/『G8337』/lead/g
s/『G8338』/a mallow \(plant\)/g
s/『G8339』/contamination/g
s/『G8340』/to live alone/g
s/『G8341』/a stable/g
s/『G8342』/a wild boar/g
s/『G8343』/lightly armed/g
s/『G8344』/a unicorn/g
s/『G8345』/to fight one on one/g
s/『G8346』/having one testicle/g
s/『G8347』/simple/g
s/『G8348』/sheepfolds/g
s/『G8349』/a young calf/g
s/『G8350』/to dress a wound/g
s/『G8351』/to make an effort/g
s/『G8352』/a bar/g
s/『G8353』/a field-mouse/g
s/『G8354』/to fill with marrow/g
s/『G8355』/a fly/g
s/『G8356』/nostril/g
s/『G8357』/sneering/g
s/『G8358』/a molar tooth/g
s/『G8359』/a tube/g
s/『G8360』/scented/g
s/『G8361』/a perfumer/g
s/『G8362』/ten thousand-fold/g
s/『G8363』/be troubled with warts/g
s/『G8364』/a small lion/g
s/『G8365』/an ant/g
s/『G8366』/a myrtle tree/g
s/『G8367』/a mouse/g
s/『G8368』/detestable/g
s/『G8369』/a mustache/g
s/『G8370』/to scorn/g
s/『G8371』/scoffing/g
s/『G8372』/a stringed instrument/g
s/『G8373』/to inhabit/g
s/『G8374』/juice/g
s/『G8375』/a grove/g
s/『G8376』/be paralyzed/g
s/『G8377』/fare/g
s/『G8378』/mariner/g
s/『G8379』/a young woman/g
s/『G8380』/a hide flask/g
s/『G8381』/a fawn/g
s/『G8382』/ostriches/g
s/『G8383』/a diadem/g
s/『G8384』/altercation/g
s/『G8385』/to feed/g
s/『G8386』/to plow fallow land/g
s/『G8387』/feathers/g
s/『G8388』/a beckon/g
s/『G8389』/the bow string/g
s/『G8390』/to hamstring/g
s/『G8391』/a nerve/g
s/『G8392』/spices/g
s/『G8393』/a field prepared for plowing/g
s/『G8394』/infancy/g
s/『G8395』/spun/g
s/『G8396』/to bring success/g
s/『G8397』/Nisan/g
s/『G8398』/bleach/g
s/『G8399』/snowflakes/g
s/『G8400』/intelligent/g
s/『G8401』/intelligible/g
s/『G8402』/feeding/g
s/『G8403』/laws/g
s/『G8404』/lawfully/g
s/『G8405』/abode/g
s/『G8406』/diseased/g
s/『G8407』/to nest/g
s/『G8408』/to build a nest/g
s/『G8409』/a load carrier/g
s/『G8410』/admonition/g
s/『G8411』/admonition/g
s/『G8412』/nightly/g
s/『G8413』/a bat/g
s/『G8414』/an owl/g
s/『G8415』/groomsman/g
s/『G8416』/a betrothing/g
s/『G8417』/a slumbering/g
s/『G8418』/a slumber/g
s/『G8419』/dull of heart/g
s/『G8420』/a shepherd/g
s/『G8421』/60/g
s/『G8422』/be yellowish/g
s/『G8423』/gifts/g
s/『G8424』/hospitality/g
s/『G8425』/dryness/g
s/『G8426』/a knife-blade/g
s/『G8427』/a stick/g
s/『G8428』/a woodcutter/g
s/『G8429』/bearing wood/g
s/『G8430』/a wood bearer/g
s/『G8431』/to board/g
s/『G8432』/a double-horse chariot/g
s/『G8433』/shaving/g
s/『G8434』/a razor/g
s/『G8435』/planed/g
s/『G8436』/to scrape/g
s/『G8437』/a point/g
s/『G8438』/a obolus/g
s/『G8439』/eighty-six/g
s/『G8440』/eighty-five/g
s/『G8441』/eighty-four/g
s/『G8442』/eighty-three/g
s/『G8443』/eightieth/g
s/『G8444』/a traveler/g
s/『G8445』/to open a way/g
s/『G8446』/grievous/g
s/『G8447』/to grieve/g
s/『G8448』/to steer/g
s/『G8449』/intimacy/g
s/『G8450』/a female domestic servant/g
s/『G8451』/place of abode/g
s/『G8452』/inhabited/g
s/『G8453』/an inhabitant/g
s/『G8454』/to resettle/g
s/『G8455』/niche/g
s/『G8456』/a native-born servant/g
s/『G8457』/an area/g
s/『G8458』/pitying/g
s/『G8459』/a lament/g
s/『G8460』/pitiable/g
s/『G8461』/alas!/g
s/『G8462』/to drink wine/g
s/『G8463』/be drunk with wine/g
s/『G8464』/a female wine server/g
s/『G8465』/a male wine server/g
s/『G8466』/be drunk with wine/g
s/『G8467』/an ephah/g
s/『G8468』/be undone/g
s/『G8469』/to foretell/g
s/『G8470』/an omen/g
s/『G8471』/an omen/g
s/『G8472』/an omen/g
s/『G8473』/to kneel/g
s/『G8474』/slothful/g
s/『G8475』/eight thousand/g
s/『G8476』/eight hundred/g
s/『G8477』/eight cubits/g
s/『G8478』/eighteen/g
s/『G8479』/eighteenth/g
s/『G8480』/pernicious/g
s/『G8481』/to destroy/g
s/『G8482』/short-lived/g
s/『G8483』/very few/g
s/『G8484』/fewness/g
s/『G8485』/be faint-hearted/g
s/『G8486』/faint-heartedness/g
s/『G8487』/to lessen/g
s/『G8488』/to slip/g
s/『G8489』/a slip/g
s/『G8490』/a scale-weight/g
s/『G8491』/to destroy/g
s/『G8492』/a whole offering/g
s/『G8493』/a whole offering/g
s/『G8494』/wholly burnt/g
s/『G8495』/bringing of a whole burnt-offering/g
s/『G8496』/shrieking of women/g
s/『G8497』/entirely of purple/g
s/『G8498』/entirely from a root/g
s/『G8499』/soundly/g
s/『G8500』/a wild oat/g
s/『G8501』/of oaten bread/g
s/『G8502』/to level/g
s/『G8503』/leveling/g
s/『G8504』/a shower/g
s/『G8505』/a security treaty/g
s/『G8506』/confessedly/g
s/『G8507』/born of the same mother/g
s/『G8508』/to consent/g
s/『G8509』/concord/g
s/『G8510』/of the same father/g
s/『G8511』/to adjoin/g
s/『G8512』/adjoining/g
s/『G8513』/be sour/g
s/『G8514』/anavel/g
s/『G8515』/an unripe grape/g
s/『G8516』/a wild donkey/g
s/『G8517』/a scorning/g
s/『G8518』/profitable/g
s/『G8519』/a satyr/g
s/『G8520』/famous/g
s/『G8521』/a claw/g
s/『G8522』/to claw/g
s/『G8523』/onyx/g
s/『G8524』/cloven-footed/g
s/『G8525』/swiftly/g
s/『G8526』/writing fast/g
s/『G8527』/quick to rage/g
s/『G8528』/to sharpen/g
s/『G8529』/swift/g
s/『G8530』/a shoemaker's awl/g
s/『G8531』/posterior/g
s/『G8532』/backwardly/g
s/『G8533』/convulsion/g
s/『G8534』/backwards/g
s/『G8535』/a hoof/g
s/『G8536』/armed with a large shield/g
s/『G8537』/an armory/g
s/『G8538』/an armed warrior/g
s/『G8539』/an armor-bearer/g
s/『G8540』/to behold/g
s/『G8541』/to bake/g
s/『G8542』/a storehouse of fruits/g
s/『G8543』/an observer/g
s/『G8544』/observant/g
s/『G8545』/an instrument/g
s/『G8546』/be straight up/g
s/『G8547』/enactment/g
s/『G8548』/a conjuring/g
s/『G8549』/pendant/g
s/『G8550』/a mooring/g
s/『G8551』/a small bird/g
s/『G8552』/to use augury/g
s/『G8553』/a scion/g
s/『G8554』/a confirmation/g
s/『G8555』/roofing/g
s/『G8556』/a mother-quail/g
s/『G8557』/a gazelle/g
s/『G8558』/bereavement/g
s/『G8559』/be sacred/g
s/『G8560』/whatsoever/g
s/『G8561』/a potsherd/g
s/『G8562』/to savor/g
s/『G8563』/a smell/g
s/『G8564』/not at all/g
s/『G8565』/neither/g
s/『G8566』/a discoloration/g
s/『G8567』/a rear guard/g
s/『G8568』/to urinate/g
s/『G8569』/a rotten egg/g
s/『G8570』/urine/g
s/『G8571』/clear to the eyes/g
s/『G8572』/a crawling locust/g
s/『G8573』/a riverbank/g
s/『G8574』/rioting/g
s/『G8575』/fortified/g
s/『G8576』/to fortify/g
s/『G8577』/to arrive late/g
s/『G8578』/fish/g
s/『G8579』/icy coldness/g
s/『G8580』/ice/g
s/『G8581』/a mourner/g
s/『G8582』/play/g
s/『G8583』/a plaything/g
s/『G8584』/a dried cluster/g
s/『G8585』/a palm \(plant\)/g
s/『G8586』/to wrestle/g
s/『G8587』/that which has grown old/g
s/『G8588』/that which has grown old/g
s/『G8589』/a concubine/g
s/『G8590』/a concubine/g
s/『G8591』/agitated/g
s/『G8592』/abundant herbage/g
s/『G8593』/in full assembly/g
s/『G8594』/to assemble for a festival/g
s/『G8595』/a panther/g
s/『G8596』/whole family/g
s/『G8597』/to trick/g
s/『G8598』/of all kinds/g
s/『G8599』/papyrus \(plant\)/g
s/『G8600』/deeply dyed/g
s/『G8601』/to cast aside/g
s/『G8602』/to look over/g
s/『G8603』/a mobilization order/g
s/『G8604』/a scraper/g
s/『G8605』/a carpenter's square/g
s/『G8606』/a model/g
s/『G8607』/to hold forth as an example/g
s/『G8608』/to do an incredible thing/g
s/『G8609』/a passing by/g
s/『G8610』/a sash/g
s/『G8611』/to overheat/g
s/『G8612』/provision/g
s/『G8613』/to press against/g
s/『G8614』/to lift from/g
s/『G8615』/to sit near/g
s/『G8616』/to deposit in care of/g
s/『G8617』/to rouse/g
s/『G8618』/comforting/g
s/『G8619』/a comforter/g
s/『G8620』/a mistress/g
s/『G8621』/to cheat/g
s/『G8622』/to speak improperly/g
s/『G8623』/alteration/g
s/『G8624』/to alter/g
s/『G8625』/paralysis/g
s/『G8626』/to uselessly consume/g
s/『G8627』/a lawbreaker/g
s/『G8628』/unlawfully/g
s/『G8629』/a dagger/g
s/『G8630』/thoroughly/g
s/『G8631』/a canopy/g
s/『G8632』/deranged/g
s/『G8633』/derangement/g
s/『G8634』/a transgression/g
s/『G8635』/to throw aside/g
s/『G8636』/a sheet of leather/g
s/『G8637』/to remain silent/g
s/『G8638』/position/g
s/『G8639』/to resemble/g
s/『G8640』/battle array/g
s/『G8641』/to deploy/g
s/『G8642』/be a bodyguard/g
s/『G8643』/ranting/g
s/『G8644』/a shoot/g
s/『G8645』/to attend upon/g
s/『G8646』/to ignore/g
s/『G8647』/to reach forth/g
s/『G8648』/a deferment/g
s/『G8649』/besides/g
s/『G8650』/to move out of place/g
s/『G8651』/marks of virginity/g
s/『G8652』/virgin/g
s/『G8653』/to present/g
s/『G8654』/to travel by/g
s/『G8655』/a sojourning/g
s/『G8656』/a sojourning/g
s/『G8657』/to insult while drunk with wine/g
s/『G8658』/be in heat/g
s/『G8659』/to overlook/g
s/『G8660』/provocation to anger/g
s/『G8661』/a shoulder strap/g
s/『G8662』/a peg/g
s/『G8663』/to strew/g
s/『G8664』/nuptial chamber/g
s/『G8665』/a chamber/g
s/『G8666』/trampled/g
s/『G8667』/trampled/g
s/『G8668』/an uncle/g
s/『G8669』/a patriarchal idol/g
s/『G8670』/of a father/g
s/『G8671』/cessation/g
s/『G8672』/frost/g
s/『G8673』/thickness/g
s/『G8674』/robust/g
s/『G8675』/to shackle/g
s/『G8676』/a plain/g
s/『G8677』/a footman/g
s/『G8678』/to maraud/g
s/『G8679』/a band of marauders/g
s/『G8680』/a marauder/g
s/『G8681』/a one near/g
s/『G8682』/pelican/g
s/『G8683』/to hew/g
s/『G8684』/hewn/g
s/『G8685』/a hewing axe/g
s/『G8686』/dark colored/g
s/『G8687』/be darkened/g
s/『G8688』/armed with a small shield/g
s/『G8689』/a small shield/g
s/『G8690』/a hewing axe/g
s/『G8691』/a cake/g
s/『G8692』/mournful/g
s/『G8693』/poverty/g
s/『G8694』/be in need/g
s/『G8695』/of five years/g
s/『G8696』/of five cubits/g
s/『G8697』/five-fold/g
s/『G8698』/five-fold way/g
s/『G8699』/fifteen/g
s/『G8700』/fifty-two/g
s/『G8701』/fifty-six/g
s/『G8702』/fifty-seven/g
s/『G8703』/fifty-five/g
s/『G8704』/fifty years/g
s/『G8705』/a commander of fifty/g
s/『G8706』/fifty-three/g
s/『G8707』/fifty-four/g
s/『G8708』/fiftieth/g
s/『G8709』/mature/g
s/『G8710』/securely/g
s/『G8711』/a melon/g
s/『G8712』/to achieve/g
s/『G8713』/a limit/g
s/『G8714』/a traveler/g
s/『G8715』/partridge/g
s/『G8716』/to silver plate/g
s/『G8717』/admired/g
s/『G8718』/a wrap-around/g
s/『G8719』/a wrap-around/g
s/『G8720』/an enclosure/g
s/『G8721』/be an advantage/g
s/『G8722』/to eat at a wake/g
s/『G8723』/a right armband/g
s/『G8724』/to grasp in the hands/g
s/『G8725』/to remain over/g
s/『G8726』/a loincloth/g
s/『G8727』/an adornment/g
s/『G8728』/to purge/g
s/『G8729』/to purge/g
s/『G8730』/to besiege/g
s/『G8731』/to besiege/g
s/『G8732』/to shave around/g
s/『G8733』/a legging/g
s/『G8734』/to adorn sumptuously/g
s/『G8735』/surrounding/g
s/『G8736』/to embrace/g
s/『G8737』/an embrace/g
s/『G8738』/residue/g
s/『G8739』/perimeter/g
s/『G8740』/to travel about/g
s/『G8741』/a circuit/g
s/『G8742』/to enclose/g
s/『G8743』/to trim nails/g
s/『G8744』/prized possession/g
s/『G8745』/a promenade/g
s/『G8746』/to twist/g
s/『G8747』/a township/g
s/『G8748』/objects edged with purple/g
s/『G8749』/sparks/g
s/『G8750』/by chance/g
s/『G8751』/to sprinkle about/g
s/『G8752』/to inlay/g
s/『G8753』/pants/g
s/『G8754』/to cover/g
s/『G8755』/distraction/g
s/『G8756』/outskirts/g
s/『G8757』/a surrounding space/g
s/『G8758』/to screen/g
s/『G8759』/a breast-plate/g
s/『G8760』/attire/g
s/『G8761』/a cleft/g
s/『G8762』/to move around/g
s/『G8763』/a peristyle/g
s/『G8764』/to tear away/g
s/『G8765』/to split/g
s/『G8766』/to wall around/g
s/『G8767』/a rampart/g
s/『G8768』/madness/g
s/『G8769』/circumference/g
s/『G8770』/deviation/g
s/『G8771』/to enclose/g
s/『G8772』/to brass plate/g
s/『G8773』/to surround with a rampart/g
s/『G8774』/overjoyed/g
s/『G8775』/to pour about/g
s/『G8776』/to gild/g
s/『G8777』/to grow dark/g
s/『G8778』/to bake/g
s/『G8779』/a leaf/g
s/『G8780』/to spread out/g
s/『G8781』/a perch/g
s/『G8782』/of rock/g
s/『G8783』/a slinger/g
s/『G8784』/pine tree/g
s/『G8785』/of pine/g
s/『G8786』/baking/g
s/『G8787』/a bank of water/g
s/『G8788』/to spring up/g
s/『G8789』/of clay/g
s/『G8790』/to fatten/g
s/『G8791』/ape/g
s/『G8792』/a cask/g
s/『G8793』/bitterness/g
s/『G8794』/a bitter herb/g
s/『G8795』/of mother of pearl/g
s/『G8796』/pitch/g
s/『G8797』/pine tree/g
s/『G8798』/plentiful/g
s/『G8799』/bend/g
s/『G8800』/sideways/g
s/『G8801』/a delusion/g
s/『G8802』/plane tree/g
s/『G8803』/an enlargement/g
s/『G8804』/very often/g
s/『G8805』/many times/g
s/『G8806』/surplus/g
s/『G8807』/usury/g
s/『G8808』/superabundant/g
s/『G8809』/advantage/g
s/『G8810』/a side/g
s/『G8811』/a trespass/g
s/『G8812』/to offend/g
s/『G8813』/a trespass/g
s/『G8814』/a trespass/g
s/『G8815』/a filling/g
s/『G8816』/dear one/g
s/『G8817』/making of bricks/g
s/『G8818』/to make bricks/g
s/『G8819』/a brick-kiln/g
s/『G8820』/a brick/g
s/『G8821』/brickmaking/g
s/『G8822』/wreathen/g
s/『G8823』/a braid/g
s/『G8824』/afloat/g
s/『G8825』/be carried by wind/g
s/『G8826』/carried by wind/g
s/『G8827』/lungs/g
s/『G8828』/herbage/g
s/『G8829』/to feel absence/g
s/『G8830』/embroidery/g
s/『G8831』/to embroidered/g
s/『G8832』/color/g
s/『G8833』/an embroiderer/g
s/『G8834』/embroidery/g
s/『G8835』/an embroidered work/g
s/『G8836』/variously/g
s/『G8837』/of a shepherd/g
s/『G8838』/fleece/g
s/『G8839』/warfare/g
s/『G8840』/warlike/g
s/『G8841』/a warrior/g
s/『G8842』/grayness of hair/g
s/『G8843』/to assault/g
s/『G8844』/an assault/g
s/『G8845』/gray hair/g
s/『G8846』/in many ways/g
s/『G8847』/a great deal/g
s/『G8848』/a cemetery/g
s/『G8849』/full of mercy/g
s/『G8850』/of many days/g
s/『G8851』/many ways/g
s/『G8852』/a great multitude/g
s/『G8853』/to manifoldly multiply/g
s/『G8854』/be numerous/g
s/『G8855』/to greatly multiply/g
s/『G8856』/crafty/g
s/『G8857』/talkative/g
s/『G8858』/prolific/g
s/『G8859』/to delay long/g
s/『G8860』/long-lived/g
s/『G8861』/to take great care/g
s/『G8862』/to suffer pain/g
s/『G8863』/to act wickedly/g
s/『G8864』/to pass through a sea/g
s/『G8865』/a trek/g
s/『G8866』/a place of harlotry/g
s/『G8867』/of a harlot/g
s/『G8868』/a whoremonger/g
s/『G8869』/of purple/g
s/『G8870』/purple-legged stork/g
s/『G8871』/how often/g
s/『G8872』/a drink/g
s/『G8873』/a channel/g
s/『G8874』/a beverage/g
s/『G8875』/leek colored/g
s/『G8876』/a sale/g
s/『G8877』/a leek/g
s/『G8878』/gentle-minded/g
s/『G8879』/to calm/g
s/『G8880』/senior/g
s/『G8881』/an ambassador/g
s/『G8882』/to bloat/g
s/『G8883』/to buy/g
s/『G8884』/toothed/g
s/『G8885』/a saw/g
s/『G8886』/a resolve/g
s/『G8887』/to prefer/g
s/『G8888』/to sprout up early/g
s/『G8889』/to forewarn/g
s/『G8890』/outskirts/g
s/『G8891』/an entrance approach/g
s/『G8892』/a riddle/g
s/『G8893』/to put forth first/g
s/『G8894』/to feel eager/g
s/『G8895』/a threshold/g
s/『G8896』/to let go/g
s/『G8897』/to post in front/g
s/『G8898』/be first to take/g
s/『G8899』/a wine press/g
s/『G8900』/a crop/g
s/『G8901』/a battlement/g
s/『G8902』/to despoil/g
s/『G8903』/plunder/g
s/『G8904』/a retort/g
s/『G8905』/a forefather/g
s/『G8906』/rashness/g
s/『G8907』/to fall down/g
s/『G8908』/a gateway/g
s/『G8909』/an ascent leading to/g
s/『G8910』/to die in addition/g
s/『G8911』/to strike up/g
s/『G8912』/amalgamated/g
s/『G8913』/unite with/g
s/『G8914』/acceptable/g
s/『G8915』/to give in addition/g
s/『G8916』/to look at/g
s/『G8917』/to say to/g
s/『G8918』/to burn besides/g
s/『G8919』/to set on fire besides/g
s/『G8920』/moreover/g
s/『G8921』/to convert/g
s/『G8922』/kind/g
s/『G8923』/an addition/g
s/『G8924』/an addition/g
s/『G8925』/to press to/g
s/『G8926』/be burnt through/g
s/『G8927』/to leave surplus/g
s/『G8928』/burnt/g
s/『G8929』/to join up with/g
s/『G8930』/a pillow/g
s/『G8931』/to rush upon/g
s/『G8932』/to count in addition to/g
s/『G8933』/to mingle with/g
s/『G8934』/to pay attention to/g
s/『G8935』/revenue/g
s/『G8936』/to give out an odor/g
s/『G8937』/to shut/g
s/『G8938』/a loathsome thing/g
s/『G8939』/aspect/g
s/『G8940』/to play before/g
s/『G8941』/to sprinkle on/g
s/『G8942』/to salivate upon/g
s/『G8943』/an order/g
s/『G8944』/an antechamber/g
s/『G8945』/a superintendent/g
s/『G8946』/to rejoice with/g
s/『G8947』/to pour on/g
s/『G8948』/a mound/g
s/『G8949』/to join with/g
s/『G8950』/area around a wall/g
s/『G8951』/honor/g
s/『G8952』/an upper part/g
s/『G8953』/to make an excuse/g
s/『G8954』/offered as an excuse/g
s/『G8955』/an advance guard/g
s/『G8956』/an advance guard/g
s/『G8957』/to keep guard over/g
s/『G8958』/beforehand/g
s/『G8959』/excrement/g
s/『G8960』/a day before/g
s/『G8961』/from morning/g
s/『G8962』/a captain/g
s/『G8963』/be seated first/g
s/『G8964』/to put forth first/g
s/『G8965』/first-born/g
s/『G8966』/first produce/g
s/『G8967』/first-ripe/g
s/『G8968』/beginning of speaking/g
s/『G8969』/to give a right of first-born/g
s/『G8970』/to give birth first time/g
s/『G8971』/fault/g
s/『G8972』/a sneezing/g
s/『G8973』/to stomp; catch by a heel/g
s/『G8974』/trickery/g
s/『G8975』/a feather/g
s/『G8976』/to grow wings/g
s/『G8977』/to flap wings/g
s/『G8978』/feathered/g
s/『G8979』/to alarm/g
s/『G8980』/hairless/g
s/『G8981』/spittle/g
s/『G8982』/fold/g
s/『G8983』/fold/g
s/『G8984』/to make poor/g
s/『G8985』/white-tailed hart/g
s/『G8986』/a lower branch/g
s/『G8987』/be dense/g
s/『G8988』/a gatekeeper/g
s/『G8989』/a writing tablet/g
s/『G8990』/boxwood/g
s/『G8991』/a towered fortification/g
s/『G8992』/a censer/g
s/『G8993』/scorched/g
s/『G8994』/wheat/g
s/『G8995』/a wheat harvest/g
s/『G8996』/fiery red/g
s/『G8997』/be reddish/g
s/『G8998』/to light a fire/g
s/『G8999』/a signal-fire/g
s/『G9000』/a fire-bearer/g
s/『G9001』/a refiner/g
s/『G9002』/a beard/g
s/『G9003』/a breach/g
s/『G9004』/a tender branch/g
s/『G9005』/broom shrub/g
s/『G9006』/be lazy/g
s/『G9007』/to sprinkle/g
s/『G9008』/ragged/g
s/『G9009』/thread/g
s/『G9010』/white-thorn/g
s/『G9011』/speckled/g
s/『G9012』/strung together/g
s/『G9013』/to sew/g
s/『G9014』/courier/g
s/『G9015』/to dash down/g
s/『G9016』/a stitcher/g
s/『G9017』/a stitched work/g
s/『G9018』/a spine/g
s/『G9019』/to snore/g
s/『G9020』/to stray/g
s/『G9021』/to stray/g
s/『G9022』/a saying/g
s/『G9023』/balm/g
s/『G9024』/in particular/g
s/『G9025』/shivering/g
s/『G9026』/a root/g
s/『G9027』/nostril/g
s/『G9028』/ventilated/g
s/『G9029』/a pomegranate/g
s/『G9030』/to gurgle/g
s/『G9031』/impetus/g
s/『G9032』/a pomegranate figure/g
s/『G9033』/a club/g
s/『G9034』/crux/g
s/『G9035』/a pomegranate grove/g
s/『G9036』/an overflow/g
s/『G9037』/to compose/g
s/『G9038』/a proportion/g
s/『G9039』/a rescuer/g
s/『G9040』/a perfumer/g
s/『G9041』/stone/g
s/『G9042』/6/g
s/『G9043』/to observe sabbaths/g
s/『G9044』/glory/g
s/『G9045』/a thicket/g
s/『G9046』/a packsaddle/g
s/『G9047』/Saddai/g
s/『G9048』/a plain/g
s/『G9049』/ranks/g
s/『G9050』/rotten/g
s/『G9051』/to disintegrate/g
s/『G9052』/a sambuke/g
s/『G9053』/planked/g
s/『G9054』/rottenness/g
s/『G9055』/to rot/g
s/『G9056』/pantaloons/g
s/『G9057』/a carnelian/g
s/『G9058』/a satrapy/g
s/『G9059』/satrap/g
s/『G9060』/a lizard/g
s/『G9061』/cheese/g
s/『G9062』/clearly/g
s/『G9063』/a siren/g
s/『G9064』/a spear/g
s/『G9065』/column/g
s/『G9066』/of three years/g
s/『G9067』/seraphim/g
s/『G9068』/a beet/g
s/『G9069』/a flag/g
s/『G9070』/a cheer/g
s/『G9071』/a signal/g
s/『G9072』/putrefaction/g
s/『G9073』/strength \(physical\)/g
s/『G9074』/a jawbone/g
s/『G9075』/quiet/g
s/『G9076』/an iron implement/g
s/『G9077』/saliva/g
s/『G9078』/a portion/g
s/『G9079』/a shekel/g
s/『G9080』/a cucumber garden/g
s/『G9081』/a cucumber/g
s/『G9082』/ornaments/g
s/『G9083』/a consecrated lock of hair/g
s/『G9084』/be well fed/g
s/『G9085』/a granary/g
s/『G9086』/scarcity/g
s/『G9087』/provision/g
s/『G9088』/to measure out grain/g
s/『G9089』/a baker/g
s/『G9090』/silence/g
s/『G9091』/a veil/g
s/『G9092』/to till/g
s/『G9093』/crooked/g
s/『G9094』/to trip up/g
s/『G9095』/to shelter/g
s/『G9096』/a hammer/g
s/『G9097』/a shelterer/g
s/『G9098』/a shelter/g
s/『G9099』/protected/g
s/『G9100』/to look about/g
s/『G9101』/a concoction/g
s/『G9102』/concocted/g
s/『G9103』/provisions officer/g
s/『G9104』/a chiefdom/g
s/『G9105』/an awning/g
s/『G9106』/to shade/g
s/『G9107』/hard-hearted/g
s/『G9108』/harsh/g
s/『G9109』/harshly/g
s/『G9110』/a midge/g
s/『G9111』/perverse/g
s/『G9112』/deformity/g
s/『G9113』/crookedly/g
s/『G9114』/a high rock/g
s/『G9115』/a height/g
s/『G9116』/garlic/g
s/『G9117』/to darken/g
s/『G9118』/moonlight/g
s/『G9119』/to look downcast/g
s/『G9120』/to despoil/g
s/『G9121』/a cub/g
s/『G9122』/a stave/g
s/『G9123』/an impediment/g
s/『G9124』/an emerald/g
s/『G9125』/beauty treatment/g
s/『G9126』/to diminish/g
s/『G9127』/a yew tree/g
s/『G9128』/an emery stone/g
s/『G9129』/of myrrh/g
s/『G9130』/a wise man/g
s/『G9131』/to give wisdom/g
s/『G9132』/wisely/g
s/『G9133』/a castrato/g
s/『G9134』/be depleted/g
s/『G9135』/sparingly/g
s/『G9136』/swaddling cloth/g
s/『G9137』/a cord/g
s/『G9138』/to conceive/g
s/『G9139』/a discharge of semen/g
s/『G9140』/a span/g
s/『G9141』/a spark/g
s/『G9142』/a pile of ashes/g
s/『G9143』/ashen/g
s/『G9144』/a libation bowl/g
s/『G9145』/a libation/g
s/『G9146』/a drop \(liquid\)/g
s/『G9147』/to drip/g
s/『G9148』/to measure by a rule/g
s/『G9149』/a scale-weight/g
s/『G9150』/a doorpost/g
s/『G9151』/dough/g
s/『G9152』/balsam/g
s/『G9153』/to trickle/g
s/『G9154』/a dried grape/g
s/『G9155』/fat/g
s/『G9156』/to grow fat/g
s/『G9157』/to roof/g
s/『G9158』/roofed/g
s/『G9159』/a stick/g
s/『G9160』/dregs/g
s/『G9161』/bemoaned/g
s/『G9162』/to moan/g
s/『G9163』/in a strait/g
s/『G9164』/straitness/g
s/『G9165』/hard-hearted/g
s/『G9166』/to deprive/g
s/『G9167』/to deprive/g
s/『G9168』/a rim/g
s/『G9169』/a breastband/g
s/『G9170』/a breast/g
s/『G9171』/a monument/g
s/『G9172』/an inscription on a monument/g
s/『G9173』/to set up a monument/g
s/『G9174』/a pillar/g
s/『G9175』/a warp/g
s/『G9176』/a reliance/g
s/『G9177』/dense/g
s/『G9178』/densely/g
s/『G9179』/antimony/g
s/『G9180』/to tinge with antimony/g
s/『G9181』/a mark/g
s/『G9182』/to brighten/g
s/『G9183』/shine/g
s/『G9184』/a row/g
s/『G9185』/to pile/g
s/『G9186』/a pile/g
s/『G9187』/to set in rows/g
s/『G9188』/to robe/g
s/『G9189』/a uniform/g
s/『G9190』/a keeper of wardrobe/g
s/『G9191』/to take thought/g
s/『G9192』/a thinker/g
s/『G9193』/perverseness/g
s/『G9194』/insidious/g
s/『G9195』/to wring out/g
s/『G9196』/herald of an army/g
s/『G9197』/a military encampment/g
s/『G9198』/to encamp/g
s/『G9199』/crooked/g
s/『G9200』/a strand/g
s/『G9201』/tough/g
s/『G9202』/to whirl/g
s/『G9203』/globular/g
s/『G9204』/round/g
s/『G9205』/a battleline/g
s/『G9206』/to chirp/g
s/『G9207』/an ostrich/g
s/『G9208』/a hinge/g
s/『G9209』/a shift and turn/g
s/『G9210』/a hinge/g
s/『G9211』/turnings/g
s/『G9212』/a bedding/g
s/『G9213』/a strewn bed/g
s/『G9214』/gloomy/g
s/『G9215』/of hemp/g
s/『G9216』/hemp/g
s/『G9217』/of a green poplar/g
s/『G9218』/be intimate with/g
s/『G9219』/a writ/g
s/『G9220』/to interweave/g
s/『G9221』/to burn with/g
s/『G9222』/a marriage veil/g
s/『G9223』/to inherit together/g
s/『G9224』/to mix together with/g
s/『G9225』/to devour together/g
s/『G9226』/to carry together/g
s/『G9227』/to dwell together/g
s/『G9228』/be situated together/g
s/『G9229』/to mix horns/g
s/『G9230』/a splinter/g
s/『G9231』/to break in pieces together/g
s/『G9232』/a joinery/g
s/『G9233』/a confinement/g
s/『G9234』/joined/g
s/『G9235』/summoned/g
s/『G9236』/to engulf/g
s/『G9237』/a bed-mate/g
s/『G9238』/to cut down/g
s/『G9239』/an admixture/g
s/『G9240』/interpretation/g
s/『G9241』/amalgamation/g
s/『G9242』/to strike together/g
s/『G9243』/to fall in with/g
s/『G9244』/to tie together/g
s/『G9245』/fruit of sycamine trees/g
s/『G9246』/a fig grove/g
s/『G9247』/an extortioner/g
s/『G9248』/extortion/g
s/『G9249』/a seizing/g
s/『G9250』/collection/g
s/『G9251』/assessment/g
s/『G9252』/to join in reviling/g
s/『G9253』/be compared with/g
s/『G9254』/a coupling/g
s/『G9255』/a coupling/g
s/『G9256』/an ally/g
s/『G9257』/a compact/g
s/『G9258』/be fond of carousing/g
s/『G9259』/a symbol/g
s/『G9260』/to feed together/g
s/『G9261』/advice/g
s/『G9262』/to fight along with/g
s/『G9263』/an alliance in war/g
s/『G9264』/well-proportioned/g
s/『G9265』/mixed together/g
s/『G9266』/to mix together with/g
s/『G9267』/consolidation/g
s/『G9268』/an alliance/g
s/『G9269』/to stand up with/g
s/『G9270』/all things/g
s/『G9271』/to trample upon together/g
s/『G9272』/to finish off together/g
s/『G9273』/to accommodate/g
s/『G9274』/closely joined/g
s/『G9275』/be closely joined/g
s/『G9276』/fulfillment/g
s/『G9277』/to bind hand and foot/g
s/『G9278』/to join in war with/g
s/『G9279』/to clasp together/g
s/『G9280』/to escort/g
s/『G9281』/to adhere with/g
s/『G9282』/to grapple together/g
s/『G9283』/a coincidence/g
s/『G9284』/to burn together/g
s/『G9285』/to lament together/g
s/『G9286』/to shut up together/g
s/『G9287』/to parch/g
s/『G9288』/to blend together/g
s/『G9289』/harmoniously/g
s/『G9290』/to scrape away/g
s/『G9291』/to sing together in concert/g
s/『G9292』/exchange/g
s/『G9293』/intermingling with/g
s/『G9294』/to join in carrying off/g
s/『G9295』/a meeting with/g
s/『G9296』/an event/g
s/『G9297』/to join together/g
s/『G9298』/to count with/g
s/『G9299』/to lodge with/g
s/『G9300』/an association/g
s/『G9301』/to dine with/g
s/『G9302』/to associate oneself/g
s/『G9303』/in the vicinity/g
s/『G9304』/to sit together with/g
s/『G9305』/to join in making war/g
s/『G9306』/to go forth together/g
s/『G9307』/to bring up together/g
s/『G9308』/to draw together/g
s/『G9309』/to raise up together/g
s/『G9310』/to go out together/g
s/『G9311』/to follow after together/g
s/『G9312』/to consider together/g
s/『G9313』/be conscious of/g
s/『G9314』/to vigorously assist/g
s/『G9315』/to join in making an attack/g
s/『G9316』/a female companion/g
s/『G9317』/a male companion/g
s/『G9318』/to bring understanding to/g
s/『G9319』/expertly/g
s/『G9320』/be glad with/g
s/『G9321』/a contemporary/g
s/『G9322』/to acquiesce/g
s/『G9323』/an agreement with/g
s/『G9324』/a composition/g
s/『G9325』/compounded/g
s/『G9326』/a treaty/g
s/『G9327』/a joint witness/g
s/『G9328』/to collect clouds together/g
s/『G9329』/covered with clouds/g
s/『G9330』/a sister-in-law/g
s/『G9331』/a convocation/g
s/『G9332』/to live together/g
s/『G9333』/closing of a wound/g
s/『G9334』/an arranged order/g
s/『G9335』/an arranged order/g
s/『G9336』/a rate/g
s/『G9337』/to disturb/g
s/『G9338』/custom \(tax\)/g
s/『G9339』/a price/g
s/『G9340』/a breaking/g
s/『G9341』/a break/g
s/『G9342』/a defeat/g
s/『G9343』/to roll together/g
s/『G9344』/to weave together/g
s/『G9345』/a woven part/g
s/『G9346』/a confederate/g
s/『G9347』/a hissing/g
s/『G9348』/a flute/g
s/『G9349』/to hiss/g
s/『G9350』/a hissing/g
s/『G9351』/to sew together/g
s/『G9352』/a fellow tent-dweller/g
s/『G9353』/to overshadow/g
s/『G9354』/shady/g
s/『G9355』/to darken/g
s/『G9356』/to shrivel/g
s/『G9357』/a quaking/g
s/『G9358』/to shake/g
s/『G9359』/a joint-conspiracy/g
s/『G9360』/collection/g
s/『G9361』/a confederation/g
s/『G9362』/close to/g
s/『G9363』/a knob/g
s/『G9364』/to have an inflammation/g
s/『G9365』/unsteady/g
s/『G9366』/to trip/g
s/『G9367』/a trip/g
s/『G9368』/to sling/g
s/『G9369』/a sling/g
s/『G9370』/a slinger/g
s/『G9371』/a swarm of wasps/g
s/『G9372』/to wedge/g
s/『G9373』/to grasp/g
s/『G9374』/vehement/g
s/『G9375』/a neck vertebrae/g
s/『G9376』/an adz/g
s/『G9377』/to strike with a hammer/g
s/『G9378』/a hammer-smith/g
s/『G9379』/to open up/g
s/『G9380』/a barge/g
s/『G9381』/kindling/g
s/『G9382』/a dart/g
s/『G9383』/a fissure/g
s/『G9384』/shredded/g
s/『G9385』/a measured out line/g
s/『G9386』/a piece of measured out land/g
s/『G9387』/a rush/g
s/『G9388』/an idler/g
s/『G9389』/to rejuvenate/g
s/『G9390』/a choice vine/g
s/『G9391』/a heap/g
s/『G9392』/ram's horn/g
s/『G9394』/fascia/g
s/『G9395』/tactician/g
s/『G9396』/miserably/g
s/『G9397』/miserable/g
s/『G9398』/a storekeeper/g
s/『G9399』/to store up/g
s/『G9400』/to stretch/g
s/『G9401』/be humble-minded/g
s/『G9402』/humble-minded/g
s/『G9403』/disturbing/g
s/『G9404』/infernal region/g
s/『G9405』/a trench/g
s/『G9406』/to hasten/g
s/『G9407』/to stretch out/g
s/『G9408』/walled/g
s/『G9409』/to wall/g
s/『G9410』/a stonemason/g
s/『G9411』/to produce children/g
s/『G9412』/to contrive/g
s/『G9413』/a woodworker/g
s/『G9414』/a ligature/g
s/『G9415』/to perfect a work/g
s/『G9416』/mystic rites/g
s/『G9417』/finality/g
s/『G9418』/a sacred precinct/g
s/『G9419』/to prune/g
s/『G9420』/an observer of signs/g
s/『G9421』/terebinth resin/g
s/『G9422』/a drill/g
s/『G9423』/delightful/g
s/『G9424』/delightfulness/g
s/『G9425』/to delight/g
s/『G9426』/delight/g
s/『G9427』/forty-two/g
s/『G9428』/forty-seven/g
s/『G9429』/forty-eight/g
s/『G9430』/forty-five/g
s/『G9431』/forty-three/g
s/『G9432』/fortieth/g
s/『G9433』/fourteen/g
s/『G9434』/four-drachma/g
s/『G9435』/puncture/g
s/『G9436』/forty thousand/g
s/『G9437』/four hundredth/g
s/『G9438』/quadrangular/g
s/『G9439』/fourfold/g
s/『G9440』/fourth/g
s/『G9441』/arranged in four rows/g
s/『G9442』/to cunningly contrive/g
s/『G9443』/Tebeth/g
s/『G9444』/a frying pan/g
s/『G9445』/radiance/g
s/『G9446』/radiant/g
s/『G9447』/radiance/g
s/『G9448』/a tiara/g
s/『G9449』/to suckle/g
s/『G9450』/a wet-nurse/g
s/『G9451』/valuation/g
s/『G9452』/to assess/g
s/『G9453』/vibration/g
s/『G9454』/titan/g
s/『G9455』/to pierce/g
s/『G9456』/to cut into shape/g
s/『G9457』/birth/g
s/『G9458』/daring/g
s/『G9459』/a wild gourd/g
s/『G9460』/pruning/g
s/『G9461』/a pruning knife/g
s/『G9462』/a roll of papyrus/g
s/『G9463』/a bow/g
s/『G9464』/to shoot/g
s/『G9465』/a bowman/g
s/『G9466』/a toparch/g
s/『G9467』/turned/g
s/『G9468』/an antelope/g
s/『G9469』/plainly/g
s/『G9470』/slain/g
s/『G9471』/to stiffen the neck/g
s/『G9472』/to rout/g
s/『G9473』/thirty-two/g
s/『G9474』/thirty-nine/g
s/『G9475』/thirty-six/g
s/『G9476』/thirty-seven/g
s/『G9477』/thirty years old/g
s/『G9478』/thirty-eight/g
s/『G9479』/thirty-five/g
s/『G9480』/thirty-three/g
s/『G9481』/thirty-four/g
s/『G9482』/thirtieth/g
s/『G9483』/be very busy/g
s/『G9484』/of three years/g
s/『G9485』/be three years old/g
s/『G9486』/third day/g
s/『G9487』/be three parts/g
s/『G9488』/three-pronged/g
s/『G9489』/triple/g
s/『G9490』/thirteen/g
s/『G9491』/thirteenth/g
s/『G9492』/to do three times/g
s/『G9493』/third rank/g
s/『G9494』/to do a third time/g
s/『G9495』/third/g
s/『G9496』/a tribune/g
s/『G9497』/three days/g
s/『G9498』/a braid/g
s/『G9499』/hair on a head/g
s/『G9500』/third story/g
s/『G9501』/to put to flight/g
s/『G9502』/to nourish/g
s/『G9503』/to nurture/g
s/『G9504』/a disc/g
s/『G9505』/a grape gatherer/g
s/『G9506』/a gathering of crops/g
s/『G9507』/wine with dregs/g
s/『G9508』/to make a hole/g
s/『G9509』/cheese/g
s/『G9510』/delicate/g
s/『G9511』/delicacy/g
s/『G9512』/a bore/g
s/『G9513』/be hardened/g
s/『G9514』/performing on a tambourine/g
s/『G9515』/a tambourine/g
s/『G9516』/be sovereign/g
s/『G9517』/a wife of a sovereign/g
s/『G9518』/to curdle into cheese/g
s/『G9519』/good luck/g
s/『G9520』/a hyena/g
s/『G9521』/outrageous/g
s/『G9522』/to heal/g
s/『G9523』/health/g
s/『G9524』/fairly/g
s/『G9525』/to wet/g
s/『G9526』/wetness/g
s/『G9527』/an aqueduct/g
s/『G9528』/to draw water/g
s/『G9529』/a water-pot/g
s/『G9530』/a water-carrier/g
s/『G9531』/like a pig/g
s/『G9532』/to rain/g
s/『G9533』/to bark/g
s/『G9534』/flush/g
s/『G9535』/singing of praise/g
s/『G9536』/to sing a hymn/g
s/『G9537』/open air/g
s/『G9538』/supreme/g
s/『G9539』/to remove secretly/g
s/『G9540』/far above/g
s/『G9541』/overflowing/g
s/『G9542』/to shield/g
s/『G9543』/shielding/g
s/『G9544』/a defender/g
s/『G9545』/to overpower/g
s/『G9547』/to overflow/g
s/『G9548』/be prideful/g
s/『G9549』/a lintel/g
s/『G9550』/to excel in strength/g
s/『G9551』/to have precedence/g
s/『G9552』/to prevail against/g
s/『G9553』/immense/g
s/『G9554』/exceedingly tall/g
s/『G9555』/a pestle/g
s/『G9556』/neglect/g
s/『G9557』/to neglect/g
s/『G9558』/disdain/g
s/『G9559』/to procrastinate/g
s/『G9560』/overwhelming/g
s/『G9561』/to overwhelm/g
s/『G9562』/overjoyed/g
s/『G9563』/to overflow/g
s/『G9564』/head and shoulders above/g
s/『G9565』/accountable/g
s/『G9566』/service/g
s/『G9567』/to sleep/g
s/『G9568』/sleepy/g
s/『G9569』/to suspect/g
s/『G9570』/subterranean/g
s/『G9571』/an undergarment/g
s/『G9572』/an underpart/g
s/『G9573』/to fire up/g
s/『G9574』/to cover up/g
s/『G9575』/from beneath/g
s/『G9576』/to lay in place of/g
s/『G9577』/a vestige/g
s/『G9578』/a vestige/g
s/『G9579』/a loosening/g
s/『G9580』/to untie/g
s/『G9581』/a record/g
s/『G9582』/a memoir/g
s/『G9583』/a recorder/g
s/『G9584』/to goad/g
s/『G9585』/be penitent/g
s/『G9586』/to dread/g
s/『G9587』/be reddish/g
s/『G9588』/to trip up/g
s/『G9589』/a fall/g
s/『G9590』/a garrison/g
s/『G9591』/a support/g
s/『G9592』/to support/g
s/『G9593』/under a breast/g
s/『G9594』/an aid/g
s/『G9595』/a narrow opening/g
s/『G9596』/subject to tribute/g
s/『G9597』/under one's hand/g
s/『G9598』/a spleen/g
s/『G9599』/a debtor/g
s/『G9600』/an oil flask/g
s/『G9601』/to turn up and open hands/g
s/『G9602』/steep/g
s/『G9603』/a bruise/g
s/『G9604』/an afterthought/g
s/『G9605』/to weave/g
s/『G9606』/to take up/g
s/『G9607』/a weaver/g
s/『G9608』/a woven work/g
s/『G9609』/to stand/g
s/『G9610』/a proud heart/g
s/『G9611』/act of exaltation/g
s/『G9612』/to rain/g
s/『G9613』/gray/g
s/『G9614』/a flask/g
s/『G9615』/bald/g
s/『G9616』/baldness/g
s/『G9617』/a quiver/g
s/『G9618』/to administer potions/g
s/『G9619』/a potion/g
s/『G9620』/a compound/g
s/『G9621』/a throat/g
s/『G9622』/a passover/g
s/『G9623』/a visible manifestation/g
s/『G9624』/to decorate with fretwork/g
s/『G9625』/a fretwork/g
s/『G9626』/to treat as worthless/g
s/『G9627』/a careless attitude/g
s/『G9628』/disparagement/g
s/『G9629』/heedless/g
s/『G9630』/giving light/g
s/『G9631』/a dowry/g
s/『G9632』/to endow/g
s/『G9633』/corruption/g
s/『G9634』/an utterance/g
s/『G9635』/to fumigate/g
s/『G9636』/to wane/g
s/『G9637』/fond of sinning/g
s/『G9638』/fond of quarreling/g
s/『G9639』/to befriend/g
s/『G9640』/fond of husbandry/g
s/『G9641』/fond of women/g
s/『G9642』/be fond of altercations/g
s/『G9643』/a rein/g
s/『G9644』/be inflamed/g
s/『G9645』/to blaze/g
s/『G9646』/an artery/g
s/『G9647』/a doorway/g
s/『G9648』/flaming/g
s/『G9649』/a boil/g
s/『G9650』/to throw into fear/g
s/『G9651』/fright/g
s/『G9652』/fearfully/g
s/『G9653』/crimson/g
s/『G9654』/palm-grove/g
s/『G9655』/a man-killer/g
s/『G9656』/to pollute with murder/g
s/『G9657』/a halter/g
s/『G9658』/a carriage/g
s/『G9659』/nobles/g
s/『G9660』/tributary/g
s/『G9661』/tribute-gatherer/g
s/『G9662』/shuddering awe/g
s/『G9663』/a cause for shuddering/g
s/『G9664』/a cause for shuddering/g
s/『G9665』/bewilderment/g
s/『G9666』/a detachment of soldiers/g
s/『G9667』/lots/g
s/『G9668』/neighing/g
s/『G9669』/dried sticks/g
s/『G9670』/to parch/g
s/『G9671』/flight/g
s/『G9672』/a place of refuge/g
s/『G9673』/a place of refuge/g
s/『G9674』/to drive into exile/g
s/『G9675』/an exile/g
s/『G9676』/development/g
s/『G9677』/an injunction/g
s/『G9678』/a female keeper/g
s/『G9679』/a tribal chief/g
s/『G9680』/a mixing together/g
s/『G9681』/to mix up/g
s/『G9682』/a befouling/g
s/『G9683』/to befoul/g
s/『G9684』/to blow/g
s/『G9685』/a pair of bellows/g
s/『G9686』/a plant/g
s/『G9687』/a plant/g
s/『G9688』/caught in the act/g
s/『G9689』/600/g
s/『G9690』/to gape wide/g
s/『G9691』/a chain-work/g
s/『G9692』/galbanum/g
s/『G9693』/gravel/g
s/『G9694』/a brass cauldron/g
s/『G9695』/of brass/g
s/『G9696』/to forge/g
s/『G9697』/chameleon/g
s/『G9698』/chaos/g
s/『G9699』/a curlew/g
s/『G9700』/a palisade/g
s/『G9701』/to build a palisade/g
s/『G9702』/a siege mound/g
s/『G9703』/to grave/g
s/『G9704』/a cause for joy/g
s/『G9705』/joyfulness/g
s/『G9706』/a causing joy/g
s/『G9707』/papyrus paper/g
s/『G9708』/a cake/g
s/『G9709』/bowls/g
s/『G9710』/of winter/g
s/『G9711』/manacles/g
s/『G9712』/stretching forth hands/g
s/『G9713』/to lay hands against/g
s/『G9714』/a swallow/g
s/『G9715』/a tortoise/g
s/『G9716』/a lip/g
s/『G9717』/a cherub/g
s/『G9718』/of dry land/g
s/『G9719』/uncultivated/g
s/『G9720』/to make barren/g
s/『G9721』/to pour/g
s/『G9722』/a claw/g
s/『G9723』/widowhood/g
s/『G9724』/widowhood/g
s/『G9725』/be a widow/g
s/『G9726』/of yesterday/g
s/『G9727』/soil/g
s/『G9728』/green wheat/g
s/『G9729』/a command of a thousand/g
s/『G9730』/a thousand times more/g
s/『G9731』/a thousand/g
s/『G9732』/a yearling/g
s/『G9733』/1 winter yearling/g
s/『G9734』/to snow/g
s/『G9735』/a goat's hair coat/g
s/『G9736』/an object of taunts/g
s/『G9737』/taunting/g
s/『G9738』/an armlet/g
s/『G9739』/be greenish/g
s/『G9740』/greenness/g
s/『G9741』/dust/g
s/『G9742』/hyrax/g
s/『G9743』/cholera/g
s/『G9744』/bitter anger/g
s/『G9745』/of groats/g
s/『G9746』/string of a lyre/g
s/『G9747』/to join in a dance/g
s/『G9748』/a bestowing of expenses/g
s/『G9749』/afterbirth/g
s/『G9750』/a patrol/g
s/『G9751』/a filling/g
s/『G9752』/be overgrown/g
s/『G9753』/a coos/g
s/『G9754』/to snort/g
s/『G9755』/snorting/g
s/『G9756』/a debt/g
s/『G9757』/to speak oracles/g
s/『G9758』/an anointing/g
s/『G9759』/complexion/g
s/『G9760』/to shine like gold/g
s/『G9761』/wrought in gold/g
s/『G9762』/a goldsmith/g
s/『G9763』/extensive/g
s/『G9764』/an increase/g
s/『G9765』/cast/g
s/『G9766』/an earthen pot/g
s/『G9767』/a pot/g
s/『G9768』/a pot with feet/g
s/『G9769』/a capital/g
s/『G9770』/be lame/g
s/『G9771』/an embankment/g
s/『G9772』/idolatrous priests/g
s/『G9773』/be fortified; by a mound/g
s/『G9774』/a molten casting/g
s/『G9775』/a molten casting/g
s/『G9776』/a foundry furnace/g
s/『G9777』/a smelterer/g
s/『G9778』/casted/g
s/『G9779』/to cast in a furnace/g
s/『G9780』/separation/g
s/『G9781』/to explore/g
s/『G9782』/a clip/g
s/『G9783』/a psaltery/g
s/『G9784』/strummed chords of music/g
s/『G9785』/to sing along with stringed instruments/g
s/『G9786』/a psalm singer/g
s/『G9787』/dapple-gray/g
s/『G9788』/mist/g
s/『G9789』/to stutter/g
s/『G9790』/a bracelet/g
s/『G9791』/falsely/g
s/『G9792』/tangible/g
s/『G9793』/a referendum/g
s/『G9794』/to whisper/g
s/『G9795』/bare/g
s/『G9796』/to make bear/g
s/『G9797』/a flank/g
s/『G9798』/fault/g
s/『G9799』/to stamp/g
s/『G9800』/a noise/g
s/『G9801』/a refreshing/g
s/『G9802』/a wine-cooler/g
s/『G9803』/a flea/g
s/『G9804』/a morsel/g
s/『G9805』/mange/g
s/『G9806』/to have chronic mange/g
s/『G9807』/an edge/g
s/『G9808』/a singer/g
s/『G9809』/to thrust through/g
s/『G9810』/protrusion/g
s/『G9811』/raw/g
s/『G9812』/to bring forth prematurely/g
s/『G9813』/be beautiful/g
s/『G9814』/beauty/g
s/『G9815』/finery/g
s/『G9816』/in season/g
s/『G9817』/a roaring/g
s/『G9818』/continually/g
s/『G9819』/mutilated ears/g
s/『G9820』/benefit/g
s/『G9821』/paleness/g
s/『G9822』/expanse/g
s/『G9823』/twisted/g
s/『G9824』/hin/g
s/『G9825』/Asen/g
s/『G9826』/Bougean/g
s/『G9827』/Edem/g
s/『G9828』/Gergashites/g
s/『G9829』/Heliopolis/g
s/『G9830』/Hodijah/g
s/『G9831』/Janen/g
s/『G9832』/Jemnath/g
s/『G9833』/Jothor/g
s/『G9834』/Parian/g
s/『G9835』/Sutalaam/g
s/『G9836』/Tam/g
s/『G9837』/peres/g
s/『G9838』/gate/g
s/『G9839』/twenty/g
s/『G9840』/Sur/g
s/『G9841』/Ausis/g
s/『G9842』/socket/g
s/『G9843』/unexcepted/g
s/『G9844』/offspring/g
s/『G9845』/cheese/g
s/『G9980』/to disable/g
s/『G9981』/lamb/g
s/『G9982』/to rise up/g
s/『G9983』/to persuade/g
s/『G9984』/to answer/g
s/『G9985』/Pythius/g
s/『G9986』/javelin/g
s/『G9987』/sprinkle/g
s/『G9989』/boundary/g
s/『G9990』/12/g
s/『G9991』/144/g
s/『G9992』/figuratively/g
s/『G9993』/wrapping/g
s/『G20001』/to be made desert/g
s/『G20002』/helplessness/g
s/『G20003』/ill-advised, inconsiderate./g
s/『G20004』/goodness/g
s/『G20005』/insolence/g
s/『G20006』/to be insolent/g
s/『G20007』/feats of mastery/g
s/『G20008』/arrogant/g
s/『G20009』/service/g
s/『G20010』/sanctify/g
s/『G20011』/service/g
s/『G20013』/purification/g
s/『G20014』/collection of streets, city/g
s/『G20015』/wifeless/g
s/『G20016』/sisterly/g
s/『G20017』/as befits a brother/g
s/『G20018』/without molestation/g
s/『G20019』/headstrong/g
s/『G20020』/that will not stand examinalion/g
s/『G20021』/deprived of its strength, useless/g
s/『G20022』/to want power, be incapable/g
s/『G20023』/grey/g
s/『G20024』/immune/g
s/『G20025』/faithlessness/g
s/『G20026』/preside over, direct/g
s/『G20027』/human organism/g
s/『G20028』/impunity/g
s/『G20029』/a goat's skin/g
s/『G20030』/wrench, shock/g
s/『G20031』/cat, Felis domesticus/g
s/『G20032』/to be bloody, blood-red/g
s/『G20033』/blood-sprinkled/g
s/『G20034』/one who chooses/g
s/『G20035』/uncovered, unveiled/g
s/『G20036』/unconquerable/g
s/『G20037』/to be unstable/g
s/『G20038』/spotless/g
s/『G20039』/sleepless, unresting/g
s/『G20040』/inhuman/g
s/『G20041』/never tires of/g
s/『G20042』/long to hear/g
s/『G20043』/to be proud/g
s/『G20044』/not exercising judgement, undiscriminating/g
s/『G20045』/form a promontory, jut out like one/g
s/『G20046』/with foreign foe/g
s/『G20047』/religions/g
s/『G20048』/adoption of foreign customs/g
s/『G20049』/to be dim-sighted/g
s/『G20050』/gloomy/g
s/『G20051』/gloomy/g
s/『G20052』/decree of amnesty/g
s/『G20053』/forgivingness/g
s/『G20054』/over/g
s/『G20055』/not leaving any stain/g
s/『G20056』/vengeance, requital/g
s/『G20057』/put on/g
s/『G20058』/going up, ascent/g
s/『G20059』/return to life/g
s/『G20060』/wrought in low relief/g
s/『G20061』/abominable wickedness/g
s/『G20062』/inerudite et/g
s/『G20063』/emergence/g
s/『G20064』/bowl/g
s/『G20065』/equivalent to, resembling/g
s/『G20066』/new again/g
s/『G20067』/mount up/g
s/『G20068』/fall late/g
s/『G20069』/calling back, recall/g
s/『G20070』/clamorous/g
s/『G20071』/eastwards/g
s/『G20072』/bravery/g
s/『G20073』/become a man/g
s/『G20074』/census/g
s/『G20075』/incapable of artistic representation/g
s/『G20076』/incessant/g
s/『G20077』/without permission/g
s/『G20078』/\(woad\)/g
s/『G20079』/plaster/g
s/『G20080』/opener/g
s/『G20081』/pour forth/g
s/『G20082』/cause to revert/g
s/『G20083』/think oneself equal to/g
s/『G20084』/lie over against/g
s/『G20085』/oppose/g
s/『G20086』/to be clothed about/g
s/『G20087』/accident/g
s/『G20088』/repel by force/g
s/『G20089』/to be contrary/g
s/『G20090』/incomparable/g
s/『G20091』/wrong/g
s/『G20092』/unnoticed/g
s/『G20093』/take leave of/g
s/『G20094』/beguiling/g
s/『G20095』/unacquainted with goodness, foolish/g
s/『G20096』/opposite/g
s/『G20097』/unlamented/g
s/『G20098』/continually/g
s/『G20099』/happily/g
s/『G20100』/err/g
s/『G20101』/insatiable/g
s/『G20102』/draw/g
s/『G20103』/anything cast away/g
s/『G20104』/tithe/g
s/『G20105』/to be set apart, forbidden/g
s/『G20106』/cistern/g
s/『G20107』/arevelation/g
s/『G20108』/evacuate/g
s/『G20109』/shut off, enclosed/g
s/『G20110』/remove from the world, kill/g
s/『G20111』/kill/g
s/『G20112』/take away the mitre/g
s/『G20113』/scarify, tear/g
s/『G20114』/deflower/g
s/『G20115』/sell/g
s/『G20116』/to be angry/g
s/『G20117』/breaking/g
s/『G20118』/breakup/g
s/『G20120』/regard/g
s/『G20121』/to scatter widely/g
s/『G20122』/to be shaved bare/g
s/『G20123』/to be horribly tortured/g
s/『G20124』/as from a sling/g
s/『G20125』/to be deprived of children/g
s/『G20126』/tow/g
s/『G20127』/to repay/g
s/『G20128』/precisely, in the strictest sense/g
s/『G20129』/to pour out/g
s/『G20130』/self-sufficient/g
s/『G20131』/undaunted/g
s/『G20132』/far from/g
s/『G20133』/replusion/g
s/『G20134』/subject to a levy in money/g
s/『G20135』/melter of, worker in, silver/g
s/『G20136』/spread/g
s/『G20137』/recitation of/g
s/『G20138』/virtuous/g
s/『G20139』/instruments of torture/g
s/『G20140』/bear-berry, Arctostaphylos Uva-ursi/g
s/『G20141』/fitting, harmonious/g
s/『G20142』/ploughing/g
s/『G20143』/to be ploughed/g
s/『G20144』/deposit paid/g
s/『G20145』/brave./g
s/『G20146』/aršan-/g
s/『G20147』/priestess/g
s/『G20148』/to be high-priest/g
s/『G20149』/high-priesthood/g
s/『G20150』/heron/g
s/『G20151』/weak-minded/g
s/『G20152』/leathern canteen/g
s/『G20153』/unsteady, unstable/g
s/『G20154』/lewd, filthy/g
s/『G20155』/to be engaged in one's own business/g
s/『G20156』/have no children/g
s/『G20157』/dishonour/g
s/『G20158』/notcapable of being valued/g
s/『G20159』/wickedness, misdeed/g
s/『G20160』/difficult/g
s/『G20161』/restriction/g
s/『G20162』/taking immediate effect/g
s/『G20163』/doorkeeper/g
s/『G20164』/free will/g
s/『G20165』/absolute master/g
s/『G20166』/wild, natural/g
s/『G20167』/taxation/g
s/『G20168』/far from hearth and home/g
s/『G20169』/guiding, leading/g
s/『G20170』/copy/g
s/『G20171』/not subjected to tribute/g
s/『G20172』/to act foolishly/g
s/『G20173』/unable to escape/g
s/『G20174』/vast, immense/g
s/『G20175』/unprofitableness, worthlessness/g
s/『G20176』/of unintelligible speech/g
s/『G20177』/bai/g
s/『G20178』/deep-roaring/g
s/『G20179』/to be dim-sighted/g
s/『G20180』/jealousy/g
s/『G20181』/archives/g
s/『G20182』/bring forth/g
s/『G20183』/buzzing: buzzing crowd/g
s/『G20184』/ox-yoke/g
s/『G20185』/ending shortly, brief/g
s/『G20186』/stink, noisome smell/g
s/『G20187』/papyrus/g
s/『G20188』/flowering head of papyrus/g
s/『G20189』/living in the deep/g
s/『G20190』/nourish with milk/g
s/『G20191』/to suckle/g
s/『G20192』/creator/g
s/『G20193』/fashioner, creator/g
s/『G20194』/parent\/ancestor/g
s/『G20195』/old age/g
s/『G20196』/gigno, gnatus./g
s/『G20197』/coffin/g
s/『G20198』/diviner/g
s/『G20199』/to be subject to spermatorrhoea/g
s/『G20200』/for/g
s/『G20201』/torch-bearing/g
s/『G20202』/thumb-screw/g
s/『G20203』/lend\/borrow/g
s/『G20204』/to be cowardly/g
s/『G20205』/to be afraid/g
s/『G20206』/fainthearted/g
s/『G20207』/to be in straits/g
s/『G20208』/multiply by ten/g
s/『G20209』/head of a/g
s/『G20210』/approve/g
s/『G20211』/joint/g
s/『G20212』/enjoy ownership of . ./g
s/『G20213』/speak a second time/g
s/『G20214』/wretched/g
s/『G20215』/popular/g
s/『G20216』/penetrate/g
s/『G20217』/speak of/g
s/『G20218』/stand in dread of/g
s/『G20219』/fly in all directions/g
s/『G20220』/turn by entreaty/g
s/『G20221』/cause to sit apart/g
s/『G20222』/keep on foot/g
s/『G20223』/dive and swim across/g
s/『G20224』/minute observance/g
s/『G20225』/digression/g
s/『G20226』/set with precious stones/g
s/『G20227』/railing, abuse/g
s/『G20228』/carp at/g
s/『G20229』/dismember/g
s/『G20230』/lie in wait for continually/g
s/『G20231』/attempt, try/g
s/『G20232』/interceed/g
s/『G20233』/to be consumed with thirst/g
s/『G20234』/arrange in order/g
s/『G20235』/to declare/g
s/『G20236』/disperse/g
s/『G20237』/leap about/g
s/『G20238』/arrangement, compact/g
s/『G20239』/glance like lightning/g
s/『G20240』/whistle away, waste idly/g
s/『G20241』/seal up/g
s/『G20242』/to be arranged, regulated by agreement/g
s/『G20243』/take quite away/g
s/『G20244』/to be envied/g
s/『G20245』/whisper among themselves/g
s/『G20246』/double burden, load/g
s/『G20247』/peep out/g
s/『G20248』/fill completely/g
s/『G20249』/distortedly/g
s/『G20250』/righteous judge/g
s/『G20251』/forensic speeches/g
s/『G20252』/vengeance/g
s/『G20253』/to be very angry/g
s/『G20254』/rise early/g
s/『G20255』/of books, editor, reviser/g
s/『G20256』/canal/g
s/『G20257』/number of twenty thousand/g
s/『G20258』/worth two talents/g
s/『G20259』/mid-menstrual period/g
s/『G20260』/spear-carrying/g
s/『G20261』/body-guard/g
s/『G20262』/eye/g
s/『G20263』/natural resources/g
s/『G20264』/most miserable/g
s/『G20265』/hard to escape/g
s/『G20266』/hard to narrate/g
s/『G20267』/restless/g
s/『G20268』/infamous, shameful/g
s/『G20269』/to be ill-affected/g
s/『G20270』/misfortune/g
s/『G20271』/unlucky in war/g
s/『G20272』/impious act/g
s/『G20273』/keep the Sabbath/g
s/『G20274』/to be near akin/g
s/『G20275』/stretch the limbs upon/g
s/『G20276』/set-firm/g
s/『G20277』/offer sacrifice/g
s/『G20278』/courses/g
s/『G20279』/bury in/g
s/『G20280』/engraved inscription/g
s/『G20281』/to be adorned/g
s/『G20282』/acquisition of territory/g
s/『G20283』/accustomed/g
s/『G20284』/by nations, as a whole nation/g
s/『G20285』/where/g
s/『G20286』/likeness/g
s/『G20287』/odious, ugly look/g
s/『G20288』/forms of knowledge/g
s/『G20289』/striking/g
s/『G20290』/carve upon/g
s/『G20291』/plunge into/g
s/『G20292』/overhang/g
s/『G20293』/profane/g
s/『G20294』/to expell/g
s/『G20295』/has broken in upon/g
s/『G20296』/erruption/g
s/『G20297』/bringforth/g
s/『G20298』/to scare/g
s/『G20299』/make to change one's habits/g
s/『G20300』/to avenge/g
s/『G20301』/searcher out/g
s/『G20303』/oppression/g
s/『G20304』/elision/g
s/『G20305』/deck out, adorn/g
s/『G20306』/very bright/g
s/『G20307』/sudden development/g
s/『G20308』/purified/g
s/『G20309』/peeled/g
s/『G20310』/winnow, sift, empty/g
s/『G20311』/accountant/g
s/『G20312』/reckoning: accounts/g
s/『G20313』/dismember/g
s/『G20314』/laugh to scorn, mock at/g
s/『G20315』/gaping/g
s/『G20316』/squeezed/g
s/『G20317』/change the constitution of a state, cause it to degenerate/g
s/『G20318』/rooter out, destroyer/g
s/『G20319』/escape/g
s/『G20320』/break the vertebrae/g
s/『G20321』/hiss loudly/g
s/『G20322』/avoid, shun/g
s/『G20323』/warm up/g
s/『G20324』/produce/g
s/『G20325』/escape/g
s/『G20326』/gape, gaze/g
s/『G20327』/to be angry/g
s/『G20328』/diminish/g
s/『G20329』/to have pity/g
s/『G20330』/giving alms/g
s/『G20331』/one must come/g
s/『G20332』/commander of a squadron of sixteen elephants/g
s/『G20333』/taking root/g
s/『G20334』/maddened by/g
s/『G20335』/instrument for practice/g
s/『G20336』/to speak openly/g
s/『G20337』/to be experienced in, have knowledge of/g
s/『G20338』/to be filled with/g
s/『G20339』/trammelling/g
s/『G20340』/besiege in/g
s/『G20341』/vehement/g
s/『G20342』/fastened with a brooch upon the shoulder/g
s/『G20343』/to wear/g
s/『G20344』/explanation/g
s/『G20345』/mix up, confuse/g
s/『G20346』/implant, instil into/g
s/『G20347』/on/g
s/『G20348』/concordant/g
s/『G20349』/look fixedly on/g
s/『G20350』/informer, complainant/g
s/『G20351』/to be persistently afflicted/g
s/『G20352』/persevere/g
s/『G20353』/to the best of his ability/g
s/『G20354』/sodomite/g
s/『G20355』/impregnated/g
s/『G20356』/stomach/g
s/『G20357』/trade with one in/g
s/『G20358』/to be brought into subjection/g
s/『G20359』/pass one's time in/g
s/『G20360』/of age, in the prime of manhood/g
s/『G20361』/sonorous/g
s/『G20362』/valid/g
s/『G20363』/crumble into liquid, make sop/g
s/『G20364』/sacrifice in . ./g
s/『G20365』/live amongst/g
s/『G20367』/signal, wave of the hand/g
s/『G20368』/make oneself a nest on/g
s/『G20369』/jostle/g
s/『G20370』/encamp/g
s/『G20371』/to be held in honour/g
s/『G20372』/shaking/g
s/『G20373』/collide with/g
s/『G20374』/inwards, entrails/g
s/『G20375』/inner/g
s/『G20376』/records/g
s/『G20377』/play the hypocrite/g
s/『G20378』/to be made subject/g
s/『G20379』/exalt, excite/g
s/『G20380』/nephew/g
s/『G20381』/change utterly/g
s/『G20382』/to be estranged/g
s/『G20383』/discharge/g
s/『G20384』/loose-jointed/g
s/『G20385』/dislocate/g
s/『G20386』/dishonour utterly/g
s/『G20387』/squander/g
s/『G20388』/grow out of/g
s/『G20389』/to leave/g
s/『G20390』/propitiate/g
s/『G20391』/show rejoicing/g
s/『G20392』/civilized/g
s/『G20393』/stupes/g
s/『G20394』/in R./g
s/『G20395』/to divert/g
s/『G20396』/depart this life/g
s/『G20397』/destruction/g
s/『G20398』/pour out like rain/g
s/『G20399』/swear, make affidavit/g
s/『G20400』/to dispise/g
s/『G20401』/above all/g
s/『G20402』/wake out of sleep/g
s/『G20403』/elevate/g
s/『G20404』/outermost/g
s/『G20405』/festival, holiday/g
s/『G20406』/begging/g
s/『G20407』/to be obeyed/g
s/『G20408』/painful/g
s/『G20409』/make manly/g
s/『G20410』/fuller statement/g
s/『G20411』/tnroll in tablets, register/g
s/『G20412』/irrigate/g
s/『G20413』/come to aid, help/g
s/『G20414』/haughty/g
s/『G20415』/breathe hard, pant in working/g
s/『G20416』/bring in one upon another/g
s/『G20417』/on yonder side, beyond,/g
s/『G20418』/break besides/g
s/『G20419』/to lie down/g
s/『G20420』/renew, restore/g
s/『G20421』/stalk/g
s/『G20422』/glean/g
s/『G20423』/against/g
s/『G20424』/to be moved/g
s/『G20425』/appellatio, appeal/g
s/『G20426』/porous, spongy/g
s/『G20427』/puff up/g
s/『G20428』/tempering/g
s/『G20429』/decretum/g
s/『G20430』/bent over, crooked/g
s/『G20431』/to be said of . ./g
s/『G20432』/smooth off, shave smooth/g
s/『G20433』/forget wilfully/g
s/『G20434』/to convulse/g
s/『G20435』/to be troubled at/g
s/『G20436』/in combination/g
s/『G20437』/mention severally, enumerate/g
s/『G20438』/to be at the middle/g
s/『G20439』/extending/g
s/『G20440』/respect of persons/g
s/『G20441』/with toil/g
s/『G20442』/superabound/g
s/『G20443』/plagues/g
s/『G20444』/covered with wool, woolly/g
s/『G20445』/glean grapes off/g
s/『G20446』/comparable/g
s/『G20447』/a/g
s/『G20448』/take to oneself/g
s/『G20449』/right of cutting/g
s/『G20450』/make of small account/g
s/『G20451』/upon/g
s/『G20452』/sing/g
s/『G20453』/stimulate, excite/g
s/『G20454』/to be wroth at/g
s/『G20455』/mother of seven children/g
s/『G20456』/sevenfold/g
s/『G20457』/seven-towered/g
s/『G20458』/indulge in petty intrigue/g
s/『G20459』/to dispute/g
s/『G20460』/blight/g
s/『G20461』/blush scarlet/g
s/『G20462』/red/g
s/『G20463』/feed on, devour/g
s/『G20464』/[hudot ]ōšen/g
s/『G20465』/in extreme old age/g
s/『G20466』/to be deaf of one ear/g
s/『G20467』/rūgio/g
s/『G20468』/affable, courteous/g
s/『G20469』/bodily strength and health/g
s/『G20470』/witty/g
s/『G20471』/easily appeased, placable/g
s/『G20472』/fortunate/g
s/『G20473』/ease, facility/g
s/『G20474』/behave orderly/g
s/『G20475』/to bless/g
s/『G20476』/honourably/g
s/『G20477』/well-cooked/g
s/『G20478』/ready obedience/g
s/『G20479』/of bright purple colour/g
s/『G20480』/in weight/g
s/『G20481』/fusibility/g
s/『G20482』/pleasant/g
s/『G20483』/mission of thanks/g
s/『G20484』/gymnasium/g
s/『G20485』/perjury/g
s/『G20486』/contemptible/g
s/『G20487』/yesterday/g
s/『G20488』/yoke in pairs, unite/g
s/『G20489』/life/g
s/『G20490』/life/g
s/『G20491』/one taken alive/g
s/『G20492』/seams/g
s/『G20493』/true to life/g
s/『G20494』/flagship/g
s/『G20495』/govenor/g
s/『G20496』/command/g
s/『G20497』/with joy, gladly/g
s/『G20498』/of manners/g
s/『G20499』/ferment/g
s/『G20500』/nictilopa/g
s/『G20501』/half-green/g
s/『G20502』/half-dead/g
s/『G20503』/half-hopeful/g
s/『G20504』/half time/g
s/『G20505』/half-set/g
s/『G20506』/sandal-thong/g
s/『G20507』/look!/g
s/『G20508』/first stomach/g
s/『G20509』/inspect the liver for soothsaying/g
s/『G20510』/gentleness/g
s/『G20511』/sounding/g
s/『G20512』/founded by God/g
s/『G20513』/reaping-hook/g
s/『G20514』/feeding upon/g
s/『G20515』/destruction/g
s/『G20516』/to be a devotee/g
s/『G20517』/to be initiated, consecrated/g
s/『G20518』/well-pleasing, delightful/g
s/『G20519』/armed with such a shield/g
s/『G20520』/suffire/g
s/『G20521』/arming with breastplates/g
s/『G20522』/separately written/g
s/『G20523』/relationship/g
s/『G20524』/sanctuary/g
s/『G20525』/templecourtesans/g
s/『G20526』/sacrilege/g
s/『G20527』/singer in the temple/g
s/『G20528』/of holy, pious soul/g
s/『G20529』/consecrated object, offering/g
s/『G20530』/suppliant/g
s/『G20531』/burlesque tragedy/g
s/『G20532』/placable/g
s/『G20533』/propitiator/g
s/『G20534』/gracious/g
s/『G20535』/piece of timber used instead of a bond-stone/g
s/『G20536』/like a star, bright as a star/g
s/『G20537』/speak as an equal/g
s/『G20538』/to be equipollent/g
s/『G20539』/equivalent/g
s/『G20540』/equitable citizen/g
s/『G20541』/strength/g
s/『G20542』/on the whole/g
s/『G20543』/PTeb.ined./g
s/『G20544』/cleansing/g
s/『G20545』/one by one, one after antoher/g
s/『G20546』/invention/g
s/『G20547』/leader/g
s/『G20548』/found/g
s/『G20549』/establish/g
s/『G20550』/novelty/g
s/『G20551』/bad habit/g
s/『G20552』/perversely/g
s/『G20553』/misdeeds/g
s/『G20554』/furnace/g
s/『G20555』/hole in the roof for the smoke to pass through/g
s/『G20556』/coach-builder/g
s/『G20557』/resolutely/g
s/『G20558』/strength of spirit/g
s/『G20559』/overload/g
s/『G20560』/descent/g
s/『G20561』/murmur against/g
s/『G20562』/subdue/g
s/『G20563』/absorb, do away with/g
s/『G20564』/repeat/g
s/『G20565』/is easily melted/g
s/『G20566』/bind by spells, enchant/g
s/『G20567』/cryptoporticus/g
s/『G20568』/precious/g
s/『G20569』/flowing down/g
s/『G20570』/one must talk against/g
s/『G20571』/smooth down, placate/g
s/『G20572』/distribution/g
s/『G20573』/spend in eating, waste/g
s/『G20574』/fortify, protect/g
s/『G20575』/one must despise/g
s/『G20576』/involved in/g
s/『G20577』/slander, calumny/g
s/『G20578』/despise/g
s/『G20579』/become firmly established/g
s/『G20580』/over against, right opposite/g
s/『G20581』/very eager/g
s/『G20582』/bow down upon/g
s/『G20583』/dīrīmat/g
s/『G20584』/hit exactly/g
s/『G20585』/highly blessed/g
s/『G20586』/applaud, extol/g
s/『G20587』/let down/g
s/『G20588』/afflict grievously/g
s/『G20589』/habitation/g
s/『G20590』/feel compassion at the thought/g
s/『G20591』/hidden/g
s/『G20592』/overtake/g
s/『G20593』/lowest/g
s/『G20594』/inflammatory humours/g
s/『G20595』/kiln/g
s/『G20596』/shorn/g
s/『G20597』/by way of command/g
s/『G20598』/vacant space/g
s/『G20599』/to be vain-glorious/g
s/『G20600』/combs/g
s/『G20601』/moving things/g
s/『G20602』/part of a torsion-engine shaped like an ivy-leaf/g
s/『G20603』/furtim/g
s/『G20604』/name, appellation/g
s/『G20605』/inheritance/g
s/『G20606』/one must call/g
s/『G20607』/scratch/g
s/『G20608』/interior/g
s/『G20609』/shortage of cash/g
s/『G20610』/derided/g
s/『G20611』/bake/g
s/『G20612』/PHolm., PLeid.X./g
s/『G20613』/slit-nosed/g
s/『G20614』/kor/g
s/『G20615』/filling the world/g
s/『G20616』/holding firm, steadying/g
s/『G20617』/lurking-place/g
s/『G20618』/sphere, globe/g
s/『G20619』/of Cycnus/g
s/『G20620』/small cup/g
s/『G20621』/shameless fly/g
s/『G20622』/prey/g
s/『G20623』/pregnancy/g
s/『G20624』/a measure of corn/g
s/『G20625』/possession, control/g
s/『G20626』/membrum virile/g
s/『G20627』/cōnōpēum/g
s/『G20628』/female garment/g
s/『G20629』/shining/g
s/『G20630』/poll-tax/g
s/『G20631』/swaggerer/g
s/『G20632』/stone hewn from a quarry/g
s/『G20633』/plunder/g
s/『G20634』/secretly/g
s/『G20635』/like a lion/g
s/『G20636』/rind, shell, husk/g
s/『G20637』/giving birth/g
s/『G20638』/to be mixed with frankincense/g
s/『G20639』/struck with stones, stoned/g
s/『G20640』/desert one's post/g
s/『G20641』/entreaty/g
s/『G20642』/pestilent condition/g
s/『G20643』/to give birth/g
s/『G20644』/defiled with gore/g
s/『G20645』/economy/g
s/『G20646』/redeemable/g
s/『G20647』/rob, plunder/g
s/『G20648』/migdol/g
s/『G20649』/cooking/g
s/『G20650』/skilled in magic/g
s/『G20651』/cooking/g
s/『G20652』/falling off of the eyelashes/g
s/『G20653』/there is baldness/g
s/『G20654』/íš mādhón/g
s/『G20655』/amalgam/g
s/『G20656』/long living/g
s/『G20657』/length of days/g
s/『G20658』/long-haired/g
s/『G20659』/farther off/g
s/『G20660』/persevere/g
s/『G20661』/long-lasting/g
s/『G20662』/calmness of the sea, malacia ac tranquillitas/g
s/『G20663』/to be cowardly/g
s/『G20664』/softening/g
s/『G20665』/mard-khwār/g
s/『G20666』/policeman/g
s/『G20667』/demanding vengeance/g
s/『G20668』/scourger/g
s/『G20669』/dicta est/g
s/『G20670』/weak-minded/g
s/『G20671』/talking idly/g
s/『G20672』/one must fight/g
s/『G20673』/large loaf/g
s/『G20674』/exultation/g
s/『G20675』/very glorious/g
s/『G20676』/long-lived/g
s/『G20677』/long-ruling/g
s/『G20678』/magnificent, sumptuous/g
s/『G20679』/magnify/g
s/『G20680』/one who does great things/g
s/『G20681』/great/g
s/『G20682』/of great strength/g
s/『G20683』/to be arrogant/g
s/『G20684』/romantic, Quixotic/g
s/『G20685』/having a higher denominator/g
s/『G20686』/far and wide, over a vast space/g
s/『G20687』/envious/g
s/『G20688』/passing lovely/g
s/『G20689』/having their order changed/g
s/『G20690』/fit for interpreting/g
s/『G20691』/remiss, careless/g
s/『G20692』/regular/g
s/『G20693』/stratagem/g
s/『G20694』/determino/g
s/『G20695』/drunkenness/g
s/『G20696』/drunk with cottabus-playing/g
s/『G20697』/beam/g
s/『G20698』/of meditations/g
s/『G20699』/be gained by practice/g
s/『G20700』/balm/g
s/『G20701』/tuneful/g
s/『G20702』/province/g
s/『G20703』/his office/g
s/『G20704』/suffering/g
s/『G20705』/portioned/g
s/『G20706』/division/g
s/『G20707』/begetting men/g
s/『G20708』/occupy a central position/g
s/『G20709』/noon/g
s/『G20710』/in the midst/g
s/『G20711』/to be half-way/g
s/『G20712』/mid/g
s/『G20713』/rent in twain/g
s/『G20714』/to be transferred, carried away/g
s/『G20715』/change one's way of life/g
s/『G20716』/intermix/g
s/『G20717』/to be got by mining/g
s/『G20718』/having departed/g
s/『G20719』/acquire a fresh tendency/g
s/『G20720』/refashion/g
s/『G20721』/a certain amount of/g
s/『G20722』/travelling through air/g
s/『G20723』/have one's course changed/g
s/『G20724』/transmigration/g
s/『G20725』/divert/g
s/『G20726』/one must measure/g
s/『G20727』/isn't it?/g
s/『G20728』/use of the probe/g
s/『G20729』/wrath/g
s/『G20730』/to be wrathful/g
s/『G20731』/wrathful man/g
s/『G20732』/lest perchance/g
s/『G20733』/thigh-burnt/g
s/『G20734』/to chew the cud/g
s/『G20735』/engineer/g
s/『G20736』/eating of abominable meats/g
s/『G20737』/gymnasium named after Mimnermus/g
s/『G20738』/hating virtue/g
s/『G20739』/half/g
s/『G20740』/mercenary/g
s/『G20741』/guests/g
s/『G20742』/wickedness/g
s/『G20743』/hatred because of wickedness/g
s/『G20744』/with hostile sentiments/g
s/『G20745』/hating insolence/g
s/『G20746』/Mitra/g
s/『G20747』/objects of memory/g
s/『G20748』/remembering God/g
s/『G20749』/remembrance of wrongs/g
s/『G20750』/to commit adultery/g
s/『G20751』/adulteress/g
s/『G20752』/lead/g
s/『G20753』/get into dirty quarrels/g
s/『G20754』/apt to make dirty/g
s/『G20755』/spot, taint/g
s/『G20756』/lasting one day/g
s/『G20757』/uniquely/g
s/『G20758』/constancy, steadfastness/g
s/『G20759』/single, solitary/g
s/『G20760』/man with ox's head/g
s/『G20761』/digging with one point/g
s/『G20762』/eating alone/g
s/『G20763』/eating alone/g
s/『G20764』/well-formed, shapely/g
s/『G20765』/PLond.ined./g
s/『G20766』/suffering/g
s/『G20767』/strengthening/g
s/『G20768』/prating/g
s/『G20769』/dry nose/g
s/『G20770』/bruised in a mill/g
s/『G20771』/to be hardened, cicatrized/g
s/『G20772』/preparation of unguents/g
s/『G20773』/prepared unguent/g
s/『G20774』/of myrrh/g
s/『G20775』/time out of mind/g
s/『G20776』/myriad/g
s/『G20777』/an anointing/g
s/『G20778』/irritation of the skin/g
s/『G20779』/like an ant/g
s/『G20780』/wet with unguent/g
s/『G20781』/loathsomeness/g
s/『G20782』/the originator of a foul deed/g
s/『G20783』/defiled/g
s/『G20784』/teacher/g
s/『G20785』/for mysteries/g
s/『G20786』/scribere/g
s/『G20787』/initiator/g
s/『G20788』/jar/g
s/『G20789』/mockery/g
s/『G20790』/mocker/g
s/『G20791』/suitable for weals/g
s/『G20792』/blame/g
s/『G20793』/are you/g
s/『G20794』/be foolish/g
s/『G20795』/stupidly wicked/g
s/『G20796』/rent/g
s/『G20797』/naft/g
s/『G20798』/insulted/g
s/『G20799』/carcas/g
s/『G20800』/newly created/g
s/『G20801』/beehive/g
s/『G20802』/to build a nest/g
s/『G20803』/slaying children/g
s/『G20804』/nig[uglide]/g
s/『G20805』/world/g
s/『G20806』/consider spurious/g
s/『G20807』/govenor/g
s/『G20808』/one must account, deem/g
s/『G20809』/observer of the law/g
s/『G20810』/point/g
s/『G20811』/by stealth/g
s/『G20812』/of the Nymphs/g
s/『G20813』/sluggishness/g
s/『G20814』/Month Eandikos/g
s/『G20815』/life of a mercenary in foreign service/g
s/『G20816』/raise a contribution of/g
s/『G20817』/maintain mercenary troops/g
s/『G20818』/smooth/g
s/『G20819』/slaves/g
s/『G20820』/nest/g
s/『G20821』/cupbearer/g
s/『G20822』/mad passion/g
s/『G20823』/Oitosupos \(Apollo\)/g
s/『G20824』/to be eaten of birds/g
s/『G20825』/olg[uglide]ā/g
s/『G20826』/fated/g
s/『G20827』/destruction-bringing/g
s/『G20828』/make few, diminish/g
s/『G20829』/to be offered as a whole burnt-offering/g
s/『G20830』/sterile male inflorescence of the caprifig/g
s/『G20831』/utterly/g
s/『G20832』/made of solid beaten metal/g
s/『G20833』/desire, long for/g
s/『G20834』/remembered/g
s/『G20835』/common zeal/g
s/『G20836』/bound by treaty to/g
s/『G20837』/endowed with the same soul/g
s/『G20838』/chamelion/g
s/『G20839』/writing of names/g
s/『G20840』/when once/g
s/『G20841』/arm/g
s/『G20842』/to be disarmed/g
s/『G20843』/make weapons/g
s/『G20844』/like that/g
s/『G20845』/fierce/g
s/『G20846』/dawn/g
s/『G20847』/dealer in birds/g
s/『G20848』/frequent mountains/g
s/『G20849』/to be roofed/g
s/『G20850』/full of potsherds/g
s/『G20851』/nosegay/g
s/『G20852』/surely not/g
s/『G20853』/none/g
s/『G20854』/lag behind/g
s/『G20855』/bitten by a serpent/g
s/『G20856』/penalty/g
s/『G20857』/attract a crowd/g
s/『G20858』/small fort/g
s/『G20859』/fortification/g
s/『G20860』/food/g
s/『G20861』/fish/g
s/『G20862』/master-gardener/g
s/『G20863』/victorious/g
s/『G20864』/manger/g
s/『G20865』/government of the passions, self-restraint/g
s/『G20866』/chanting of the paean/g
s/『G20867』/*Geom./g
s/『G20868』/absolute monarch/g
s/『G20869』/with all the limbs, entire/g
s/『G20870』/all-abominable/g
s/『G20871』/mixed of all sorts, all-blended/g
s/『G20872』/all-holy/g
s/『G20873』/with the whole nation/g
s/『G20874』/all-observing/g
s/『G20875』/shell\/shield/g
s/『G20876』/display, ostentation/g
s/『G20877』/most lamentable/g
s/『G20878』/wonderful feats/g
s/『G20879』/sophistry/g
s/『G20880』/all-surveying/g
s/『G20881』/in full armour/g
s/『G20882』/all-powerful/g
s/『G20883』/to be almighty/g
s/『G20884』/all-nurturing/g
s/『G20885』/indiscriminate eating/g
s/『G20886』/impostor/g
s/『G20887』/commit treason/g
s/『G20888』/adjacent to an angle/g
s/『G20889』/military reprimand/g
s/『G20890』/cause to dine/g
s/『G20891』/appendage/g
s/『G20892』/keep watch by/g
s/『G20893』/excuse, pretext/g
s/『G20894』/shut up/g
s/『G20895』/turn aside from, avoid/g
s/『G20896』/read publicly/g
s/『G20897』/lay beside/g
s/『G20898』/present oneself obliquely/g
s/『G20899』/cheat/g
s/『G20900』/near/g
s/『G20901』/to preside/g
s/『G20902』/fallacious/g
s/『G20903』/fortify next in order/g
s/『G20904』/flow/g
s/『G20905』/like a pard/g
s/『G20906』/alter slightly/g
s/『G20907』/enter/g
s/『G20908』/fail/g
s/『G20909』/rebuke/g
s/『G20910』/to be derived/g
s/『G20911』/to be included in one form/g
s/『G20912』/outside/g
s/『G20913』/exhibit out of season, make a display/g
s/『G20914』/virginity/g
s/『G20915』/make a side-road/g
s/『G20916』/passing by/g
s/『G20917』/people who quote proverbs/g
s/『G20918』/overlooking/g
s/『G20919』/to beguile/g
s/『G20920』/outspoken/g
s/『G20921』/not to admit of/g
s/『G20922』/one fettered, prisoner/g
s/『G20923』/stalk/g
s/『G20924』/become worn in the sole/g
s/『G20925』/to be poor/g
s/『G20926』/wild rose/g
s/『G20927』/five times twisted/g
s/『G20928』/league of five cities/g
s/『G20929』/fifty-six/g
s/『G20930』/fifty-four/g
s/『G20931』/from the far side/g
s/『G20932』/tie the hands behind the back/g
s/『G20933』/to be completely drowned/g
s/『G20934』/set in silver/g
s/『G20935』/keep alive/g
s/『G20936』/utter frantic cries/g
s/『G20937』/space round a/g
s/『G20938』/carved figure/g
s/『G20939』/wrap round, pack up/g
s/『G20940』/inflame, excite/g
s/『G20941』/detected/g
s/『G20942』/on such ground/g
s/『G20943』/declare loudly/g
s/『G20944』/to be mastered, cured/g
s/『G20945』/rend all round/g
s/『G20946』/embrace/g
s/『G20947』/drilled out/g
s/『G20948』/pathetic, heartrending/g
s/『G20949』/cover thick all round/g
s/『G20950』/much-beloved/g
s/『G20951』/sprinkle/g
s/『G20952』/about them/g
s/『G20953』/exceeding strong/g
s/『G20954』/drawers/g
s/『G20955』/scalp in Scythian fashion/g
s/『G20956』/small pidgeon/g
s/『G20957』/enwreathe, surround/g
s/『G20958』/whorls/g
s/『G20959』/cover with a coat/g
s/『G20960』/despising/g
s/『G20961』/plant round about/g
s/『G20962』/relax all round/g
s/『G20963』/refresh, revive, cherish/g
s/『G20964』/renaid/g
s/『G20965』/plates/g
s/『G20966』/baldacchino/g
s/『G20967』/govern/g
s/『G20968』/working in clay/g
s/『G20969』/to pitch \(a tent\)/g
s/『G20970』/multitude/g
s/『G20971』/accredit, confirm/g
s/『G20972』/one must use in abundance/g
s/『G20973』/lungs/g
s/『G20974』/plebs/g
s/『G20975』/make multiple, 'plurify'/g
s/『G20976』/-casing/g
s/『G20977』/maintain war/g
s/『G20978』/to be made an enemy of/g
s/『G20979』/statesman/g
s/『G20980』/keeping for many years/g
s/『G20981』/attain length of days/g
s/『G20982』/the hissing of the serpents round the Gorgon's head/g
s/『G20983』/swearing much/g
s/『G20984』/with many children/g
s/『G20985』/great experience/g
s/『G20986』/much-experienced/g
s/『G20987』/many times/g
s/『G20988』/number/g
s/『G20989』/full of thought/g
s/『G20990』/condition/g
s/『G20991』/drowned in the sea/g
s/『G20992』/going, travelling/g
s/『G20993』/hair-clasp/g
s/『G20994』/troublesome, formidable/g
s/『G20995』/rather rashly/g
s/『G20996』/first/g
s/『G20997』/fulfil before/g
s/『G20998』/torture before/g
s/『G20999』/muttonium/g
s/『G21000』/forelands, headlands/g
s/『G21001』/spread, beaten out/g
s/『G21002』/ancestral/g
s/『G21003』/to be involved in before/g
s/『G21004』/send out before/g
s/『G21005』/defender, advocate/g
s/『G21006』/extend/g
s/『G21007』/reap first/g
s/『G21008』/prematurely/g
s/『G21009』/to be afflicted before/g
s/『G21010』/use the device of/g
s/『G21011』/inveterate/g
s/『G21012』/set down first/g
s/『G21013』/overhanging, beetling/g
s/『G21014』/cake/g
s/『G21015』/indicate before, predict/g
s/『G21016』/the day before a new moon/g
s/『G21017』/one who goes before to show the way/g
s/『G21018』/vanguard/g
s/『G21019』/exact/g
s/『G21020』/out/g
s/『G21021』/degeneration/g
s/『G21022』/recount besides/g
s/『G21023』/find rest in/g
s/『G21024』/overturn besides/g
s/『G21025』/to be added for edification/g
s/『G21026』/also/g
s/『G21027』/dispatch besides/g
s/『G21028』/push away, reject besides/g
s/『G21029』/lately/g
s/『G21030』/smile upon/g
s/『G21031』/beside/g
s/『G21032』/permit/g
s/『G21033』/threaten besides/g
s/『G21034』/to burn through/g
s/『G21035』/to be holden by, in the grip of/g
s/『G21036』/relate besides/g
s/『G21037』/still more/g
s/『G21038』/still more/g
s/『G21039』/to be noted before/g
s/『G21040』/go down to meet/g
s/『G21041』/extend besides/g
s/『G21042』/painted scenery at the back of the stage/g
s/『G21043』/invocation/g
s/『G21044』/lament beside/g
s/『G21045』/to be surnamed/g
s/『G21046』/putting to land/g
s/『G21047』/still more/g
s/『G21048』/sprinkle upon/g
s/『G21049』/incense still more/g
s/『G21050』/an order/g
s/『G21051』/trouble further/g
s/『G21052』/licence-fee/g
s/『G21053』/celebrate in song as well/g
s/『G21054』/to be drawn up beforehand/g
s/『G21055』/raise still higher/g
s/『G21056』/cling fast/g
s/『G21057』/obtutus\)/g
s/『G21058』/abuse/g
s/『G21059』/towards/g
s/『G21060』/person/g
s/『G21061』/before/g
s/『G21062』/antecedents/g
s/『G21063』/conspicuous, extraordinary/g
s/『G21064』/to be loosed beforehand/g
s/『G21065』/dam/g
s/『G21066』/president/g
s/『G21067』/yesterday/g
s/『G21068』/coronation festival/g
s/『G21069』/first shearing/g
s/『G21070』/first-formed/g
s/『G21071』/lippus/g
s/『G21072』/excitement/g
s/『G21073』/arrows tipped with fire/g
s/『G21074』/red-winged/g
s/『G21075』/redder/g
s/『G21076』/pointer/g
s/『G21077』/drop, spot/g
s/『G21078』/roving/g
s/『G21079』/bearing roses/g
s/『G21080』/deliverance/g
s/『G21081』/entrance/g
s/『G21082』/vendor/g
s/『G21083』/of the week/g
s/『G21084』/padding/g
s/『G21085』/table/g
s/『G21086』/medlar/g
s/『G21087』/quenching/g
s/『G21088』/act of worship/g
s/『G21089』/bewitching/g
s/『G21090』/extortions/g
s/『G21091』/weight/g
s/『G21092』/decay/g
s/『G21093』/be able/g
s/『G21094』/silence/g
s/『G21095』/with bonds of iron/g
s/『G21096』/provision/g
s/『G21097』/protection/g
s/『G21098』/food preparation/g
s/『G21099』/furniture/g
s/『G21100』/preparer/g
s/『G21101』/dwelling in one/g
s/『G21102』/perspective-painter, scene-painter/g
s/『G21103』/hard-footed/g
s/『G21104』/watch out/g
s/『G21105』/contumely/g
s/『G21106』/small scorpion/g
s/『G21107』/darkness/g
s/『G21108』/look on as dung, reject contemptuously/g
s/『G21109』/despoiling, plundering/g
s/『G21110』/expenditure of effort, trouble/g
s/『G21111』/evil, ruin/g
s/『G21112』/meadow-saffron, Colchicum parnassicum/g
s/『G21113』/craving/g
s/『G21114』/drawing/g
s/『G21115』/bracelet/g
s/『G21116』/in maniples, manipulatim/g
s/『G21117』/a feeding on the inwards of a sacrifice/g
s/『G21118』/eating the/g
s/『G21119』/with ashes/g
s/『G21120』/by weight/g
s/『G21121』/sebaceous formation in the scrotum/g
s/『G21122』/brothel/g
s/『G21123』/make barren/g
s/『G21124』/desire, entreat/g
s/『G21125』/of solid nature/g
s/『G21126』/obstinacy/g
s/『G21127』/to be a/g
s/『G21128』/poitrel/g
s/『G21129』/recording on a tablet/g
s/『G21130』/apply any eye-salve/g
s/『G21131』/made of tow/g
s/『G21132』/hemp/g
s/『G21133』/arranged in a row/g
s/『G21134』/course/g
s/『G21135』/a bit \(of a horse\)/g
s/『G21136』/a scale which flies from hammered iron/g
s/『G21137』/strew./g
s/『G21138』/ligature/g
s/『G21139』/induration/g
s/『G21140』/agino/g
s/『G21141』/out-general/g
s/『G21142』/province governed by a/g
s/『G21143』/torture/g
s/『G21144』/rack/g
s/『G21145』/cheese/g
s/『G21146』/winter cherry/g
s/『G21147』/laugh with, join in laughter/g
s/『G21148』/relatives/g
s/『G21149』/experience, training/g
s/『G21150』/lasts to the end of/g
s/『G21151』/together/g
s/『G21152』/pierce together, stab at once/g
s/『G21153』/a mixed drink, aqua calda/g
s/『G21154』/thunder-stricken/g
s/『G21155』/to be joint-heir/g
s/『G21156』/collision/g
s/『G21157』/to be created along with/g
s/『G21158』/to be contemporaneous/g
s/『G21159』/conjugate/g
s/『G21160』/girdle/g
s/『G21161』/useless/g
s/『G21162』/fig-yard/g
s/『G21163』/ambush/g
s/『G21164』/musterroll, census/g
s/『G21165』/rest under the same roof./g
s/『G21166』/club, society/g
s/『G21167』/confidants/g
s/『G21168』/keeper of receipts/g
s/『G21169』/-senator/g
s/『G21170』/to be assessor with/g
s/『G21171』/to be mad together, join in madness/g
s/『G21172』/hold, stand fast, continue/g
s/『G21173』/defile together with/g
s/『G21174』/feel common hatred of what is bad/g
s/『G21175』/disgrace together/g
s/『G21176』/accompanying/g
s/『G21177』/drinking together/g
s/『G21178』/travel forward with/g
s/『G21179』/burn together/g
s/『G21180』/bring together in thought/g
s/『G21181』/gravel in the kidneys/g
s/『G21182』/wrestle with/g
s/『G21183』/living with, intercourse/g
s/『G21184』/shut up altogether/g
s/『G21185』/conceal together/g
s/『G21186』/smart exceedingly/g
s/『G21187』/members of a dining-club/g
s/『G21188』/arranged/g
s/『G21189』/stab at once/g
s/『G21190』/destroy utterly together/g
s/『G21191』/stronghold/g
s/『G21192』/contend together/g
s/『G21193』/counsel well with/g
s/『G21194』/recommendation/g
s/『G21195』/suffer pain with/g
s/『G21196』/decide/g
s/『G21197』/licentiousness/g
s/『G21198』/to pipe/g
s/『G21199』/roam together/g
s/『G21200』/tent-mate/g
s/『G21201』/sweep along with one/g
s/『G21202』/machine, apparatus/g
s/『G21203』/familiarity/g
s/『G21204』/beam/g
s/『G21205』/an instrument of torture/g
s/『G21206』/greed/g
s/『G21207』/leather thong, shoe-latchet/g
s/『G21208』/act with insufficient care/g
s/『G21209』/mastich, Pistacia Lentiscus/g
s/『G21210』/protecting the body/g
s/『G21211』/in arithmetical progression/g
s/『G21212』/safe, sure, certain/g
s/『G21213』/chamber, closet/g
s/『G21214』/meanness/g
s/『G21215』/child of Tartarus/g
s/『G21216』/Tarshish/g
s/『G21217』/sagacity/g
s/『G21218』/swift-rushing, swift-flying/g
s/『G21219』/tukkîyîm/g
s/『G21220』/child-murdering/g
s/『G21221』/carpenter/g
s/『G21222』/sorceress/g
s/『G21223』/are done/g
s/『G21224』/been paid/g
s/『G21225』/wonders/g
s/『G21226』/quadripartite/g
s/『G21227』/in a fourfold manner, fourfold/g
s/『G21228』/masonry, fabric/g
s/『G21229』/courtesan/g
s/『G21230』/fry in a/g
s/『G21231』/splendour/g
s/『G21232』/nursing/g
s/『G21233』/nursing/g
s/『G21234』/avenger/g
s/『G21235』/quaked/g
s/『G21236』/one who exacts interest/g
s/『G21237』/endure/g
s/『G21238』/sharpest, hottest/g
s/『G21239』/venenum/g
s/『G21240』/famed for archery/g
s/『G21241』/district governed by a/g
s/『G21242』/manoeuvre for position/g
s/『G21243』/at one time . ., at another/g
s/『G21244』/thirty-four/g
s/『G21245』/swell/g
s/『G21246』/the 'trivium'/g
s/『G21247』/thrice as much as/g
s/『G21248』/thrice-sinful/g
s/『G21249』/in three places/g
s/『G21250』/three-headed/g
s/『G21251』/trihorium/g
s/『G21252』/stand in awe of/g
s/『G21253』/rearing, bringing up/g
s/『G21254』/processes/g
s/『G21255』/worked by a wheel/g
s/『G21256』/wheel/g
s/『G21257』/fastidious/g
s/『G21258』/texture/g
s/『G21259』/fruit eating/g
s/『G21260』/Trogodutai/g
s/『G21261』/drum-like/g
s/『G21262』/lines/g
s/『G21263』/to be beaten/g
s/『G21264』/with cheese on it/g
s/『G21265』/crazy vanity/g
s/『G21266』/insolent/g
s/『G21267』/mud/g
s/『G21268』/worm/g
s/『G21269』/sung of, praised, lauded/g
s/『G21270』/composer of hymns/g
s/『G21271』/self-exalting/g
s/『G21272』/exceedingly/g
s/『G21273』/excessive/g
s/『G21274』/to be praised exceedingly/g
s/『G21275』/leap to a high place/g
s/『G21276』/exceedingly glorious/g
s/『G21277』/behave arrogantly/g
s/『G21278』/champion, defender/g
s/『G21279』/melt exceedingly/g
s/『G21280』/prize overmuch/g
s/『G21281』/highly extolled/g
s/『G21282』/very terrible/g
s/『G21283』/sing loudly/g
s/『G21284』/upper/g
s/『G21285』/to be somewhat afraid/g
s/『G21286』/thing placed under, base/g
s/『G21287』/break/g
s/『G21288』/payment in advance/g
s/『G21289』/to be grieved at heart/g
s/『G21290』/below-breast/g
s/『G21291』/explain, interpret/g
s/『G21292』/supposition/g
s/『G21293』/procure by corruption/g
s/『G21294』/intrigues/g
s/『G21295』/trip up/g
s/『G21296』/a cutting instrument/g
s/『G21297』/shuddering a little/g
s/『G21298』/a gleaning/g
s/『G21299』/carry the neck high, show off/g
s/『G21300』/become bald/g
s/『G21301』/bald place/g
s/『G21302』/indulge vain fancies/g
s/『G21303』/witchcraft/g
s/『G21304』/ceiling in coffers/g
s/『G21305』/thrift, sparing/g
s/『G21306』/have the morbus pedicularis, Com. A desp./g
s/『G21307』/obtain redress/g
s/『G21308』/love money/g
s/『G21309』/efforts to gain power/g
s/『G21310』/compassionate/g
s/『G21311』/loving one's children/g
s/『G21312』/womaniser/g
s/『G21313』/loving one's fellow-citizens/g
s/『G21314』/love of one's children/g
s/『G21315』/souls/g
s/『G21316』/heat, passion, excess/g
s/『G21317』/terrible to behold/g
s/『G21318』/cleanse, purify/g
s/『G21319』/deadly, malignant/g
s/『G21320』/carry-chair/g
s/『G21321』/tribute/g
s/『G21322』/to be high-minded, elated/g
s/『G21323』/shuddering, shivering/g
s/『G21324』/watching/g
s/『G21325』/arrogant/g
s/『G21326』/dragging along fugitives/g
s/『G21327』/a chief/g
s/『G21328』/fruitful/g
s/『G21329』/draw down supernatural illumination/g
s/『G21330』/salute/g
s/『G21331』/bronze-worker/g
s/『G21332』/joy caused to any one/g
s/『G21333』/grey/g
s/『G21334』/papyrus/g
s/『G21335』/plug in a ship's bottom/g
s/『G21336』/pantomimic movement, gesticulation/g
s/『G21337』/cranium/g
s/『G21338』/made of tortoise-shell/g
s/『G21339』/threshold/g
s/『G21340』/with empty hands/g
s/『G21341』/knock/g
s/『G21342』/green fodder/g
s/『G21343』/get together/g
s/『G21344』/dancing-place/g
s/『G21345』/of grass, like grass/g
s/『G21346』/dust/g
s/『G21347』/oracle, sanctuary/g
s/『G21348』/serviceable/g
s/『G21349』/goodness of heart/g
s/『G21350』/a short time/g
s/『G21351』/goldsmith/g
s/『G21352』/flavour/g
s/『G21353』/psalmist/g
s/『G21354』/harper/g
s/『G21355』/sabulum./g
s/『G21356』/stucco/g
s/『G21357』/bhasman/g
s/『G21358』/secret door/g
s/『G21359』/tickling/g
s/『G21360』/to make mosaic/g
s/『G21361』/twittering/g
s/『G21362』/to blame/g
s/『G21363』/animi oblectamenta procurentur/g
s/『G21364』/to be at the last gasp/g
s/『G21365』/[hudot ]èbel/g
s/『G21366』/small shoulder/g
s/『G21367』/savagery, fierceness, cruelty/g
s/『G21368』/savage-minded/g
s/『G21369』/make display/g
